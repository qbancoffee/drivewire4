/*     */ package com.Ostermiller.util;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class BrowserCommandLexer
/*     */ {
/*     */   private static final int YYEOF = -1;
/*     */   private static final int ZZ_BUFFERSIZE = 16384;
/*     */   private static final int YYINITIAL = 0;
/*     */   private static final String ZZ_CMAP_PACKED = "\t\000\002\002\001\000\002\002\022\000\001\002\001\000\001\0039\000\001\001ﾣ\000";
/*  62 */   private static final char[] ZZ_CMAP = zzUnpackCMap("\t\000\002\002\001\000\002\002\022\000\001\002\001\000\001\0039\000\001\001ﾣ\000");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  67 */   private static final int[] ZZ_ACTION = zzUnpackAction();
/*     */ 
/*     */   
/*     */   private static final String ZZ_ACTION_PACKED_0 = "\002\001\002\002\001\001\003\000\001\003\001\001\001\003\001\000\002\003";
/*     */ 
/*     */   
/*     */   private static int[] zzUnpackAction() {
/*  74 */     int[] result = new int[14];
/*  75 */     int offset = 0;
/*  76 */     offset = zzUnpackAction("\002\001\002\002\001\001\003\000\001\003\001\001\001\003\001\000\002\003", offset, result);
/*  77 */     return result;
/*     */   }
/*     */   
/*     */   private static int zzUnpackAction(String packed, int offset, int[] result) {
/*  81 */     int i = 0;
/*  82 */     int j = offset;
/*  83 */     int l = packed.length();
/*  84 */     while (i < l) {
/*  85 */       int count = packed.charAt(i++);
/*  86 */       int value = packed.charAt(i++); 
/*  87 */       do { result[j++] = value; } while (--count > 0);
/*     */     } 
/*  89 */     return j;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  96 */   private static final int[] ZZ_ROWMAP = zzUnpackRowMap();
/*     */ 
/*     */   
/*     */   private static final String ZZ_ROWMAP_PACKED_0 = "\000\000\000\004\000\b\000\f\000\020\000\b\000\024\000\030\000\004\000\034\000\020\000 \000\f\000\030";
/*     */ 
/*     */   
/*     */   private static int[] zzUnpackRowMap() {
/* 103 */     int[] result = new int[14];
/* 104 */     int offset = 0;
/* 105 */     offset = zzUnpackRowMap("\000\000\000\004\000\b\000\f\000\020\000\b\000\024\000\030\000\004\000\034\000\020\000 \000\f\000\030", offset, result);
/* 106 */     return result;
/*     */   }
/*     */   
/*     */   private static int zzUnpackRowMap(String packed, int offset, int[] result) {
/* 110 */     int i = 0;
/* 111 */     int j = offset;
/* 112 */     int l = packed.length();
/* 113 */     while (i < l) {
/* 114 */       int high = packed.charAt(i++) << 16;
/* 115 */       result[j++] = high | packed.charAt(i++);
/*     */     } 
/* 117 */     return j;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 123 */   private static final int[] ZZ_TRANS = zzUnpackTrans();
/*     */   
/*     */   private static final String ZZ_TRANS_PACKED_0 = "\001\002\001\003\001\004\001\005\001\002\001\006\001\000\005\002\004\000\001\005\001\007\001\b\001\t\001\005\001\n\001\005\001\013\001\b\001\f\001\b\001\r\001\005\001\007\001\b\001\013\001\b\001\f\001\b\001\016";
/*     */   
/*     */   private static final int ZZ_UNKNOWN_ERROR = 0;
/*     */   private static final int ZZ_NO_MATCH = 1;
/*     */   private static final int ZZ_PUSHBACK_2BIG = 2;
/*     */   
/*     */   private static int[] zzUnpackTrans() {
/* 132 */     int[] result = new int[36];
/* 133 */     int offset = 0;
/* 134 */     offset = zzUnpackTrans("\001\002\001\003\001\004\001\005\001\002\001\006\001\000\005\002\004\000\001\005\001\007\001\b\001\t\001\005\001\n\001\005\001\013\001\b\001\f\001\b\001\r\001\005\001\007\001\b\001\013\001\b\001\f\001\b\001\016", offset, result);
/* 135 */     return result;
/*     */   }
/*     */   
/*     */   private static int zzUnpackTrans(String packed, int offset, int[] result) {
/* 139 */     int i = 0;
/* 140 */     int j = offset;
/* 141 */     int l = packed.length();
/* 142 */     while (i < l) {
/* 143 */       int count = packed.charAt(i++);
/* 144 */       int value = packed.charAt(i++);
/* 145 */       value--; 
/* 146 */       do { result[j++] = value; } while (--count > 0);
/*     */     } 
/* 148 */     return j;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 158 */   private static final String[] ZZ_ERROR_MSG = new String[] {
/* 159 */       "Unkown internal scanner error", 
/* 160 */       "Error: could not match input", 
/* 161 */       "Error: pushback value was too large"
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 167 */   private static final int[] ZZ_ATTRIBUTE = zzUnpackAttribute();
/*     */   private static final String ZZ_ATTRIBUTE_PACKED_0 = "\003\001\001\t\001\001\003\000\003\001\001\000\001\t\001\001";
/*     */   private Reader zzReader;
/*     */   private int zzState;
/*     */   
/*     */   private static int[] zzUnpackAttribute() {
/* 173 */     int[] result = new int[14];
/* 174 */     int offset = 0;
/* 175 */     offset = zzUnpackAttribute("\003\001\001\t\001\001\003\000\003\001\001\000\001\t\001\001", offset, result);
/* 176 */     return result;
/*     */   }
/*     */   
/*     */   private static int zzUnpackAttribute(String packed, int offset, int[] result) {
/* 180 */     int i = 0;
/* 181 */     int j = offset;
/* 182 */     int l = packed.length();
/* 183 */     while (i < l) {
/* 184 */       int count = packed.charAt(i++);
/* 185 */       int value = packed.charAt(i++); 
/* 186 */       do { result[j++] = value; } while (--count > 0);
/*     */     } 
/* 188 */     return j;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 198 */   private int zzLexicalState = 0;
/*     */ 
/*     */ 
/*     */   
/* 202 */   private char[] zzBuffer = new char[16384];
/*     */ 
/*     */ 
/*     */   
/*     */   private int zzMarkedPos;
/*     */ 
/*     */ 
/*     */   
/*     */   private int zzPushbackPos;
/*     */ 
/*     */ 
/*     */   
/*     */   private int zzCurrentPos;
/*     */ 
/*     */ 
/*     */   
/*     */   private int zzStartRead;
/*     */ 
/*     */ 
/*     */   
/*     */   private int zzEndRead;
/*     */ 
/*     */ 
/*     */   
/*     */   private int yyline;
/*     */ 
/*     */ 
/*     */   
/*     */   private int yychar;
/*     */ 
/*     */ 
/*     */   
/*     */   private int yycolumn;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean zzAtBOL = true;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean zzAtEOF;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getNextToken() throws IOException {
/* 248 */     return getToken();
/*     */   }
/*     */   
/*     */   private static String unescape(String s) {
/* 252 */     StringBuffer sb = new StringBuffer(s.length());
/* 253 */     for (int i = 0; i < s.length(); i++) {
/* 254 */       if (s.charAt(i) == '\\' && i < s.length()) {
/* 255 */         i++;
/*     */       }
/* 257 */       sb.append(s.charAt(i));
/*     */     } 
/* 259 */     return sb.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   BrowserCommandLexer(Reader in) {
/* 270 */     this.zzReader = in;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   BrowserCommandLexer(InputStream in) {
/* 280 */     this(new InputStreamReader(in));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static char[] zzUnpackCMap(String packed) {
/* 290 */     char[] map = new char[65536];
/* 291 */     int i = 0;
/* 292 */     int j = 0;
/* 293 */     while (i < 22) {
/* 294 */       int count = packed.charAt(i++);
/* 295 */       char value = packed.charAt(i++); 
/* 296 */       do { map[j++] = value; } while (--count > 0);
/*     */     } 
/* 298 */     return map;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean zzRefill() throws IOException {
/* 312 */     if (this.zzStartRead > 0) {
/* 313 */       System.arraycopy(this.zzBuffer, this.zzStartRead, 
/* 314 */           this.zzBuffer, 0, 
/* 315 */           this.zzEndRead - this.zzStartRead);
/*     */ 
/*     */       
/* 318 */       this.zzEndRead -= this.zzStartRead;
/* 319 */       this.zzCurrentPos -= this.zzStartRead;
/* 320 */       this.zzMarkedPos -= this.zzStartRead;
/* 321 */       this.zzPushbackPos -= this.zzStartRead;
/* 322 */       this.zzStartRead = 0;
/*     */     } 
/*     */ 
/*     */     
/* 326 */     if (this.zzCurrentPos >= this.zzBuffer.length) {
/*     */       
/* 328 */       char[] newBuffer = new char[this.zzCurrentPos * 2];
/* 329 */       System.arraycopy(this.zzBuffer, 0, newBuffer, 0, this.zzBuffer.length);
/* 330 */       this.zzBuffer = newBuffer;
/*     */     } 
/*     */ 
/*     */     
/* 334 */     int numRead = this.zzReader.read(this.zzBuffer, this.zzEndRead, 
/* 335 */         this.zzBuffer.length - this.zzEndRead);
/*     */     
/* 337 */     if (numRead < 0) {
/* 338 */       return true;
/*     */     }
/*     */     
/* 341 */     this.zzEndRead += numRead;
/* 342 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final void yyclose() throws IOException {
/* 351 */     this.zzAtEOF = true;
/* 352 */     this.zzEndRead = this.zzStartRead;
/*     */     
/* 354 */     if (this.zzReader != null) {
/* 355 */       this.zzReader.close();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final void yyreset(Reader reader) {
/* 370 */     this.zzReader = reader;
/* 371 */     this.zzAtBOL = true;
/* 372 */     this.zzAtEOF = false;
/* 373 */     this.zzEndRead = this.zzStartRead = 0;
/* 374 */     this.zzCurrentPos = this.zzMarkedPos = this.zzPushbackPos = 0;
/* 375 */     this.yyline = this.yychar = this.yycolumn = 0;
/* 376 */     this.zzLexicalState = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int yystate() {
/* 384 */     return this.zzLexicalState;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final void yybegin(int newState) {
/* 394 */     this.zzLexicalState = newState;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String yytext() {
/* 402 */     return new String(this.zzBuffer, this.zzStartRead, this.zzMarkedPos - this.zzStartRead);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final char yycharat(int pos) {
/* 418 */     return this.zzBuffer[this.zzStartRead + pos];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int yylength() {
/* 426 */     return this.zzMarkedPos - this.zzStartRead;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void zzScanError(int errorCode) {
/*     */     String message;
/*     */     try {
/* 447 */       message = ZZ_ERROR_MSG[errorCode];
/*     */     }
/* 449 */     catch (ArrayIndexOutOfBoundsException e) {
/* 450 */       message = ZZ_ERROR_MSG[0];
/*     */     } 
/*     */     
/* 453 */     throw new Error(message);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void yypushback(int number) {
/* 466 */     if (number > yylength()) {
/* 467 */       zzScanError(2);
/*     */     }
/* 469 */     this.zzMarkedPos -= number;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getToken() throws IOException {
/* 487 */     int zzEndReadL = this.zzEndRead;
/* 488 */     char[] zzBufferL = this.zzBuffer;
/* 489 */     char[] zzCMapL = ZZ_CMAP;
/*     */     
/* 491 */     int[] zzTransL = ZZ_TRANS;
/* 492 */     int[] zzRowMapL = ZZ_ROWMAP;
/* 493 */     int[] zzAttrL = ZZ_ATTRIBUTE;
/*     */     
/*     */     while (true) {
/* 496 */       int zzInput, zzMarkedPosL = this.zzMarkedPos;
/*     */       
/* 498 */       int zzAction = -1;
/*     */       
/* 500 */       int zzCurrentPosL = this.zzCurrentPos = this.zzStartRead = zzMarkedPosL;
/*     */       
/* 502 */       this.zzState = this.zzLexicalState;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       while (true) {
/* 508 */         if (zzCurrentPosL < zzEndReadL)
/* 509 */         { zzInput = zzBufferL[zzCurrentPosL++]; }
/* 510 */         else { if (this.zzAtEOF) {
/* 511 */             int i = -1;
/*     */             
/*     */             break;
/*     */           } 
/*     */           
/* 516 */           this.zzCurrentPos = zzCurrentPosL;
/* 517 */           this.zzMarkedPos = zzMarkedPosL;
/* 518 */           boolean eof = zzRefill();
/*     */           
/* 520 */           zzCurrentPosL = this.zzCurrentPos;
/* 521 */           zzMarkedPosL = this.zzMarkedPos;
/* 522 */           zzBufferL = this.zzBuffer;
/* 523 */           zzEndReadL = this.zzEndRead;
/* 524 */           if (eof) {
/* 525 */             int i = -1;
/*     */             
/*     */             break;
/*     */           } 
/* 529 */           zzInput = zzBufferL[zzCurrentPosL++]; }
/*     */ 
/*     */         
/* 532 */         int zzNext = zzTransL[zzRowMapL[this.zzState] + zzCMapL[zzInput]];
/* 533 */         if (zzNext == -1)
/* 534 */           break;  this.zzState = zzNext;
/*     */         
/* 536 */         int zzAttributes = zzAttrL[this.zzState];
/* 537 */         if ((zzAttributes & 0x1) == 1) {
/* 538 */           zzAction = this.zzState;
/* 539 */           zzMarkedPosL = zzCurrentPosL;
/* 540 */           if ((zzAttributes & 0x8) == 8) {
/*     */             break;
/*     */           }
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 547 */       this.zzMarkedPos = zzMarkedPosL;
/*     */       
/* 549 */       switch ((zzAction < 0) ? zzAction : ZZ_ACTION[zzAction]) {
/*     */         case 2:
/*     */         case 4:
/*     */           continue;
/*     */         
/*     */         case 3:
/* 555 */           return unescape(yytext().substring(1, yytext().length() - 1));
/*     */         case 5:
/*     */           continue;
/*     */         case 1:
/* 559 */           return unescape(yytext());
/*     */         case 6:
/*     */           continue;
/*     */       } 
/* 563 */       if (zzInput == -1 && this.zzStartRead == this.zzCurrentPos) {
/* 564 */         this.zzAtEOF = true;
/* 565 */         return null;
/*     */       } 
/*     */       
/* 568 */       zzScanError(1);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/Ostermiller/util/BrowserCommandLexer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */