/*     */ package com.Ostermiller.util;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ExcelCSVLexer
/*     */ {
/*     */   public static final int YYEOF = -1;
/*     */   private static final int ZZ_BUFFERSIZE = 16384;
/*     */   public static final int BEFORE = 1;
/*     */   public static final int YYINITIAL = 0;
/*     */   public static final int COMMENT = 3;
/*     */   public static final int AFTER = 2;
/*     */   private static final String ZZ_CMAP_PACKED = "\n\000\001\002\002\000\001\001\024\000\001\004\t\000\001\003ￓ\000";
/* 105 */   private static final char[] ZZ_CMAP = zzUnpackCMap("\n\000\001\002\002\000\001\001\024\000\001\004\t\000\001\003ￓ\000");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 110 */   private static final int[] ZZ_ACTION = zzUnpackAction();
/*     */ 
/*     */   
/*     */   private static final String ZZ_ACTION_PACKED_0 = "\002\000\002\001\001\002\002\003\001\004\001\005\001\006\002\007\001\b\001\t\001\001\001\n\001\001\001\013\001\f";
/*     */ 
/*     */   
/*     */   private static int[] zzUnpackAction() {
/* 117 */     int[] result = new int[19];
/* 118 */     int offset = 0;
/* 119 */     offset = zzUnpackAction("\002\000\002\001\001\002\002\003\001\004\001\005\001\006\002\007\001\b\001\t\001\001\001\n\001\001\001\013\001\f", offset, result);
/* 120 */     return result;
/*     */   }
/*     */   
/*     */   private static int zzUnpackAction(String packed, int offset, int[] result) {
/* 124 */     int i = 0;
/* 125 */     int j = offset;
/* 126 */     int l = packed.length();
/* 127 */     while (i < l) {
/* 128 */       int count = packed.charAt(i++);
/* 129 */       int value = packed.charAt(i++); 
/* 130 */       do { result[j++] = value; } while (--count > 0);
/*     */     } 
/* 132 */     return j;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 139 */   private static final int[] ZZ_ROWMAP = zzUnpackRowMap();
/*     */ 
/*     */   
/*     */   private static final String ZZ_ROWMAP_PACKED_0 = "\000\000\000\005\000\n\000\017\000\024\000\031\000\036\000\036\000#\000(\000-\000\036\000\036\0002\0007\000\036\000<\000A\000F";
/*     */ 
/*     */ 
/*     */   
/*     */   private static int[] zzUnpackRowMap() {
/* 147 */     int[] result = new int[19];
/* 148 */     int offset = 0;
/* 149 */     offset = zzUnpackRowMap("\000\000\000\005\000\n\000\017\000\024\000\031\000\036\000\036\000#\000(\000-\000\036\000\036\0002\0007\000\036\000<\000A\000F", offset, result);
/* 150 */     return result;
/*     */   }
/*     */   
/*     */   private static int zzUnpackRowMap(String packed, int offset, int[] result) {
/* 154 */     int i = 0;
/* 155 */     int j = offset;
/* 156 */     int l = packed.length();
/* 157 */     while (i < l) {
/* 158 */       int high = packed.charAt(i++) << 16;
/* 159 */       result[j++] = high | packed.charAt(i++);
/*     */     } 
/* 161 */     return j;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 167 */   private static final int[] ZZ_TRANS = zzUnpackTrans();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String ZZ_TRANS_PACKED_0 = "\001\005\001\006\001\007\001\b\001\t\001\n\001\013\001\f\001\r\001\016\001\017\001\006\001\007\001\020\001\017\001\021\001\006\001\007\002\021\001\005\003\000\001\005\002\000\001\007\007\000\004\t\001\022\001\n\003\000\001\n\002\000\001\f\002\000\004\016\001\023\001\017\003\000\001\017\001\021\002\000\002\021\004\000\001\t\004\000\001\016";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int[] zzUnpackTrans() {
/* 178 */     int[] result = new int[75];
/* 179 */     int offset = 0;
/* 180 */     offset = zzUnpackTrans("\001\005\001\006\001\007\001\b\001\t\001\n\001\013\001\f\001\r\001\016\001\017\001\006\001\007\001\020\001\017\001\021\001\006\001\007\002\021\001\005\003\000\001\005\002\000\001\007\007\000\004\t\001\022\001\n\003\000\001\n\002\000\001\f\002\000\004\016\001\023\001\017\003\000\001\017\001\021\002\000\002\021\004\000\001\t\004\000\001\016", offset, result);
/* 181 */     return result;
/*     */   }
/*     */   
/*     */   private static int zzUnpackTrans(String packed, int offset, int[] result) {
/* 185 */     int i = 0;
/* 186 */     int j = offset;
/* 187 */     int l = packed.length();
/* 188 */     while (i < l) {
/* 189 */       int count = packed.charAt(i++);
/* 190 */       int value = packed.charAt(i++);
/* 191 */       value--; 
/* 192 */       do { result[j++] = value; } while (--count > 0);
/*     */     } 
/* 194 */     return j;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 202 */   private char[] zzcmap_instance = ZZ_CMAP;
/*     */   
/*     */   private static final int ZZ_UNKNOWN_ERROR = 0;
/*     */   
/*     */   private static final int ZZ_NO_MATCH = 1;
/*     */   
/*     */   private static final int ZZ_PUSHBACK_2BIG = 2;
/*     */   
/* 210 */   private static final String[] ZZ_ERROR_MSG = new String[] {
/* 211 */       "Unkown internal scanner error", 
/* 212 */       "Error: could not match input", 
/* 213 */       "Error: pushback value was too large"
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 219 */   private static final int[] ZZ_ATTRIBUTE = zzUnpackAttribute();
/*     */   private static final String ZZ_ATTRIBUTE_PACKED_0 = "\002\000\004\001\002\t\003\001\002\t\002\001\001\t\003\001";
/*     */   private Reader zzReader;
/*     */   private int zzState;
/*     */   
/*     */   private static int[] zzUnpackAttribute() {
/* 225 */     int[] result = new int[19];
/* 226 */     int offset = 0;
/* 227 */     offset = zzUnpackAttribute("\002\000\004\001\002\t\003\001\002\t\002\001\001\t\003\001", offset, result);
/* 228 */     return result;
/*     */   }
/*     */   
/*     */   private static int zzUnpackAttribute(String packed, int offset, int[] result) {
/* 232 */     int i = 0;
/* 233 */     int j = offset;
/* 234 */     int l = packed.length();
/* 235 */     while (i < l) {
/* 236 */       int count = packed.charAt(i++);
/* 237 */       int value = packed.charAt(i++); 
/* 238 */       do { result[j++] = value; } while (--count > 0);
/*     */     } 
/* 240 */     return j;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 250 */   private int zzLexicalState = 0;
/*     */ 
/*     */ 
/*     */   
/* 254 */   private char[] zzBuffer = new char[16384];
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int zzMarkedPos;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int zzPushbackPos;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int zzCurrentPos;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int zzStartRead;
/*     */ 
/*     */ 
/*     */   
/*     */   private int zzEndRead;
/*     */ 
/*     */ 
/*     */   
/*     */   private int yyline;
/*     */ 
/*     */ 
/*     */   
/*     */   private int yychar;
/*     */ 
/*     */ 
/*     */   
/*     */   private int yycolumn;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean zzAtBOL = true;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean zzAtEOF;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/*     */     try {
/*     */       InputStream in;
/* 306 */       if (args.length > 0) {
/* 307 */         File f = new File(args[0]);
/* 308 */         if (f.exists()) {
/* 309 */           if (f.canRead()) {
/* 310 */             in = new FileInputStream(f);
/*     */           } else {
/* 312 */             throw new IOException("Could not open " + args[0]);
/*     */           } 
/*     */         } else {
/* 315 */           throw new IOException("Could not find " + args[0]);
/*     */         } 
/*     */       } else {
/* 318 */         in = System.in;
/*     */       } 
/* 320 */       ExcelCSVLexer shredder = new ExcelCSVLexer(in);
/*     */       String t;
/* 322 */       while ((t = shredder.getNextToken()) != null) {
/* 323 */         System.out.println(shredder.getLineNumber() + " " + t);
/*     */       }
/* 325 */     } catch (IOException e) {
/* 326 */       System.out.println(e.getMessage());
/*     */     } 
/*     */   }
/*     */   
/* 330 */   private char delimiter = ',';
/* 331 */   private char quote = '"';
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void ensureCharacterMapIsInstance() {
/* 340 */     if (ZZ_CMAP == this.zzcmap_instance) {
/* 341 */       this.zzcmap_instance = new char[ZZ_CMAP.length];
/* 342 */       System.arraycopy(ZZ_CMAP, 0, this.zzcmap_instance, 0, ZZ_CMAP.length);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean charIsSafe(char c) {
/* 358 */     return !(this.zzcmap_instance[c] != ZZ_CMAP[97] && this.zzcmap_instance[c] != ZZ_CMAP[9]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateCharacterClasses(char oldChar, char newChar) {
/* 373 */     ensureCharacterMapIsInstance();
/*     */     
/* 375 */     this.zzcmap_instance[newChar] = this.zzcmap_instance[oldChar];
/*     */     
/* 377 */     switch (oldChar) {
/*     */ 
/*     */       
/*     */       case '"':
/*     */       case ',':
/* 382 */         this.zzcmap_instance[oldChar] = ZZ_CMAP[97];
/*     */         return;
/*     */     } 
/*     */ 
/*     */     
/* 387 */     this.zzcmap_instance[oldChar] = ZZ_CMAP[oldChar];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void changeDelimiter(char newDelim) throws BadDelimiterException {
/* 404 */     if (newDelim == this.delimiter)
/* 405 */       return;  if (!charIsSafe(newDelim)) {
/* 406 */       throw new BadDelimiterException(String.valueOf(newDelim) + " is not a safe delimiter.");
/*     */     }
/* 408 */     updateCharacterClasses(this.delimiter, newDelim);
/*     */     
/* 410 */     this.delimiter = newDelim;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void changeQuote(char newQuote) throws BadQuoteException {
/* 425 */     if (newQuote == this.quote)
/* 426 */       return;  if (!charIsSafe(newQuote)) {
/* 427 */       throw new BadQuoteException(String.valueOf(newQuote) + " is not a safe quote.");
/*     */     }
/* 429 */     updateCharacterClasses(this.quote, newQuote);
/*     */     
/* 431 */     this.quote = newQuote;
/*     */   }
/*     */   
/*     */   private String unescape(String s) {
/* 435 */     if (s.indexOf('"', 1) == s.length() - 1) {
/* 436 */       return s.substring(1, s.length() - 1);
/*     */     }
/* 438 */     StringBuffer sb = new StringBuffer(s.length());
/* 439 */     for (int i = 1; i < s.length() - 1; i++) {
/* 440 */       char c = s.charAt(i);
/* 441 */       char c1 = s.charAt(i + 1);
/* 442 */       if (c == '"' && c1 == '"') {
/* 443 */         i++;
/* 444 */         sb.append("\"");
/*     */       } else {
/* 446 */         sb.append(c);
/*     */       } 
/*     */     } 
/* 449 */     return sb.toString();
/*     */   }
/*     */   
/* 452 */   private String commentDelims = "";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCommentStart(String commentDelims) {
/* 469 */     this.commentDelims = commentDelims;
/*     */   }
/*     */   
/* 472 */   private int addLine = 1;
/* 473 */   private int lines = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLineNumber() {
/* 488 */     return this.lines;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ExcelCSVLexer(Reader in) {
/* 499 */     this.zzReader = in;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   ExcelCSVLexer(InputStream in) {
/* 509 */     this(new InputStreamReader(in));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static char[] zzUnpackCMap(String packed) {
/* 519 */     char[] map = new char[65536];
/* 520 */     int i = 0;
/* 521 */     int j = 0;
/* 522 */     while (i < 18) {
/* 523 */       int count = packed.charAt(i++);
/* 524 */       char value = packed.charAt(i++); 
/* 525 */       do { map[j++] = value; } while (--count > 0);
/*     */     } 
/* 527 */     return map;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean zzRefill() throws IOException {
/* 541 */     if (this.zzStartRead > 0) {
/* 542 */       System.arraycopy(this.zzBuffer, this.zzStartRead, 
/* 543 */           this.zzBuffer, 0, 
/* 544 */           this.zzEndRead - this.zzStartRead);
/*     */ 
/*     */       
/* 547 */       this.zzEndRead -= this.zzStartRead;
/* 548 */       this.zzCurrentPos -= this.zzStartRead;
/* 549 */       this.zzMarkedPos -= this.zzStartRead;
/* 550 */       this.zzPushbackPos -= this.zzStartRead;
/* 551 */       this.zzStartRead = 0;
/*     */     } 
/*     */ 
/*     */     
/* 555 */     if (this.zzCurrentPos >= this.zzBuffer.length) {
/*     */       
/* 557 */       char[] newBuffer = new char[this.zzCurrentPos * 2];
/* 558 */       System.arraycopy(this.zzBuffer, 0, newBuffer, 0, this.zzBuffer.length);
/* 559 */       this.zzBuffer = newBuffer;
/*     */     } 
/*     */ 
/*     */     
/* 563 */     int numRead = this.zzReader.read(this.zzBuffer, this.zzEndRead, 
/* 564 */         this.zzBuffer.length - this.zzEndRead);
/*     */     
/* 566 */     if (numRead < 0) {
/* 567 */       return true;
/*     */     }
/*     */     
/* 570 */     this.zzEndRead += numRead;
/* 571 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void yyclose() throws IOException {
/* 580 */     this.zzAtEOF = true;
/* 581 */     this.zzEndRead = this.zzStartRead;
/*     */     
/* 583 */     if (this.zzReader != null) {
/* 584 */       this.zzReader.close();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void yyreset(Reader reader) {
/* 599 */     this.zzReader = reader;
/* 600 */     this.zzAtBOL = true;
/* 601 */     this.zzAtEOF = false;
/* 602 */     this.zzEndRead = this.zzStartRead = 0;
/* 603 */     this.zzCurrentPos = this.zzMarkedPos = this.zzPushbackPos = 0;
/* 604 */     this.yyline = this.yychar = this.yycolumn = 0;
/* 605 */     this.zzLexicalState = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int yystate() {
/* 613 */     return this.zzLexicalState;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void yybegin(int newState) {
/* 623 */     this.zzLexicalState = newState;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String yytext() {
/* 631 */     return new String(this.zzBuffer, this.zzStartRead, this.zzMarkedPos - this.zzStartRead);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final char yycharat(int pos) {
/* 647 */     return this.zzBuffer[this.zzStartRead + pos];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int yylength() {
/* 655 */     return this.zzMarkedPos - this.zzStartRead;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void zzScanError(int errorCode) {
/*     */     String message;
/*     */     try {
/* 676 */       message = ZZ_ERROR_MSG[errorCode];
/*     */     }
/* 678 */     catch (ArrayIndexOutOfBoundsException e) {
/* 679 */       message = ZZ_ERROR_MSG[0];
/*     */     } 
/*     */     
/* 682 */     throw new Error(message);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void yypushback(int number) {
/* 695 */     if (number > yylength()) {
/* 696 */       zzScanError(2);
/*     */     }
/* 698 */     this.zzMarkedPos -= number;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getNextToken() throws IOException {
/* 716 */     int zzEndReadL = this.zzEndRead;
/* 717 */     char[] zzBufferL = this.zzBuffer;
/* 718 */     char[] zzCMapL = this.zzcmap_instance;
/*     */     
/* 720 */     int[] zzTransL = ZZ_TRANS;
/* 721 */     int[] zzRowMapL = ZZ_ROWMAP;
/* 722 */     int[] zzAttrL = ZZ_ATTRIBUTE; while (true) {
/*     */       int zzInput;
/*     */       String text;
/* 725 */       int zzMarkedPosL = this.zzMarkedPos;
/*     */       
/* 727 */       int zzAction = -1;
/*     */       
/* 729 */       int zzCurrentPosL = this.zzCurrentPos = this.zzStartRead = zzMarkedPosL;
/*     */       
/* 731 */       this.zzState = this.zzLexicalState;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       while (true) {
/* 737 */         if (zzCurrentPosL < zzEndReadL)
/* 738 */         { zzInput = zzBufferL[zzCurrentPosL++]; }
/* 739 */         else { if (this.zzAtEOF) {
/* 740 */             int i = -1;
/*     */             
/*     */             break;
/*     */           } 
/*     */           
/* 745 */           this.zzCurrentPos = zzCurrentPosL;
/* 746 */           this.zzMarkedPos = zzMarkedPosL;
/* 747 */           boolean eof = zzRefill();
/*     */           
/* 749 */           zzCurrentPosL = this.zzCurrentPos;
/* 750 */           zzMarkedPosL = this.zzMarkedPos;
/* 751 */           zzBufferL = this.zzBuffer;
/* 752 */           zzEndReadL = this.zzEndRead;
/* 753 */           if (eof) {
/* 754 */             int i = -1;
/*     */             
/*     */             break;
/*     */           } 
/* 758 */           zzInput = zzBufferL[zzCurrentPosL++]; }
/*     */ 
/*     */         
/* 761 */         int zzNext = zzTransL[zzRowMapL[this.zzState] + zzCMapL[zzInput]];
/* 762 */         if (zzNext == -1)
/* 763 */           break;  this.zzState = zzNext;
/*     */         
/* 765 */         int zzAttributes = zzAttrL[this.zzState];
/* 766 */         if ((zzAttributes & 0x1) == 1) {
/* 767 */           zzAction = this.zzState;
/* 768 */           zzMarkedPosL = zzCurrentPosL;
/* 769 */           if ((zzAttributes & 0x8) == 8) {
/*     */             break;
/*     */           }
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 776 */       this.zzMarkedPos = zzMarkedPosL;
/*     */       
/* 778 */       switch ((zzAction < 0) ? zzAction : ZZ_ACTION[zzAction]) {
/*     */         case 2:
/* 780 */           this.lines += this.addLine;
/* 781 */           this.addLine = 0;
/* 782 */           text = yytext();
/* 783 */           if (this.commentDelims.indexOf(text.charAt(0)) == -1) {
/* 784 */             yybegin(2);
/* 785 */             return text;
/*     */           } 
/* 787 */           yybegin(3);
/*     */           continue;
/*     */         case 13:
/*     */           continue;
/*     */         case 8:
/* 792 */           yybegin(1);
/* 793 */           return "";
/*     */         case 14:
/*     */           continue;
/*     */         case 3:
/* 797 */           this.addLine++;
/* 798 */           yybegin(0); continue;
/*     */         case 15:
/*     */           continue;
/*     */         case 4:
/* 802 */           this.lines += this.addLine;
/* 803 */           this.addLine = 0;
/* 804 */           yybegin(1);
/* 805 */           return "";
/*     */         case 16:
/*     */           continue;
/*     */         case 11:
/* 809 */           this.lines += this.addLine;
/* 810 */           this.addLine = 0;
/* 811 */           yybegin(2);
/* 812 */           return unescape(yytext());
/*     */         case 17:
/*     */           continue;
/*     */         case 6:
/* 816 */           yybegin(2);
/* 817 */           return yytext();
/*     */         case 18:
/*     */           continue;
/*     */         case 7:
/* 821 */           yybegin(0);
/* 822 */           this.addLine++;
/* 823 */           return "";
/*     */         case 19:
/*     */           continue;
/*     */         case 5:
/* 827 */           this.lines += this.addLine;
/* 828 */           this.addLine = 0;
/* 829 */           yybegin(0);
/* 830 */           return yytext();
/*     */         case 20:
/*     */           continue;
/*     */         case 10:
/* 834 */           yybegin(1); continue;
/*     */         case 21:
/*     */           continue;
/*     */         case 12:
/* 838 */           yybegin(2);
/* 839 */           return unescape(yytext());
/*     */         case 22:
/*     */           continue;
/*     */         case 9:
/* 843 */           yybegin(0);
/* 844 */           return yytext();
/*     */         
/*     */         case 23:
/*     */         case 1:
/*     */         case 24:
/*     */           continue;
/*     */       } 
/*     */       
/* 852 */       if (zzInput == -1 && this.zzStartRead == this.zzCurrentPos) {
/* 853 */         this.zzAtEOF = true;
/* 854 */         switch (this.zzLexicalState) {
/*     */           case 1:
/* 856 */             yybegin(0);
/* 857 */             this.addLine++;
/* 858 */             return "";
/*     */           case 20:
/*     */             continue;
/*     */         } 
/* 862 */         return null;
/*     */       } 
/*     */ 
/*     */       
/* 866 */       zzScanError(1);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/Ostermiller/util/ExcelCSVLexer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */