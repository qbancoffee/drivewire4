/*     */ package com.Ostermiller.util;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CSVLexer
/*     */ {
/*     */   public static final int YYEOF = -1;
/*     */   private static final int ZZ_BUFFERSIZE = 16384;
/*     */   public static final int BEFORE = 1;
/*     */   public static final int YYINITIAL = 0;
/*     */   public static final int COMMENT = 3;
/*     */   public static final int AFTER = 2;
/*     */   private static final String ZZ_CMAP_PACKED = "\t\000\001\001\001\003\001\000\001\001\001\002\022\000\001\001\001\000\001\005\t\000\001\004/\000\001\006ﾣ\000";
/* 102 */   private static final char[] ZZ_CMAP = zzUnpackCMap("\t\000\001\001\001\003\001\000\001\001\001\002\022\000\001\001\001\000\001\005\t\000\001\004/\000\001\006ﾣ\000");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 107 */   private static final int[] ZZ_ACTION = zzUnpackAction();
/*     */ 
/*     */   
/*     */   private static final String ZZ_ACTION_PACKED_0 = "\001\000\003\001\001\002\001\003\002\004\001\005\001\006\001\007\001\001\002\b\001\t\001\n\002\001\001\013\001\001\002\000\001\f\002\000\001\r\001\000";
/*     */ 
/*     */ 
/*     */   
/*     */   private static int[] zzUnpackAction() {
/* 115 */     int[] result = new int[27];
/* 116 */     int offset = 0;
/* 117 */     offset = zzUnpackAction("\001\000\003\001\001\002\001\003\002\004\001\005\001\006\001\007\001\001\002\b\001\t\001\n\002\001\001\013\001\001\002\000\001\f\002\000\001\r\001\000", offset, result);
/* 118 */     return result;
/*     */   }
/*     */   
/*     */   private static int zzUnpackAction(String packed, int offset, int[] result) {
/* 122 */     int i = 0;
/* 123 */     int j = offset;
/* 124 */     int l = packed.length();
/* 125 */     while (i < l) {
/* 126 */       int count = packed.charAt(i++);
/* 127 */       int value = packed.charAt(i++); 
/* 128 */       do { result[j++] = value; } while (--count > 0);
/*     */     } 
/* 130 */     return j;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 137 */   private static final int[] ZZ_ROWMAP = zzUnpackRowMap();
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String ZZ_ROWMAP_PACKED_0 = "\000\000\000\007\000\016\000\025\000\034\000#\000*\0001\0001\0008\000?\000F\000M\0001\0001\000T\000[\000b\0001\000i\000\034\000#\0001\000p\000?\0001\000w";
/*     */ 
/*     */ 
/*     */   
/*     */   private static int[] zzUnpackRowMap() {
/* 146 */     int[] result = new int[27];
/* 147 */     int offset = 0;
/* 148 */     offset = zzUnpackRowMap("\000\000\000\007\000\016\000\025\000\034\000#\000*\0001\0001\0008\000?\000F\000M\0001\0001\000T\000[\000b\0001\000i\000\034\000#\0001\000p\000?\0001\000w", offset, result);
/* 149 */     return result;
/*     */   }
/*     */   
/*     */   private static int zzUnpackRowMap(String packed, int offset, int[] result) {
/* 153 */     int i = 0;
/* 154 */     int j = offset;
/* 155 */     int l = packed.length();
/* 156 */     while (i < l) {
/* 157 */       int high = packed.charAt(i++) << 16;
/* 158 */       result[j++] = high | packed.charAt(i++);
/*     */     } 
/* 160 */     return j;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 166 */   private static final int[] ZZ_TRANS = zzUnpackTrans();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String ZZ_TRANS_PACKED_0 = "\001\005\001\006\001\007\001\b\001\t\001\n\001\005\001\013\001\f\001\r\001\016\001\017\001\020\001\013\001\021\001\022\001\007\001\b\001\023\002\021\001\024\001\004\001\007\001\b\003\024\001\005\001\025\003\000\002\005\001\000\001\026\001\007\001\b\006\000\001\b\n\000\005\n\001\027\001\030\001\013\001\031\003\000\002\013\001\000\001\f\b\000\001\016\003\000\005\020\001\032\001\033\002\021\003\000\003\021\001\022\001\007\001\b\001\000\002\021\002\024\002\000\003\024\007\n\007\020";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int[] zzUnpackTrans() {
/* 179 */     int[] result = new int[126];
/* 180 */     int offset = 0;
/* 181 */     offset = zzUnpackTrans("\001\005\001\006\001\007\001\b\001\t\001\n\001\005\001\013\001\f\001\r\001\016\001\017\001\020\001\013\001\021\001\022\001\007\001\b\001\023\002\021\001\024\001\004\001\007\001\b\003\024\001\005\001\025\003\000\002\005\001\000\001\026\001\007\001\b\006\000\001\b\n\000\005\n\001\027\001\030\001\013\001\031\003\000\002\013\001\000\001\f\b\000\001\016\003\000\005\020\001\032\001\033\002\021\003\000\003\021\001\022\001\007\001\b\001\000\002\021\002\024\002\000\003\024\007\n\007\020", offset, result);
/* 182 */     return result;
/*     */   }
/*     */   
/*     */   private static int zzUnpackTrans(String packed, int offset, int[] result) {
/* 186 */     int i = 0;
/* 187 */     int j = offset;
/* 188 */     int l = packed.length();
/* 189 */     while (i < l) {
/* 190 */       int count = packed.charAt(i++);
/* 191 */       int value = packed.charAt(i++);
/* 192 */       value--; 
/* 193 */       do { result[j++] = value; } while (--count > 0);
/*     */     } 
/* 195 */     return j;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 203 */   private char[] zzcmap_instance = ZZ_CMAP;
/*     */   
/*     */   private static final int ZZ_UNKNOWN_ERROR = 0;
/*     */   
/*     */   private static final int ZZ_NO_MATCH = 1;
/*     */   
/*     */   private static final int ZZ_PUSHBACK_2BIG = 2;
/*     */   
/* 211 */   private static final String[] ZZ_ERROR_MSG = new String[] {
/* 212 */       "Unkown internal scanner error", 
/* 213 */       "Error: could not match input", 
/* 214 */       "Error: pushback value was too large"
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 220 */   private static final int[] ZZ_ATTRIBUTE = zzUnpackAttribute();
/*     */   
/*     */   private static final String ZZ_ATTRIBUTE_PACKED_0 = "\001\000\006\001\002\t\004\001\002\t\003\001\001\t\001\001\002\000\001\t\002\000\001\t\001\000";
/*     */   private Reader zzReader;
/*     */   private int zzState;
/*     */   
/*     */   private static int[] zzUnpackAttribute() {
/* 227 */     int[] result = new int[27];
/* 228 */     int offset = 0;
/* 229 */     offset = zzUnpackAttribute("\001\000\006\001\002\t\004\001\002\t\003\001\001\t\001\001\002\000\001\t\002\000\001\t\001\000", offset, result);
/* 230 */     return result;
/*     */   }
/*     */   
/*     */   private static int zzUnpackAttribute(String packed, int offset, int[] result) {
/* 234 */     int i = 0;
/* 235 */     int j = offset;
/* 236 */     int l = packed.length();
/* 237 */     while (i < l) {
/* 238 */       int count = packed.charAt(i++);
/* 239 */       int value = packed.charAt(i++); 
/* 240 */       do { result[j++] = value; } while (--count > 0);
/*     */     } 
/* 242 */     return j;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 252 */   private int zzLexicalState = 0;
/*     */ 
/*     */ 
/*     */   
/* 256 */   private char[] zzBuffer = new char[16384];
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int zzMarkedPos;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int zzPushbackPos;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int zzCurrentPos;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int zzStartRead;
/*     */ 
/*     */ 
/*     */   
/*     */   private int zzEndRead;
/*     */ 
/*     */ 
/*     */   
/*     */   private int yyline;
/*     */ 
/*     */ 
/*     */   
/*     */   private int yychar;
/*     */ 
/*     */ 
/*     */   
/*     */   private int yycolumn;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean zzAtBOL = true;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean zzAtEOF;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/*     */     try {
/*     */       InputStream in;
/* 308 */       if (args.length > 0) {
/* 309 */         File f = new File(args[0]);
/* 310 */         if (f.exists()) {
/* 311 */           if (f.canRead()) {
/* 312 */             in = new FileInputStream(f);
/*     */           } else {
/* 314 */             throw new IOException("Could not open " + args[0]);
/*     */           } 
/*     */         } else {
/* 317 */           throw new IOException("Could not find " + args[0]);
/*     */         } 
/*     */       } else {
/* 320 */         in = System.in;
/*     */       } 
/* 322 */       CSVLexer shredder = new CSVLexer(in);
/* 323 */       shredder.setCommentStart("#;!");
/* 324 */       shredder.setEscapes("nrtf", "\n\r\t\f");
/*     */       String t;
/* 326 */       while ((t = shredder.getNextToken()) != null) {
/* 327 */         System.out.println(shredder.getLineNumber() + " " + t);
/*     */       }
/* 329 */     } catch (IOException e) {
/* 330 */       System.out.println(e.getMessage());
/*     */     } 
/*     */   }
/*     */   
/* 334 */   private char delimiter = ',';
/* 335 */   private char quote = '"';
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void ensureCharacterMapIsInstance() {
/* 345 */     if (ZZ_CMAP == this.zzcmap_instance) {
/* 346 */       this.zzcmap_instance = new char[ZZ_CMAP.length];
/* 347 */       System.arraycopy(ZZ_CMAP, 0, this.zzcmap_instance, 0, ZZ_CMAP.length);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean charIsSafe(char c) {
/* 363 */     return !(this.zzcmap_instance[c] != ZZ_CMAP[97] && this.zzcmap_instance[c] != ZZ_CMAP[9]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void updateCharacterClasses(char oldChar, char newChar) {
/* 378 */     ensureCharacterMapIsInstance();
/*     */     
/* 380 */     this.zzcmap_instance[newChar] = this.zzcmap_instance[oldChar];
/*     */     
/* 382 */     switch (oldChar) {
/*     */ 
/*     */       
/*     */       case '"':
/*     */       case ',':
/* 387 */         this.zzcmap_instance[oldChar] = ZZ_CMAP[97];
/*     */         return;
/*     */     } 
/*     */ 
/*     */     
/* 392 */     this.zzcmap_instance[oldChar] = ZZ_CMAP[oldChar];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void changeDelimiter(char newDelim) throws BadDelimiterException {
/* 409 */     if (newDelim == this.delimiter)
/* 410 */       return;  if (!charIsSafe(newDelim)) {
/* 411 */       throw new BadDelimiterException(String.valueOf(newDelim) + " is not a safe delimiter.");
/*     */     }
/* 413 */     updateCharacterClasses(this.delimiter, newDelim);
/*     */     
/* 415 */     this.delimiter = newDelim;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void changeQuote(char newQuote) throws BadQuoteException {
/* 430 */     if (newQuote == this.quote)
/* 431 */       return;  if (!charIsSafe(newQuote)) {
/* 432 */       throw new BadQuoteException(String.valueOf(newQuote) + " is not a safe quote.");
/*     */     }
/* 434 */     updateCharacterClasses(this.quote, newQuote);
/*     */     
/* 436 */     this.quote = newQuote;
/*     */   }
/*     */   
/* 439 */   private String escapes = "";
/* 440 */   private String replacements = "";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEscapes(String escapes, String replacements) {
/* 462 */     int length = escapes.length();
/* 463 */     if (replacements.length() < length) {
/* 464 */       length = replacements.length();
/*     */     }
/* 466 */     this.escapes = escapes.substring(0, length);
/* 467 */     this.replacements = replacements.substring(0, length);
/*     */   }
/*     */   
/*     */   private String unescape(String s) {
/* 471 */     if (s.indexOf('\\') == -1) {
/* 472 */       return s.substring(1, s.length() - 1);
/*     */     }
/* 474 */     StringBuffer sb = new StringBuffer(s.length());
/* 475 */     for (int i = 1; i < s.length() - 1; i++) {
/* 476 */       char c = s.charAt(i);
/* 477 */       if (c == '\\')
/* 478 */       { char c1 = s.charAt(++i);
/*     */         
/* 480 */         if (c1 == '\\' || c1 == '"')
/* 481 */         { sb.append(c1); }
/* 482 */         else { int index; if ((index = this.escapes.indexOf(c1)) != -1) {
/* 483 */             sb.append(this.replacements.charAt(index));
/*     */           } else {
/* 485 */             sb.append(c1);
/*     */           }  }
/*     */          }
/* 488 */       else { sb.append(c); }
/*     */     
/*     */     } 
/* 491 */     return sb.toString();
/*     */   }
/*     */   
/* 494 */   private String commentDelims = "";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setCommentStart(String commentDelims) {
/* 511 */     this.commentDelims = commentDelims;
/*     */   }
/*     */   
/* 514 */   private int addLine = 1;
/* 515 */   private int lines = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int getLineNumber() {
/* 530 */     return this.lines;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CSVLexer(Reader in) {
/* 541 */     this.zzReader = in;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CSVLexer(InputStream in) {
/* 551 */     this(new InputStreamReader(in));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static char[] zzUnpackCMap(String packed) {
/* 561 */     char[] map = new char[65536];
/* 562 */     int i = 0;
/* 563 */     int j = 0;
/* 564 */     while (i < 30) {
/* 565 */       int count = packed.charAt(i++);
/* 566 */       char value = packed.charAt(i++); 
/* 567 */       do { map[j++] = value; } while (--count > 0);
/*     */     } 
/* 569 */     return map;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean zzRefill() throws IOException {
/* 583 */     if (this.zzStartRead > 0) {
/* 584 */       System.arraycopy(this.zzBuffer, this.zzStartRead, 
/* 585 */           this.zzBuffer, 0, 
/* 586 */           this.zzEndRead - this.zzStartRead);
/*     */ 
/*     */       
/* 589 */       this.zzEndRead -= this.zzStartRead;
/* 590 */       this.zzCurrentPos -= this.zzStartRead;
/* 591 */       this.zzMarkedPos -= this.zzStartRead;
/* 592 */       this.zzPushbackPos -= this.zzStartRead;
/* 593 */       this.zzStartRead = 0;
/*     */     } 
/*     */ 
/*     */     
/* 597 */     if (this.zzCurrentPos >= this.zzBuffer.length) {
/*     */       
/* 599 */       char[] newBuffer = new char[this.zzCurrentPos * 2];
/* 600 */       System.arraycopy(this.zzBuffer, 0, newBuffer, 0, this.zzBuffer.length);
/* 601 */       this.zzBuffer = newBuffer;
/*     */     } 
/*     */ 
/*     */     
/* 605 */     int numRead = this.zzReader.read(this.zzBuffer, this.zzEndRead, 
/* 606 */         this.zzBuffer.length - this.zzEndRead);
/*     */     
/* 608 */     if (numRead < 0) {
/* 609 */       return true;
/*     */     }
/*     */     
/* 612 */     this.zzEndRead += numRead;
/* 613 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void yyclose() throws IOException {
/* 622 */     this.zzAtEOF = true;
/* 623 */     this.zzEndRead = this.zzStartRead;
/*     */     
/* 625 */     if (this.zzReader != null) {
/* 626 */       this.zzReader.close();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void yyreset(Reader reader) {
/* 641 */     this.zzReader = reader;
/* 642 */     this.zzAtBOL = true;
/* 643 */     this.zzAtEOF = false;
/* 644 */     this.zzEndRead = this.zzStartRead = 0;
/* 645 */     this.zzCurrentPos = this.zzMarkedPos = this.zzPushbackPos = 0;
/* 646 */     this.yyline = this.yychar = this.yycolumn = 0;
/* 647 */     this.zzLexicalState = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int yystate() {
/* 655 */     return this.zzLexicalState;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final void yybegin(int newState) {
/* 665 */     this.zzLexicalState = newState;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final String yytext() {
/* 673 */     return new String(this.zzBuffer, this.zzStartRead, this.zzMarkedPos - this.zzStartRead);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final char yycharat(int pos) {
/* 689 */     return this.zzBuffer[this.zzStartRead + pos];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final int yylength() {
/* 697 */     return this.zzMarkedPos - this.zzStartRead;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void zzScanError(int errorCode) {
/*     */     String message;
/*     */     try {
/* 718 */       message = ZZ_ERROR_MSG[errorCode];
/*     */     }
/* 720 */     catch (ArrayIndexOutOfBoundsException e) {
/* 721 */       message = ZZ_ERROR_MSG[0];
/*     */     } 
/*     */     
/* 724 */     throw new Error(message);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void yypushback(int number) {
/* 737 */     if (number > yylength()) {
/* 738 */       zzScanError(2);
/*     */     }
/* 740 */     this.zzMarkedPos -= number;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getNextToken() throws IOException {
/* 758 */     int zzEndReadL = this.zzEndRead;
/* 759 */     char[] zzBufferL = this.zzBuffer;
/* 760 */     char[] zzCMapL = this.zzcmap_instance;
/*     */     
/* 762 */     int[] zzTransL = ZZ_TRANS;
/* 763 */     int[] zzRowMapL = ZZ_ROWMAP;
/* 764 */     int[] zzAttrL = ZZ_ATTRIBUTE; while (true) {
/*     */       int zzInput;
/*     */       String text;
/* 767 */       int zzMarkedPosL = this.zzMarkedPos;
/*     */       
/* 769 */       int zzAction = -1;
/*     */       
/* 771 */       int zzCurrentPosL = this.zzCurrentPos = this.zzStartRead = zzMarkedPosL;
/*     */       
/* 773 */       this.zzState = this.zzLexicalState;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       while (true) {
/* 779 */         if (zzCurrentPosL < zzEndReadL)
/* 780 */         { zzInput = zzBufferL[zzCurrentPosL++]; }
/* 781 */         else { if (this.zzAtEOF) {
/* 782 */             int i = -1;
/*     */             
/*     */             break;
/*     */           } 
/*     */           
/* 787 */           this.zzCurrentPos = zzCurrentPosL;
/* 788 */           this.zzMarkedPos = zzMarkedPosL;
/* 789 */           boolean eof = zzRefill();
/*     */           
/* 791 */           zzCurrentPosL = this.zzCurrentPos;
/* 792 */           zzMarkedPosL = this.zzMarkedPos;
/* 793 */           zzBufferL = this.zzBuffer;
/* 794 */           zzEndReadL = this.zzEndRead;
/* 795 */           if (eof) {
/* 796 */             int i = -1;
/*     */             
/*     */             break;
/*     */           } 
/* 800 */           zzInput = zzBufferL[zzCurrentPosL++]; }
/*     */ 
/*     */         
/* 803 */         int zzNext = zzTransL[zzRowMapL[this.zzState] + zzCMapL[zzInput]];
/* 804 */         if (zzNext == -1)
/* 805 */           break;  this.zzState = zzNext;
/*     */         
/* 807 */         int zzAttributes = zzAttrL[this.zzState];
/* 808 */         if ((zzAttributes & 0x1) == 1) {
/* 809 */           zzAction = this.zzState;
/* 810 */           zzMarkedPosL = zzCurrentPosL;
/* 811 */           if ((zzAttributes & 0x8) == 8) {
/*     */             break;
/*     */           }
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 818 */       this.zzMarkedPos = zzMarkedPosL;
/*     */       
/* 820 */       switch ((zzAction < 0) ? zzAction : ZZ_ACTION[zzAction]) {
/*     */         case 2:
/* 822 */           this.lines += this.addLine;
/* 823 */           this.addLine = 0;
/* 824 */           text = yytext();
/* 825 */           if (this.commentDelims.indexOf(text.charAt(0)) == -1) {
/* 826 */             yybegin(2);
/* 827 */             return text;
/*     */           } 
/* 829 */           yybegin(3);
/*     */           continue;
/*     */         case 14:
/*     */           continue;
/*     */         case 8:
/* 834 */           this.addLine++;
/* 835 */           yybegin(0);
/* 836 */           return "";
/*     */         case 15:
/*     */           continue;
/*     */         case 9:
/* 840 */           yybegin(1);
/* 841 */           return "";
/*     */         case 16:
/*     */           continue;
/*     */         case 4:
/* 845 */           this.addLine++;
/* 846 */           yybegin(0); continue;
/*     */         case 17:
/*     */           continue;
/*     */         case 5:
/* 850 */           this.lines += this.addLine;
/* 851 */           this.addLine = 0;
/* 852 */           yybegin(1);
/* 853 */           return "";
/*     */         case 18:
/*     */           continue;
/*     */         case 12:
/* 857 */           this.lines += this.addLine;
/* 858 */           this.addLine = 0;
/* 859 */           yybegin(2);
/* 860 */           return unescape(yytext());
/*     */         case 19:
/*     */           continue;
/*     */         case 7:
/* 864 */           yybegin(2);
/* 865 */           return yytext();
/*     */         case 20:
/*     */           continue;
/*     */         case 6:
/* 869 */           this.lines += this.addLine;
/* 870 */           this.addLine = 0;
/* 871 */           yybegin(0);
/* 872 */           return yytext();
/*     */         case 21:
/*     */           continue;
/*     */         case 11:
/* 876 */           yybegin(1); continue;
/*     */         case 22:
/*     */           continue;
/*     */         case 13:
/* 880 */           yybegin(2);
/* 881 */           return unescape(yytext());
/*     */         case 23:
/*     */           continue;
/*     */         case 10:
/* 885 */           yybegin(0);
/* 886 */           return yytext();
/*     */         
/*     */         case 24:
/*     */         case 1:
/*     */         case 25:
/*     */           continue;
/*     */         
/*     */         case 3:
/* 894 */           this.lines += this.addLine;
/* 895 */           this.addLine = 0;
/* 896 */           yybegin(1); continue;
/*     */         case 26:
/*     */           continue;
/*     */       } 
/* 900 */       if (zzInput == -1 && this.zzStartRead == this.zzCurrentPos) {
/* 901 */         this.zzAtEOF = true;
/* 902 */         switch (this.zzLexicalState) {
/*     */           case 1:
/* 904 */             yybegin(0);
/* 905 */             this.addLine++;
/* 906 */             return "";
/*     */           case 28:
/*     */             continue;
/*     */         } 
/* 910 */         return null;
/*     */       } 
/*     */ 
/*     */       
/* 914 */       zzScanError(1);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/Ostermiller/util/CSVLexer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */