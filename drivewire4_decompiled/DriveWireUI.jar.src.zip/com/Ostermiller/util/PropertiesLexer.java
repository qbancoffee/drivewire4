/*     */ package com.Ostermiller.util;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class PropertiesLexer
/*     */ {
/*     */   private static final int YYEOF = -1;
/*     */   private static final int ZZ_BUFFERSIZE = 16384;
/*     */   private static final int SEPARATOR = 7;
/*     */   private static final int DONE = 9;
/*     */   private static final int MID_NAME = 5;
/*     */   private static final int MID_NAME_NEW_LINE = 6;
/*     */   private static final int VALUE = 8;
/*     */   private static final int MID_VALUE = 7;
/*     */   private static final int NAME_SPACE = 4;
/*     */   private static final int YYINITIAL = 0;
/*     */   private static final int WHITE_SPACE = 2;
/*     */   private static final int LINE_END = 1;
/*     */   private static final int NAME = 3;
/*  78 */   private static final char[] ZZ_CMAP = new char[] { 
/*  79 */       '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\000', '\001', '\004', '\001', '\003', 
/*     */       
/*  81 */       '\001', '\006', '\006', 
/*  82 */       '\005', '\005', 
/*     */       
/*  84 */       '\002' };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 100 */   private static final int[] ZZ_ACTION = zzUnpackAction();
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String ZZ_ACTION_PACKED_0 = "\001\001\001\000\001\001\002\002\002\001\001\002\001\000\001\003\001\001\001\004\001\005\002\006\001\007\001\b\001\t\001\005\001\002\001\n\003\005\001\013\001\f\002\005\002\000\002\r\002\016\002\017";
/*     */ 
/*     */ 
/*     */   
/*     */   private static int[] zzUnpackAction() {
/* 109 */     int[] result = new int[36];
/* 110 */     int offset = 0;
/* 111 */     offset = zzUnpackAction("\001\001\001\000\001\001\002\002\002\001\001\002\001\000\001\003\001\001\001\004\001\005\002\006\001\007\001\b\001\t\001\005\001\002\001\n\003\005\001\013\001\f\002\005\002\000\002\r\002\016\002\017", offset, result);
/* 112 */     return result;
/*     */   }
/*     */   
/*     */   private static int zzUnpackAction(String packed, int offset, int[] result) {
/* 116 */     int i = 0;
/* 117 */     int j = offset;
/* 118 */     int l = packed.length();
/* 119 */     while (i < l) {
/* 120 */       int count = packed.charAt(i++);
/* 121 */       int value = packed.charAt(i++); 
/* 122 */       do { result[j++] = value; } while (--count > 0);
/*     */     } 
/* 124 */     return j;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 131 */   private static final int[] ZZ_ROWMAP = zzUnpackRowMap();
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String ZZ_ROWMAP_PACKED_0 = "\000\000\000\007\000\016\000\025\000\034\000#\000*\0001\0008\000?\000F\000M\000T\000[\000b\000b\000i\000b\000b\000p\000w\000~\000\000\000\000\000¡\000¨\000T\000¯\000¶\000b\000½\000b\000Ä\000b";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int[] zzUnpackRowMap() {
/* 141 */     int[] result = new int[36];
/* 142 */     int offset = 0;
/* 143 */     offset = zzUnpackRowMap("\000\000\000\007\000\016\000\025\000\034\000#\000*\0001\0008\000?\000F\000M\000T\000[\000b\000b\000i\000b\000b\000p\000w\000~\000\000\000\000\000¡\000¨\000T\000¯\000¶\000b\000½\000b\000Ä\000b", offset, result);
/* 144 */     return result;
/*     */   }
/*     */   
/*     */   private static int zzUnpackRowMap(String packed, int offset, int[] result) {
/* 148 */     int i = 0;
/* 149 */     int j = offset;
/* 150 */     int l = packed.length();
/* 151 */     while (i < l) {
/* 152 */       int high = packed.charAt(i++) << 16;
/* 153 */       result[j++] = high | packed.charAt(i++);
/*     */     } 
/* 155 */     return j;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 161 */   private static final int[] ZZ_TRANS = zzUnpackTrans();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final String ZZ_TRANS_PACKED_0 = "\001\013\001\f\001\r\001\016\001\017\001\020\001\021\002\022\001\023\001\016\001\017\002\022\001\013\001\022\001\r\001\016\001\017\001\020\001\013\001\024\001\025\001\026\001\016\001\017\001\020\002\024\001\025\001\027\001\016\001\017\001\020\001\024\001\013\001\022\001\030\001\016\001\017\001\020\002\013\001\031\001\030\001\016\001\017\001\020\001\013\001\024\001\032\001\033\001\016\001\017\002\024\001\022\001\032\001\034\001\016\001\017\002\022\007\n\001\013\001\000\001\035\003\000\001\013\001\000\001\f\004\000\001\021\003\013\002\000\002\013\004\000\001\017\t\000\003\021\002\000\002\021\002\024\001\036\002\000\002\024\001\000\001\025\005\000\003\024\001\037\001 \005\024\001!\001\"\002\024\003\013\001\037\001 \002\013\001\000\001\031\006\000\001\032\005\000\003\024\001#\001$\002\024\003\000\001#\001$\002\000\003\024\002\000\002\024\004\000\001 \006\000\001\"\006\000\001$\002\000";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static int[] zzUnpackTrans() {
/* 181 */     int[] result = new int[203];
/* 182 */     int offset = 0;
/* 183 */     offset = zzUnpackTrans("\001\013\001\f\001\r\001\016\001\017\001\020\001\021\002\022\001\023\001\016\001\017\002\022\001\013\001\022\001\r\001\016\001\017\001\020\001\013\001\024\001\025\001\026\001\016\001\017\001\020\002\024\001\025\001\027\001\016\001\017\001\020\001\024\001\013\001\022\001\030\001\016\001\017\001\020\002\013\001\031\001\030\001\016\001\017\001\020\001\013\001\024\001\032\001\033\001\016\001\017\002\024\001\022\001\032\001\034\001\016\001\017\002\022\007\n\001\013\001\000\001\035\003\000\001\013\001\000\001\f\004\000\001\021\003\013\002\000\002\013\004\000\001\017\t\000\003\021\002\000\002\021\002\024\001\036\002\000\002\024\001\000\001\025\005\000\003\024\001\037\001 \005\024\001!\001\"\002\024\003\013\001\037\001 \002\013\001\000\001\031\006\000\001\032\005\000\003\024\001#\001$\002\024\003\000\001#\001$\002\000\003\024\002\000\002\024\004\000\001 \006\000\001\"\006\000\001$\002\000", offset, result);
/* 184 */     return result;
/*     */   }
/*     */   
/*     */   private static int zzUnpackTrans(String packed, int offset, int[] result) {
/* 188 */     int i = 0;
/* 189 */     int j = offset;
/* 190 */     int l = packed.length();
/* 191 */     while (i < l) {
/* 192 */       int count = packed.charAt(i++);
/* 193 */       int value = packed.charAt(i++);
/* 194 */       value--; 
/* 195 */       do { result[j++] = value; } while (--count > 0);
/*     */     } 
/* 197 */     return j;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 205 */   private char[] zzcmap_instance = ZZ_CMAP;
/*     */   
/*     */   private static final int ZZ_UNKNOWN_ERROR = 0;
/*     */   
/*     */   private static final int ZZ_NO_MATCH = 1;
/*     */   
/*     */   private static final int ZZ_PUSHBACK_2BIG = 2;
/*     */   
/* 213 */   private static final String[] ZZ_ERROR_MSG = new String[] {
/* 214 */       "Unkown internal scanner error", 
/* 215 */       "Error: could not match input", 
/* 216 */       "Error: pushback value was too large"
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 222 */   private static final int[] ZZ_ATTRIBUTE = zzUnpackAttribute();
/*     */   
/*     */   private static final String ZZ_ATTRIBUTE_PACKED_0 = "\001\001\001\000\006\001\001\000\005\001\002\t\001\001\002\t\t\001\002\000\001\001\001\t\001\001\001\t\001\001\001\t";
/*     */   private Reader zzReader;
/*     */   private int zzState;
/*     */   
/*     */   private static int[] zzUnpackAttribute() {
/* 229 */     int[] result = new int[36];
/* 230 */     int offset = 0;
/* 231 */     offset = zzUnpackAttribute("\001\001\001\000\006\001\001\000\005\001\002\t\001\001\002\t\t\001\002\000\001\001\001\t\001\001\001\t\001\001\001\t", offset, result);
/* 232 */     return result;
/*     */   }
/*     */   
/*     */   private static int zzUnpackAttribute(String packed, int offset, int[] result) {
/* 236 */     int i = 0;
/* 237 */     int j = offset;
/* 238 */     int l = packed.length();
/* 239 */     while (i < l) {
/* 240 */       int count = packed.charAt(i++);
/* 241 */       int value = packed.charAt(i++); 
/* 242 */       do { result[j++] = value; } while (--count > 0);
/*     */     } 
/* 244 */     return j;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 254 */   private int zzLexicalState = 0;
/*     */ 
/*     */ 
/*     */   
/* 258 */   private char[] zzBuffer = new char[16384];
/*     */ 
/*     */ 
/*     */   
/*     */   private int zzMarkedPos;
/*     */ 
/*     */ 
/*     */   
/*     */   private int zzPushbackPos;
/*     */ 
/*     */ 
/*     */   
/*     */   private int zzCurrentPos;
/*     */ 
/*     */ 
/*     */   
/*     */   private int zzStartRead;
/*     */ 
/*     */   
/*     */   private int zzEndRead;
/*     */ 
/*     */   
/*     */   private int yyline;
/*     */ 
/*     */   
/*     */   private int yychar;
/*     */ 
/*     */   
/*     */   private int yycolumn;
/*     */ 
/*     */   
/*     */   private boolean zzAtBOL = true;
/*     */ 
/*     */   
/*     */   private boolean zzAtEOF;
/*     */ 
/*     */   
/*     */   private int lastToken;
/*     */ 
/*     */   
/* 298 */   private int nextState = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/*     */     try {
/*     */       InputStream in;
/* 313 */       if (args.length > 0) {
/* 314 */         File f = new File(args[0]);
/* 315 */         if (f.exists()) {
/* 316 */           if (f.canRead()) {
/* 317 */             in = new FileInputStream(f);
/*     */           } else {
/* 319 */             throw new IOException("Could not open " + args[0]);
/*     */           } 
/*     */         } else {
/* 322 */           throw new IOException("Could not find " + args[0]);
/*     */         } 
/*     */       } else {
/* 325 */         in = System.in;
/*     */       } 
/* 327 */       PropertiesLexer shredder = new PropertiesLexer(in);
/*     */       PropertiesToken t;
/* 329 */       while ((t = shredder.getNextToken()) != null)
/*     */       {
/* 331 */         System.out.println(t);
/*     */       }
/*     */     }
/* 334 */     catch (IOException e) {
/* 335 */       System.err.println(e.getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public PropertiesToken getNextToken() throws IOException {
/* 346 */     return getToken();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   PropertiesLexer(Reader in) {
/* 358 */     this.zzReader = in;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   PropertiesLexer(InputStream in) {
/* 368 */     this(new InputStreamReader(in));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean zzRefill() throws IOException {
/* 382 */     if (this.zzStartRead > 0) {
/* 383 */       System.arraycopy(this.zzBuffer, this.zzStartRead, 
/* 384 */           this.zzBuffer, 0, 
/* 385 */           this.zzEndRead - this.zzStartRead);
/*     */ 
/*     */       
/* 388 */       this.zzEndRead -= this.zzStartRead;
/* 389 */       this.zzCurrentPos -= this.zzStartRead;
/* 390 */       this.zzMarkedPos -= this.zzStartRead;
/* 391 */       this.zzPushbackPos -= this.zzStartRead;
/* 392 */       this.zzStartRead = 0;
/*     */     } 
/*     */ 
/*     */     
/* 396 */     if (this.zzCurrentPos >= this.zzBuffer.length) {
/*     */       
/* 398 */       char[] newBuffer = new char[this.zzCurrentPos * 2];
/* 399 */       System.arraycopy(this.zzBuffer, 0, newBuffer, 0, this.zzBuffer.length);
/* 400 */       this.zzBuffer = newBuffer;
/*     */     } 
/*     */ 
/*     */     
/* 404 */     int numRead = this.zzReader.read(this.zzBuffer, this.zzEndRead, 
/* 405 */         this.zzBuffer.length - this.zzEndRead);
/*     */     
/* 407 */     if (numRead < 0) {
/* 408 */       return true;
/*     */     }
/*     */     
/* 411 */     this.zzEndRead += numRead;
/* 412 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final void yyclose() throws IOException {
/* 421 */     this.zzAtEOF = true;
/* 422 */     this.zzEndRead = this.zzStartRead;
/*     */     
/* 424 */     if (this.zzReader != null) {
/* 425 */       this.zzReader.close();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final void yyreset(Reader reader) {
/* 440 */     this.zzReader = reader;
/* 441 */     this.zzAtBOL = true;
/* 442 */     this.zzAtEOF = false;
/* 443 */     this.zzEndRead = this.zzStartRead = 0;
/* 444 */     this.zzCurrentPos = this.zzMarkedPos = this.zzPushbackPos = 0;
/* 445 */     this.yyline = this.yychar = this.yycolumn = 0;
/* 446 */     this.zzLexicalState = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int yystate() {
/* 454 */     return this.zzLexicalState;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final void yybegin(int newState) {
/* 464 */     this.zzLexicalState = newState;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String yytext() {
/* 472 */     return new String(this.zzBuffer, this.zzStartRead, this.zzMarkedPos - this.zzStartRead);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final char yycharat(int pos) {
/* 488 */     return this.zzBuffer[this.zzStartRead + pos];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int yylength() {
/* 496 */     return this.zzMarkedPos - this.zzStartRead;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void zzScanError(int errorCode) {
/*     */     String message;
/*     */     try {
/* 517 */       message = ZZ_ERROR_MSG[errorCode];
/*     */     }
/* 519 */     catch (ArrayIndexOutOfBoundsException e) {
/* 520 */       message = ZZ_ERROR_MSG[0];
/*     */     } 
/*     */     
/* 523 */     throw new Error(message);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void yypushback(int number) {
/* 536 */     if (number > yylength()) {
/* 537 */       zzScanError(2);
/*     */     }
/* 539 */     this.zzMarkedPos -= number;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private PropertiesToken getToken() throws IOException {
/* 557 */     int zzEndReadL = this.zzEndRead;
/* 558 */     char[] zzBufferL = this.zzBuffer;
/* 559 */     char[] zzCMapL = this.zzcmap_instance;
/*     */     
/* 561 */     int[] zzTransL = ZZ_TRANS;
/* 562 */     int[] zzRowMapL = ZZ_ROWMAP;
/* 563 */     int[] zzAttrL = ZZ_ATTRIBUTE; while (true) {
/*     */       int zzInput; String str1, state, text; PropertiesToken propertiesToken1; String str2;
/*     */       PropertiesToken t;
/* 566 */       int zzMarkedPosL = this.zzMarkedPos;
/*     */       
/* 568 */       int zzAction = -1;
/*     */       
/* 570 */       int zzCurrentPosL = this.zzCurrentPos = this.zzStartRead = zzMarkedPosL;
/*     */       
/* 572 */       this.zzState = this.zzLexicalState;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       while (true) {
/* 578 */         if (zzCurrentPosL < zzEndReadL)
/* 579 */         { zzInput = zzBufferL[zzCurrentPosL++]; }
/* 580 */         else { if (this.zzAtEOF) {
/* 581 */             int i = -1;
/*     */             
/*     */             break;
/*     */           } 
/*     */           
/* 586 */           this.zzCurrentPos = zzCurrentPosL;
/* 587 */           this.zzMarkedPos = zzMarkedPosL;
/* 588 */           boolean eof = zzRefill();
/*     */           
/* 590 */           zzCurrentPosL = this.zzCurrentPos;
/* 591 */           zzMarkedPosL = this.zzMarkedPos;
/* 592 */           zzBufferL = this.zzBuffer;
/* 593 */           zzEndReadL = this.zzEndRead;
/* 594 */           if (eof) {
/* 595 */             int i = -1;
/*     */             
/*     */             break;
/*     */           } 
/* 599 */           zzInput = zzBufferL[zzCurrentPosL++]; }
/*     */ 
/*     */         
/* 602 */         int zzNext = zzTransL[zzRowMapL[this.zzState] + zzCMapL[zzInput]];
/* 603 */         if (zzNext == -1)
/* 604 */           break;  this.zzState = zzNext;
/*     */         
/* 606 */         int zzAttributes = zzAttrL[this.zzState];
/* 607 */         if ((zzAttributes & 0x1) == 1) {
/* 608 */           zzAction = this.zzState;
/* 609 */           zzMarkedPosL = zzCurrentPosL;
/* 610 */           if ((zzAttributes & 0x8) == 8) {
/*     */             break;
/*     */           }
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 617 */       this.zzMarkedPos = zzMarkedPosL;
/*     */       
/* 619 */       switch ((zzAction < 0) ? zzAction : ZZ_ACTION[zzAction]) {
/*     */         case 6:
/* 621 */           this.nextState = 0;
/* 622 */           this.lastToken = 1;
/* 623 */           str1 = yytext();
/* 624 */           propertiesToken1 = new PropertiesToken(this.lastToken, str1);
/* 625 */           yybegin(this.nextState);
/* 626 */           return propertiesToken1;
/*     */         case 16:
/*     */           continue;
/*     */         case 10:
/* 630 */           this.nextState = 4;
/* 631 */           this.lastToken = 2;
/* 632 */           str1 = yytext();
/* 633 */           propertiesToken1 = new PropertiesToken(this.lastToken, str1);
/* 634 */           yybegin(this.nextState);
/* 635 */           return propertiesToken1;
/*     */         case 17:
/*     */           continue;
/*     */         case 1:
/* 639 */           this.nextState = 3;
/* 640 */           this.lastToken = 5;
/* 641 */           str1 = yytext();
/* 642 */           propertiesToken1 = new PropertiesToken(this.lastToken, str1);
/* 643 */           yybegin(this.nextState);
/* 644 */           return propertiesToken1;
/*     */         case 18:
/*     */           continue;
/*     */         case 13:
/* 648 */           this.nextState = 6;
/* 649 */           this.lastToken = 4;
/* 650 */           str1 = yytext();
/* 651 */           propertiesToken1 = new PropertiesToken(this.lastToken, str1);
/* 652 */           yybegin(this.nextState);
/* 653 */           return propertiesToken1;
/*     */         case 19:
/*     */           continue;
/*     */         case 11:
/* 657 */           this.nextState = 5;
/* 658 */           this.lastToken = 2;
/* 659 */           str1 = yytext();
/* 660 */           propertiesToken1 = new PropertiesToken(this.lastToken, str1);
/* 661 */           yybegin(this.nextState);
/* 662 */           return propertiesToken1;
/*     */         case 20:
/*     */           continue;
/*     */         case 15:
/* 666 */           this.nextState = 7;
/* 667 */           this.lastToken = 4;
/* 668 */           str1 = yytext();
/* 669 */           propertiesToken1 = new PropertiesToken(this.lastToken, str1);
/* 670 */           yybegin(this.nextState);
/* 671 */           return propertiesToken1;
/*     */         case 21:
/*     */           continue;
/*     */         case 4:
/* 675 */           this.nextState = 2;
/* 676 */           this.lastToken = 2;
/* 677 */           str1 = yytext();
/* 678 */           propertiesToken1 = new PropertiesToken(this.lastToken, str1);
/* 679 */           yybegin(this.nextState);
/* 680 */           return propertiesToken1;
/*     */         case 22:
/*     */           continue;
/*     */         case 8:
/* 684 */           this.nextState = 1;
/* 685 */           this.lastToken = 0;
/* 686 */           str1 = yytext();
/* 687 */           propertiesToken1 = new PropertiesToken(this.lastToken, str1);
/* 688 */           yybegin(this.nextState);
/* 689 */           return propertiesToken1;
/*     */         
/*     */         case 23:
/*     */         case 5:
/*     */         case 24:
/*     */           continue;
/*     */         
/*     */         case 12:
/* 697 */           this.lastToken = 2;
/* 698 */           str1 = yytext();
/* 699 */           propertiesToken1 = new PropertiesToken(this.lastToken, str1);
/* 700 */           return propertiesToken1;
/*     */         case 25:
/*     */           continue;
/*     */         case 14:
/* 704 */           this.lastToken = 4;
/* 705 */           str1 = yytext();
/* 706 */           propertiesToken1 = new PropertiesToken(this.lastToken, str1);
/* 707 */           return propertiesToken1;
/*     */         case 26:
/*     */           continue;
/*     */         case 7:
/* 711 */           this.nextState = 7;
/* 712 */           this.lastToken = 3;
/* 713 */           str1 = yytext();
/* 714 */           propertiesToken1 = new PropertiesToken(this.lastToken, str1);
/* 715 */           yybegin(this.nextState);
/* 716 */           return propertiesToken1;
/*     */         case 27:
/*     */           continue;
/*     */         case 3:
/* 720 */           return null;
/*     */         case 28:
/*     */           continue;
/*     */         case 9:
/* 724 */           System.err.println("Unmatched input.");
/* 725 */           state = "";
/* 726 */           str2 = yytext();
/* 727 */           switch (this.nextState) { case 0:
/* 728 */               state = "YYINITIAL"; break;
/* 729 */             case 1: state = "LINE_END"; break;
/* 730 */             case 2: state = "WHITE_SPACE"; break;
/* 731 */             case 3: state = "NAME"; break;
/* 732 */             case 7: state = "SEPARATOR"; break;
/* 733 */             case 8: state = "VALUE"; break;
/* 734 */             case 5: state = "MID_NAME"; break;
/* 735 */             case 4: state = "NAME_SPACE"; break; }
/*     */           
/* 737 */           System.err.println("State: '" + state + "'");
/* 738 */           System.err.println("Text: '" + str2 + "'");
/* 739 */           zzScanError(1); continue;
/*     */         case 29:
/*     */           continue;
/*     */         case 2:
/* 743 */           this.nextState = 8;
/* 744 */           this.lastToken = 6;
/* 745 */           text = yytext();
/* 746 */           t = new PropertiesToken(this.lastToken, text);
/* 747 */           yybegin(this.nextState);
/* 748 */           return t;
/*     */         case 30:
/*     */           continue;
/*     */       } 
/* 752 */       if (zzInput == -1 && this.zzStartRead == this.zzCurrentPos) {
/* 753 */         PropertiesToken propertiesToken; this.zzAtEOF = true;
/* 754 */         switch (this.zzLexicalState) {
/*     */           case 7:
/* 756 */             this.nextState = 9;
/* 757 */             this.lastToken = 1;
/* 758 */             propertiesToken = new PropertiesToken(this.lastToken, "");
/* 759 */             yybegin(this.nextState);
/* 760 */             return propertiesToken;
/*     */           case 37:
/*     */             continue;
/*     */           case 5:
/* 764 */             this.nextState = 9;
/* 765 */             this.lastToken = 1;
/* 766 */             propertiesToken = new PropertiesToken(this.lastToken, "");
/* 767 */             yybegin(this.nextState);
/* 768 */             return propertiesToken;
/*     */           case 38:
/*     */             continue;
/*     */           case 6:
/* 772 */             this.nextState = 9;
/* 773 */             this.lastToken = 1;
/* 774 */             propertiesToken = new PropertiesToken(this.lastToken, "");
/* 775 */             yybegin(this.nextState);
/* 776 */             return propertiesToken;
/*     */           case 39:
/*     */             continue;
/*     */           case 8:
/* 780 */             this.nextState = 9;
/* 781 */             this.lastToken = 1;
/* 782 */             propertiesToken = new PropertiesToken(this.lastToken, "");
/* 783 */             yybegin(this.nextState);
/* 784 */             return propertiesToken;
/*     */           case 40:
/*     */             continue;
/*     */           case 4:
/* 788 */             this.nextState = 9;
/* 789 */             this.lastToken = 1;
/* 790 */             propertiesToken = new PropertiesToken(this.lastToken, "");
/* 791 */             yybegin(this.nextState);
/* 792 */             return propertiesToken;
/*     */           case 41:
/*     */             continue;
/*     */           case 0:
/* 796 */             this.nextState = 9;
/* 797 */             this.lastToken = 1;
/* 798 */             propertiesToken = new PropertiesToken(this.lastToken, "");
/* 799 */             yybegin(this.nextState);
/* 800 */             return propertiesToken;
/*     */           case 42:
/*     */             continue;
/*     */           case 2:
/* 804 */             this.nextState = 9;
/* 805 */             this.lastToken = 1;
/* 806 */             propertiesToken = new PropertiesToken(this.lastToken, "");
/* 807 */             yybegin(this.nextState);
/* 808 */             return propertiesToken;
/*     */           case 43:
/*     */             continue;
/*     */           case 1:
/* 812 */             this.nextState = 9;
/* 813 */             this.lastToken = 1;
/* 814 */             propertiesToken = new PropertiesToken(this.lastToken, "");
/* 815 */             yybegin(this.nextState);
/* 816 */             return propertiesToken;
/*     */           case 44:
/*     */             continue;
/*     */           case 3:
/* 820 */             this.nextState = 9;
/* 821 */             this.lastToken = 1;
/* 822 */             propertiesToken = new PropertiesToken(this.lastToken, "");
/* 823 */             yybegin(this.nextState);
/* 824 */             return propertiesToken;
/*     */           case 45:
/*     */             continue;
/*     */         } 
/* 828 */         return null;
/*     */       } 
/*     */ 
/*     */       
/* 832 */       zzScanError(1);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/Ostermiller/util/PropertiesLexer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */