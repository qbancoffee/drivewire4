/*     */ package com.Ostermiller.util;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Reader;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class CGILexer
/*     */ {
/*     */   private static final int YYEOF = -1;
/*     */   private static final int ZZ_BUFFERSIZE = 16384;
/*     */   private static final int YYINITIAL = 0;
/*     */   private static final String ZZ_CMAP_PACKED = "&\000\001\001\026\000\001\000ￂ\000";
/*  65 */   private static final char[] ZZ_CMAP = zzUnpackCMap("&\000\001\001\026\000\001\000ￂ\000");
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  70 */   private static final int[] ZZ_ACTION = zzUnpackAction();
/*     */   
/*     */   private static final String ZZ_ACTION_PACKED_0 = "\002\001\001\002";
/*     */ 
/*     */   
/*     */   private static int[] zzUnpackAction() {
/*  76 */     int[] result = new int[3];
/*  77 */     int offset = 0;
/*  78 */     offset = zzUnpackAction("\002\001\001\002", offset, result);
/*  79 */     return result;
/*     */   }
/*     */   
/*     */   private static int zzUnpackAction(String packed, int offset, int[] result) {
/*  83 */     int i = 0;
/*  84 */     int j = offset;
/*  85 */     int l = packed.length();
/*  86 */     while (i < l) {
/*  87 */       int count = packed.charAt(i++);
/*  88 */       int value = packed.charAt(i++); 
/*  89 */       do { result[j++] = value; } while (--count > 0);
/*     */     } 
/*  91 */     return j;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  98 */   private static final int[] ZZ_ROWMAP = zzUnpackRowMap();
/*     */   
/*     */   private static final String ZZ_ROWMAP_PACKED_0 = "\000\000\000\002\000\004";
/*     */ 
/*     */   
/*     */   private static int[] zzUnpackRowMap() {
/* 104 */     int[] result = new int[3];
/* 105 */     int offset = 0;
/* 106 */     offset = zzUnpackRowMap("\000\000\000\002\000\004", offset, result);
/* 107 */     return result;
/*     */   }
/*     */   
/*     */   private static int zzUnpackRowMap(String packed, int offset, int[] result) {
/* 111 */     int i = 0;
/* 112 */     int j = offset;
/* 113 */     int l = packed.length();
/* 114 */     while (i < l) {
/* 115 */       int high = packed.charAt(i++) << 16;
/* 116 */       result[j++] = high | packed.charAt(i++);
/*     */     } 
/* 118 */     return j;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 124 */   private static final int[] ZZ_TRANS = zzUnpackTrans();
/*     */   
/*     */   private static final String ZZ_TRANS_PACKED_0 = "\001\002\001\003\001\002\003\000";
/*     */ 
/*     */   
/*     */   private static int[] zzUnpackTrans() {
/* 130 */     int[] result = new int[6];
/* 131 */     int offset = 0;
/* 132 */     offset = zzUnpackTrans("\001\002\001\003\001\002\003\000", offset, result);
/* 133 */     return result;
/*     */   }
/*     */   
/*     */   private static int zzUnpackTrans(String packed, int offset, int[] result) {
/* 137 */     int i = 0;
/* 138 */     int j = offset;
/* 139 */     int l = packed.length();
/* 140 */     while (i < l) {
/* 141 */       int count = packed.charAt(i++);
/* 142 */       int value = packed.charAt(i++);
/* 143 */       value--; 
/* 144 */       do { result[j++] = value; } while (--count > 0);
/*     */     } 
/* 146 */     return j;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 154 */   private char[] zzcmap_instance = ZZ_CMAP;
/*     */   
/*     */   private static final int ZZ_UNKNOWN_ERROR = 0;
/*     */   
/*     */   private static final int ZZ_NO_MATCH = 1;
/*     */   
/*     */   private static final int ZZ_PUSHBACK_2BIG = 2;
/*     */   
/* 162 */   private static final String[] ZZ_ERROR_MSG = new String[] {
/* 163 */       "Unkown internal scanner error", 
/* 164 */       "Error: could not match input", 
/* 165 */       "Error: pushback value was too large"
/*     */     };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 171 */   private static final int[] ZZ_ATTRIBUTE = zzUnpackAttribute();
/*     */   private static final String ZZ_ATTRIBUTE_PACKED_0 = "\002\001\001\t";
/*     */   private Reader zzReader;
/*     */   private int zzState;
/*     */   
/*     */   private static int[] zzUnpackAttribute() {
/* 177 */     int[] result = new int[3];
/* 178 */     int offset = 0;
/* 179 */     offset = zzUnpackAttribute("\002\001\001\t", offset, result);
/* 180 */     return result;
/*     */   }
/*     */   
/*     */   private static int zzUnpackAttribute(String packed, int offset, int[] result) {
/* 184 */     int i = 0;
/* 185 */     int j = offset;
/* 186 */     int l = packed.length();
/* 187 */     while (i < l) {
/* 188 */       int count = packed.charAt(i++);
/* 189 */       int value = packed.charAt(i++); 
/* 190 */       do { result[j++] = value; } while (--count > 0);
/*     */     } 
/* 192 */     return j;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 202 */   private int zzLexicalState = 0;
/*     */ 
/*     */ 
/*     */   
/* 206 */   private char[] zzBuffer = new char[16384];
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int zzMarkedPos;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int zzPushbackPos;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int zzCurrentPos;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int zzStartRead;
/*     */ 
/*     */ 
/*     */   
/*     */   private int zzEndRead;
/*     */ 
/*     */ 
/*     */   
/*     */   private int yyline;
/*     */ 
/*     */ 
/*     */   
/*     */   private int yychar;
/*     */ 
/*     */ 
/*     */   
/*     */   private int yycolumn;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean zzAtBOL = true;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean zzAtEOF;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void main(String[] args) {
/*     */     try {
/*     */       InputStream in;
/* 258 */       if (args.length > 0) {
/* 259 */         File f = new File(args[0]);
/* 260 */         if (f.exists()) {
/* 261 */           if (f.canRead()) {
/* 262 */             in = new FileInputStream(f);
/*     */           } else {
/* 264 */             throw new IOException("Could not open " + args[0]);
/*     */           } 
/*     */         } else {
/* 267 */           throw new IOException("Could not find " + args[0]);
/*     */         } 
/*     */       } else {
/* 270 */         in = System.in;
/*     */       } 
/* 272 */       CGILexer shredder = new CGILexer(in);
/*     */       String t;
/* 274 */       while ((t = shredder.nextToken()) != null) {
/* 275 */         System.out.println(t);
/*     */       }
/* 277 */     } catch (IOException e) {
/* 278 */       System.out.println(e.getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String nextToken() throws IOException {
/* 290 */     return getToken();
/*     */   }
/*     */   
/* 293 */   private StringBuffer token = new StringBuffer();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   CGILexer(Reader in) {
/* 303 */     this.zzReader = in;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   CGILexer(InputStream in) {
/* 313 */     this(new InputStreamReader(in));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static char[] zzUnpackCMap(String packed) {
/* 323 */     char[] map = new char[65536];
/* 324 */     int i = 0;
/* 325 */     int j = 0;
/* 326 */     while (i < 10) {
/* 327 */       int count = packed.charAt(i++);
/* 328 */       char value = packed.charAt(i++); 
/* 329 */       do { map[j++] = value; } while (--count > 0);
/*     */     } 
/* 331 */     return map;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean zzRefill() throws IOException {
/* 345 */     if (this.zzStartRead > 0) {
/* 346 */       System.arraycopy(this.zzBuffer, this.zzStartRead, 
/* 347 */           this.zzBuffer, 0, 
/* 348 */           this.zzEndRead - this.zzStartRead);
/*     */ 
/*     */       
/* 351 */       this.zzEndRead -= this.zzStartRead;
/* 352 */       this.zzCurrentPos -= this.zzStartRead;
/* 353 */       this.zzMarkedPos -= this.zzStartRead;
/* 354 */       this.zzPushbackPos -= this.zzStartRead;
/* 355 */       this.zzStartRead = 0;
/*     */     } 
/*     */ 
/*     */     
/* 359 */     if (this.zzCurrentPos >= this.zzBuffer.length) {
/*     */       
/* 361 */       char[] newBuffer = new char[this.zzCurrentPos * 2];
/* 362 */       System.arraycopy(this.zzBuffer, 0, newBuffer, 0, this.zzBuffer.length);
/* 363 */       this.zzBuffer = newBuffer;
/*     */     } 
/*     */ 
/*     */     
/* 367 */     int numRead = this.zzReader.read(this.zzBuffer, this.zzEndRead, 
/* 368 */         this.zzBuffer.length - this.zzEndRead);
/*     */     
/* 370 */     if (numRead < 0) {
/* 371 */       return true;
/*     */     }
/*     */     
/* 374 */     this.zzEndRead += numRead;
/* 375 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final void yyclose() throws IOException {
/* 384 */     this.zzAtEOF = true;
/* 385 */     this.zzEndRead = this.zzStartRead;
/*     */     
/* 387 */     if (this.zzReader != null) {
/* 388 */       this.zzReader.close();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final void yyreset(Reader reader) {
/* 403 */     this.zzReader = reader;
/* 404 */     this.zzAtBOL = true;
/* 405 */     this.zzAtEOF = false;
/* 406 */     this.zzEndRead = this.zzStartRead = 0;
/* 407 */     this.zzCurrentPos = this.zzMarkedPos = this.zzPushbackPos = 0;
/* 408 */     this.yyline = this.yychar = this.yycolumn = 0;
/* 409 */     this.zzLexicalState = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int yystate() {
/* 417 */     return this.zzLexicalState;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final void yybegin(int newState) {
/* 427 */     this.zzLexicalState = newState;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final String yytext() {
/* 435 */     return new String(this.zzBuffer, this.zzStartRead, this.zzMarkedPos - this.zzStartRead);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final char yycharat(int pos) {
/* 451 */     return this.zzBuffer[this.zzStartRead + pos];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int yylength() {
/* 459 */     return this.zzMarkedPos - this.zzStartRead;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void zzScanError(int errorCode) {
/*     */     String message;
/*     */     try {
/* 480 */       message = ZZ_ERROR_MSG[errorCode];
/*     */     }
/* 482 */     catch (ArrayIndexOutOfBoundsException e) {
/* 483 */       message = ZZ_ERROR_MSG[0];
/*     */     } 
/*     */     
/* 486 */     throw new Error(message);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void yypushback(int number) {
/* 499 */     if (number > yylength()) {
/* 500 */       zzScanError(2);
/*     */     }
/* 502 */     this.zzMarkedPos -= number;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private String getToken() throws IOException {
/* 520 */     int zzEndReadL = this.zzEndRead;
/* 521 */     char[] zzBufferL = this.zzBuffer;
/* 522 */     char[] zzCMapL = this.zzcmap_instance;
/*     */     
/* 524 */     int[] zzTransL = ZZ_TRANS;
/* 525 */     int[] zzRowMapL = ZZ_ROWMAP;
/* 526 */     int[] zzAttrL = ZZ_ATTRIBUTE;
/*     */     
/*     */     while (true) {
/* 529 */       int zzInput, zzMarkedPosL = this.zzMarkedPos;
/*     */       
/* 531 */       int zzAction = -1;
/*     */       
/* 533 */       int zzCurrentPosL = this.zzCurrentPos = this.zzStartRead = zzMarkedPosL;
/*     */       
/* 535 */       this.zzState = this.zzLexicalState;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       while (true) {
/* 541 */         if (zzCurrentPosL < zzEndReadL)
/* 542 */         { zzInput = zzBufferL[zzCurrentPosL++]; }
/* 543 */         else { if (this.zzAtEOF) {
/* 544 */             int i = -1;
/*     */             
/*     */             break;
/*     */           } 
/*     */           
/* 549 */           this.zzCurrentPos = zzCurrentPosL;
/* 550 */           this.zzMarkedPos = zzMarkedPosL;
/* 551 */           boolean eof = zzRefill();
/*     */           
/* 553 */           zzCurrentPosL = this.zzCurrentPos;
/* 554 */           zzMarkedPosL = this.zzMarkedPos;
/* 555 */           zzBufferL = this.zzBuffer;
/* 556 */           zzEndReadL = this.zzEndRead;
/* 557 */           if (eof) {
/* 558 */             int i = -1;
/*     */             
/*     */             break;
/*     */           } 
/* 562 */           zzInput = zzBufferL[zzCurrentPosL++]; }
/*     */ 
/*     */         
/* 565 */         int zzNext = zzTransL[zzRowMapL[this.zzState] + zzCMapL[zzInput]];
/* 566 */         if (zzNext == -1)
/* 567 */           break;  this.zzState = zzNext;
/*     */         
/* 569 */         int zzAttributes = zzAttrL[this.zzState];
/* 570 */         if ((zzAttributes & 0x1) == 1) {
/* 571 */           zzAction = this.zzState;
/* 572 */           zzMarkedPosL = zzCurrentPosL;
/* 573 */           if ((zzAttributes & 0x8) == 8) {
/*     */             break;
/*     */           }
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 580 */       this.zzMarkedPos = zzMarkedPosL;
/*     */       
/* 582 */       switch ((zzAction < 0) ? zzAction : ZZ_ACTION[zzAction]) {
/*     */         case 1:
/* 584 */           return yytext();
/*     */         
/*     */         case 3:
/*     */         case 2:
/*     */         case 4:
/*     */           continue;
/*     */       } 
/*     */       
/* 592 */       if (zzInput == -1 && this.zzStartRead == this.zzCurrentPos) {
/* 593 */         this.zzAtEOF = true;
/* 594 */         return null;
/*     */       } 
/*     */       
/* 597 */       zzScanError(1);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/Ostermiller/util/CGILexer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */