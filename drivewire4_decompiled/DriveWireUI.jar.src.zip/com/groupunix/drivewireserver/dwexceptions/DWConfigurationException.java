/*    */ package com.groupunix.drivewireserver.dwexceptions;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DWConfigurationException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public DWConfigurationException(String msg) {
/* 12 */     super(msg);
/*    */   }
/*    */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/groupunix/drivewireserver/dwexceptions/DWConfigurationException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */