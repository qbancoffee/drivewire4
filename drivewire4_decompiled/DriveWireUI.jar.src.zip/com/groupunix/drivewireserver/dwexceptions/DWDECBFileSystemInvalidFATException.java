/*    */ package com.groupunix.drivewireserver.dwexceptions;
/*    */ 
/*    */ 
/*    */ public class DWDECBFileSystemInvalidFATException
/*    */   extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   
/*    */   public DWDECBFileSystemInvalidFATException(String msg) {
/* 10 */     super(msg);
/*    */   }
/*    */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/groupunix/drivewireserver/dwexceptions/DWDECBFileSystemInvalidFATException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */