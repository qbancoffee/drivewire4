/*    */ package com.jcraft.jsch;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ChannelSubsystem
/*    */   extends ChannelSession
/*    */ {
/*    */   boolean xforwading = false;
/*    */   boolean pty = false;
/*    */   boolean want_reply = true;
/* 36 */   String subsystem = "";
/* 37 */   public void setXForwarding(boolean paramBoolean) { this.xforwading = true; }
/* 38 */   public void setPty(boolean paramBoolean) { this.pty = paramBoolean; }
/* 39 */   public void setWantReply(boolean paramBoolean) { this.want_reply = paramBoolean; } public void setSubsystem(String paramString) {
/* 40 */     this.subsystem = paramString;
/*    */   } public void start() throws JSchException {
/* 42 */     Session session = getSession();
/*    */     
/*    */     try {
/* 45 */       if (this.xforwading) {
/* 46 */         RequestX11 requestX11 = new RequestX11();
/* 47 */         requestX11.request(session, this);
/*    */       } 
/* 49 */       if (this.pty) {
/* 50 */         RequestPtyReq requestPtyReq = new RequestPtyReq();
/* 51 */         requestPtyReq.request(session, this);
/*    */       } 
/* 53 */       RequestSubsystem requestSubsystem = new RequestSubsystem();
/* 54 */       requestSubsystem.request(session, this, this.subsystem, this.want_reply);
/*    */     } catch (Exception exception) {
/*    */       
/* 57 */       if (exception instanceof JSchException) throw (JSchException)exception; 
/* 58 */       if (exception instanceof Throwable)
/* 59 */         throw new JSchException("ChannelSubsystem", exception); 
/* 60 */       throw new JSchException("ChannelSubsystem");
/*    */     } 
/* 62 */     if (this.io.in != null) {
/* 63 */       this.thread = new Thread(this);
/* 64 */       this.thread.setName("Subsystem for " + session.host);
/* 65 */       if (session.daemon_thread) {
/* 66 */         this.thread.setDaemon(session.daemon_thread);
/*    */       }
/* 68 */       this.thread.start();
/*    */     } 
/*    */   }
/*    */   
/*    */   void init() throws JSchException {
/* 73 */     this.io.setInputStream((getSession()).in);
/* 74 */     this.io.setOutputStream((getSession()).out);
/*    */   }
/*    */   
/*    */   public void setErrStream(OutputStream paramOutputStream) {
/* 78 */     setExtOutputStream(paramOutputStream);
/*    */   }
/*    */   public InputStream getErrStream() throws IOException {
/* 81 */     return getExtInputStream();
/*    */   }
/*    */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/ChannelSubsystem.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */