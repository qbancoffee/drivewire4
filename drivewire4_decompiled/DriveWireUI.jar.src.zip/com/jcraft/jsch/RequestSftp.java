/*    */ package com.jcraft.jsch;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RequestSftp
/*    */   extends Request
/*    */ {
/*    */   RequestSftp() {
/* 34 */     setReply(true);
/*    */   }
/*    */   public void request(Session paramSession, Channel paramChannel) throws Exception {
/* 37 */     super.request(paramSession, paramChannel);
/*    */     
/* 39 */     Buffer buffer = new Buffer();
/* 40 */     Packet packet = new Packet(buffer);
/* 41 */     packet.reset();
/* 42 */     buffer.putByte((byte)98);
/* 43 */     buffer.putInt(paramChannel.getRecipient());
/* 44 */     buffer.putString("subsystem".getBytes());
/* 45 */     buffer.putByte((byte)(waitForReply() ? 1 : 0));
/* 46 */     buffer.putString("sftp".getBytes());
/* 47 */     write(packet);
/*    */   }
/*    */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/RequestSftp.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */