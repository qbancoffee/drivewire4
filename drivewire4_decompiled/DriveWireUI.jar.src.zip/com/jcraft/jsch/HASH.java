package com.jcraft.jsch;

public interface HASH {
  void init() throws Exception;
  
  int getBlockSize();
  
  void update(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws Exception;
  
  byte[] digest() throws Exception;
}


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/HASH.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */