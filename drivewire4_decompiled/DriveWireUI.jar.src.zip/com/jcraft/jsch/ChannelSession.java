/*     */ package com.jcraft.jsch;
/*     */ 
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ChannelSession
/*     */   extends Channel
/*     */ {
/*  35 */   private static byte[] _session = "session".getBytes();
/*     */   
/*     */   protected boolean agent_forwarding = false;
/*     */   protected boolean xforwading = false;
/*  39 */   protected Hashtable env = null;
/*     */   
/*     */   protected boolean pty = false;
/*     */   
/*  43 */   protected String ttype = "vt100";
/*  44 */   protected int tcol = 80;
/*  45 */   protected int trow = 24;
/*  46 */   protected int twp = 640;
/*  47 */   protected int thp = 480;
/*  48 */   protected byte[] terminal_mode = null;
/*     */ 
/*     */   
/*     */   ChannelSession() {
/*  52 */     this.type = _session;
/*  53 */     this.io = new IO();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAgentForwarding(boolean paramBoolean) {
/*  62 */     this.agent_forwarding = paramBoolean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setXForwarding(boolean paramBoolean) {
/*  72 */     this.xforwading = paramBoolean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEnv(Hashtable paramHashtable) {
/*  81 */     synchronized (this) {
/*  82 */       this.env = paramHashtable;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEnv(String paramString1, String paramString2) {
/*  97 */     setEnv(paramString1.getBytes(), paramString2.getBytes());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setEnv(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) {
/* 109 */     synchronized (this) {
/* 110 */       getEnv().put(paramArrayOfbyte1, paramArrayOfbyte2);
/*     */     } 
/*     */   }
/*     */   
/*     */   private Hashtable getEnv() {
/* 115 */     if (this.env == null)
/* 116 */       this.env = new Hashtable(); 
/* 117 */     return this.env;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPty(boolean paramBoolean) {
/* 127 */     this.pty = paramBoolean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setTerminalMode(byte[] paramArrayOfbyte) {
/* 136 */     this.terminal_mode = paramArrayOfbyte;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPtySize(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 149 */     setPtyType(this.ttype, paramInt1, paramInt2, paramInt3, paramInt4);
/* 150 */     if (!this.pty || !isConnected()) {
/*     */       return;
/*     */     }
/*     */     try {
/* 154 */       RequestWindowChange requestWindowChange = new RequestWindowChange();
/* 155 */       requestWindowChange.setSize(paramInt1, paramInt2, paramInt3, paramInt4);
/* 156 */       requestWindowChange.request(getSession(), this);
/*     */     }
/* 158 */     catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPtyType(String paramString) {
/* 171 */     setPtyType(paramString, 80, 24, 640, 480);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPtyType(String paramString, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 185 */     this.ttype = paramString;
/* 186 */     this.tcol = paramInt1;
/* 187 */     this.trow = paramInt2;
/* 188 */     this.twp = paramInt3;
/* 189 */     this.thp = paramInt4;
/*     */   }
/*     */   
/*     */   protected void sendRequests() throws Exception {
/* 193 */     Session session = getSession();
/*     */     
/* 195 */     if (this.agent_forwarding) {
/* 196 */       RequestAgentForwarding requestAgentForwarding = new RequestAgentForwarding();
/* 197 */       requestAgentForwarding.request(session, this);
/*     */     } 
/*     */     
/* 200 */     if (this.xforwading) {
/* 201 */       RequestX11 requestX11 = new RequestX11();
/* 202 */       requestX11.request(session, this);
/*     */     } 
/*     */     
/* 205 */     if (this.pty) {
/* 206 */       RequestPtyReq requestPtyReq = new RequestPtyReq();
/* 207 */       requestPtyReq.setTType(this.ttype);
/* 208 */       requestPtyReq.setTSize(this.tcol, this.trow, this.twp, this.thp);
/* 209 */       if (this.terminal_mode != null) {
/* 210 */         requestPtyReq.setTerminalMode(this.terminal_mode);
/*     */       }
/* 212 */       requestPtyReq.request(session, this);
/*     */     } 
/*     */     
/* 215 */     if (this.env != null) {
/* 216 */       for (Enumeration enumeration = this.env.keys(); enumeration.hasMoreElements(); ) {
/* 217 */         Object object = enumeration.nextElement();
/* 218 */         Object object1 = this.env.get(object);
/* 219 */         RequestEnv requestEnv = new RequestEnv();
/* 220 */         requestEnv.setEnv(toByteArray(object), toByteArray(object1));
/*     */         
/* 222 */         requestEnv.request(session, this);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private byte[] toByteArray(Object paramObject) {
/* 228 */     if (paramObject instanceof String) {
/* 229 */       return ((String)paramObject).getBytes();
/*     */     }
/* 231 */     return (byte[])paramObject;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/* 237 */     Buffer buffer = new Buffer(this.rmpsize);
/* 238 */     Packet packet = new Packet(buffer);
/* 239 */     int i = -1;
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 244 */       while (isConnected() && this.thread != null && this.io != null && this.io.in != null) {
/* 245 */         i = this.io.in.read(buffer.buffer, 14, buffer.buffer.length - 14 - 32 - 20);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 250 */         if (i == 0)
/* 251 */           continue;  if (i == -1) {
/* 252 */           eof();
/*     */           break;
/*     */         } 
/* 255 */         if (this.close)
/*     */           break; 
/* 257 */         packet.reset();
/* 258 */         buffer.putByte((byte)94);
/* 259 */         buffer.putInt(this.recipient);
/* 260 */         buffer.putInt(i);
/* 261 */         buffer.skip(i);
/* 262 */         getSession().write(packet, this, i);
/*     */       }
/*     */     
/* 265 */     } catch (Exception exception) {}
/*     */ 
/*     */ 
/*     */     
/* 269 */     if (this.thread != null)
/* 270 */       synchronized (this.thread) { this.thread.notifyAll(); }
/*     */        
/* 272 */     this.thread = null;
/*     */   }
/*     */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/ChannelSession.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */