/*     */ package com.jcraft.jsch;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class KeyExchange
/*     */ {
/*     */   static final int PROPOSAL_KEX_ALGS = 0;
/*     */   static final int PROPOSAL_SERVER_HOST_KEY_ALGS = 1;
/*     */   static final int PROPOSAL_ENC_ALGS_CTOS = 2;
/*     */   static final int PROPOSAL_ENC_ALGS_STOC = 3;
/*     */   static final int PROPOSAL_MAC_ALGS_CTOS = 4;
/*     */   static final int PROPOSAL_MAC_ALGS_STOC = 5;
/*     */   static final int PROPOSAL_COMP_ALGS_CTOS = 6;
/*     */   static final int PROPOSAL_COMP_ALGS_STOC = 7;
/*     */   static final int PROPOSAL_LANG_CTOS = 8;
/*     */   static final int PROPOSAL_LANG_STOC = 9;
/*     */   static final int PROPOSAL_MAX = 10;
/*  50 */   static String kex = "diffie-hellman-group1-sha1";
/*  51 */   static String server_host_key = "ssh-rsa,ssh-dss";
/*  52 */   static String enc_c2s = "blowfish-cbc";
/*  53 */   static String enc_s2c = "blowfish-cbc";
/*  54 */   static String mac_c2s = "hmac-md5";
/*     */   
/*  56 */   static String mac_s2c = "hmac-md5";
/*     */ 
/*     */   
/*  59 */   static String lang_c2s = "";
/*  60 */   static String lang_s2c = "";
/*     */   
/*     */   public static final int STATE_END = 0;
/*     */   
/*  64 */   protected Session session = null;
/*  65 */   protected HASH sha = null;
/*  66 */   protected byte[] K = null;
/*  67 */   protected byte[] H = null;
/*  68 */   protected byte[] K_S = null;
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract void init(Session paramSession, byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[] paramArrayOfbyte3, byte[] paramArrayOfbyte4) throws Exception;
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract boolean next(Buffer paramBuffer) throws Exception;
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract String getKeyType();
/*     */ 
/*     */ 
/*     */   
/*     */   public abstract int getState();
/*     */ 
/*     */ 
/*     */   
/*     */   protected static String[] guess(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) {
/*  89 */     String[] arrayOfString = new String[10];
/*  90 */     Buffer buffer1 = new Buffer(paramArrayOfbyte1); buffer1.setOffSet(17);
/*  91 */     Buffer buffer2 = new Buffer(paramArrayOfbyte2); buffer2.setOffSet(17);
/*     */     
/*  93 */     for (byte b = 0; b < 10; b++) {
/*  94 */       byte[] arrayOfByte1 = buffer1.getString();
/*  95 */       byte[] arrayOfByte2 = buffer2.getString();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 100 */       byte b1 = 0;
/* 101 */       byte b2 = 0;
/*     */ 
/*     */       
/* 104 */       label41: while (b1 < arrayOfByte2.length) {
/* 105 */         for (; b1 < arrayOfByte2.length && arrayOfByte2[b1] != 44; b1++);
/* 106 */         if (b2 == b1) return null; 
/* 107 */         String str = new String(arrayOfByte2, b2, b1 - b2);
/*     */         
/* 109 */         byte b3 = 0;
/* 110 */         byte b4 = 0;
/* 111 */         while (b3 < arrayOfByte1.length) {
/* 112 */           for (; b3 < arrayOfByte1.length && arrayOfByte1[b3] != 44; b3++);
/* 113 */           if (b4 == b3) return null;
/*     */           
/* 115 */           if (str.equals(new String(arrayOfByte1, b4, b3 - b4))) {
/* 116 */             arrayOfString[b] = str;
/*     */             
/*     */             break label41;
/*     */           } 
/*     */           
/* 121 */           b4 = ++b3;
/*     */         } 
/*     */         
/* 124 */         b2 = ++b1;
/*     */       } 
/* 126 */       if (b1 == 0) {
/* 127 */         arrayOfString[b] = "";
/*     */       }
/* 129 */       else if (arrayOfString[b] == null) {
/*     */         
/* 131 */         return null;
/*     */       } 
/*     */     } 
/*     */     
/* 135 */     if (JSch.getLogger().isEnabled(1)) {
/* 136 */       JSch.getLogger().log(1, "kex: server->client " + arrayOfString[3] + " " + arrayOfString[5] + " " + arrayOfString[7]);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 141 */       JSch.getLogger().log(1, "kex: client->server " + arrayOfString[2] + " " + arrayOfString[4] + " " + arrayOfString[6]);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 152 */     return arrayOfString;
/*     */   }
/*     */   
/*     */   public String getFingerPrint() {
/* 156 */     HASH hASH = null;
/*     */     try {
/* 158 */       Class clazz = Class.forName(this.session.getConfig("md5"));
/* 159 */       hASH = (HASH)clazz.newInstance();
/*     */     } catch (Exception exception) {
/* 161 */       System.err.println("getFingerPrint: " + exception);
/* 162 */     }  return Util.getFingerPrint(hASH, getHostKey());
/*     */   }
/* 164 */   byte[] getK() { return this.K; }
/* 165 */   byte[] getH() { return this.H; }
/* 166 */   HASH getHash() { return this.sha; } byte[] getHostKey() {
/* 167 */     return this.K_S;
/*     */   }
/*     */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/KeyExchange.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */