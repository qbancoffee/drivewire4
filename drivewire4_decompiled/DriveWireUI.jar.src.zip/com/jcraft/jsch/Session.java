/*      */ package com.jcraft.jsch;
/*      */ 
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.InterruptedIOException;
/*      */ import java.io.OutputStream;
/*      */ import java.net.Socket;
/*      */ import java.util.Arrays;
/*      */ import java.util.Enumeration;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Properties;
/*      */ import java.util.Vector;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Session
/*      */   implements Runnable
/*      */ {
/*      */   private static final String version = "JSCH-0.1.42";
/*      */   static final int SSH_MSG_DISCONNECT = 1;
/*      */   static final int SSH_MSG_IGNORE = 2;
/*      */   static final int SSH_MSG_UNIMPLEMENTED = 3;
/*      */   static final int SSH_MSG_DEBUG = 4;
/*      */   static final int SSH_MSG_SERVICE_REQUEST = 5;
/*      */   static final int SSH_MSG_SERVICE_ACCEPT = 6;
/*      */   static final int SSH_MSG_KEXINIT = 20;
/*      */   static final int SSH_MSG_NEWKEYS = 21;
/*      */   static final int SSH_MSG_KEXDH_INIT = 30;
/*      */   static final int SSH_MSG_KEXDH_REPLY = 31;
/*      */   static final int SSH_MSG_KEX_DH_GEX_GROUP = 31;
/*      */   static final int SSH_MSG_KEX_DH_GEX_INIT = 32;
/*      */   static final int SSH_MSG_KEX_DH_GEX_REPLY = 33;
/*      */   static final int SSH_MSG_KEX_DH_GEX_REQUEST = 34;
/*      */   static final int SSH_MSG_GLOBAL_REQUEST = 80;
/*      */   static final int SSH_MSG_REQUEST_SUCCESS = 81;
/*      */   static final int SSH_MSG_REQUEST_FAILURE = 82;
/*      */   static final int SSH_MSG_CHANNEL_OPEN = 90;
/*      */   static final int SSH_MSG_CHANNEL_OPEN_CONFIRMATION = 91;
/*      */   static final int SSH_MSG_CHANNEL_OPEN_FAILURE = 92;
/*      */   static final int SSH_MSG_CHANNEL_WINDOW_ADJUST = 93;
/*      */   static final int SSH_MSG_CHANNEL_DATA = 94;
/*      */   static final int SSH_MSG_CHANNEL_EXTENDED_DATA = 95;
/*      */   static final int SSH_MSG_CHANNEL_EOF = 96;
/*      */   static final int SSH_MSG_CHANNEL_CLOSE = 97;
/*      */   static final int SSH_MSG_CHANNEL_REQUEST = 98;
/*      */   static final int SSH_MSG_CHANNEL_SUCCESS = 99;
/*      */   static final int SSH_MSG_CHANNEL_FAILURE = 100;
/*      */   private byte[] V_S;
/*   69 */   private byte[] V_C = "SSH-2.0-JSCH-0.1.42".getBytes();
/*      */   
/*      */   private byte[] I_C;
/*      */   
/*      */   private byte[] I_S;
/*      */   
/*      */   private byte[] K_S;
/*      */   
/*      */   private byte[] session_id;
/*      */   private byte[] IVc2s;
/*      */   private byte[] IVs2c;
/*      */   private byte[] Ec2s;
/*      */   private byte[] Es2c;
/*      */   private byte[] MACc2s;
/*      */   private byte[] MACs2c;
/*   84 */   private int seqi = 0;
/*   85 */   private int seqo = 0;
/*      */   
/*   87 */   String[] guess = null;
/*      */   
/*      */   private Cipher s2ccipher;
/*      */   
/*      */   private Cipher c2scipher;
/*      */   
/*      */   private MAC s2cmac;
/*      */   private MAC c2smac;
/*      */   private byte[] s2cmac_result1;
/*      */   private byte[] s2cmac_result2;
/*      */   private Compression deflater;
/*      */   private Compression inflater;
/*      */   private IO io;
/*      */   private Socket socket;
/*  101 */   private int timeout = 0;
/*      */   
/*      */   private boolean isConnected = false;
/*      */   
/*      */   private boolean isAuthed = false;
/*      */   
/*  107 */   private Thread connectThread = null;
/*  108 */   private Object lock = new Object();
/*      */   
/*      */   boolean x11_forwarding = false;
/*      */   
/*      */   boolean agent_forwarding = false;
/*  113 */   InputStream in = null;
/*  114 */   OutputStream out = null;
/*      */   
/*      */   static Random random;
/*      */   
/*      */   Buffer buf;
/*      */   
/*      */   Packet packet;
/*  121 */   SocketFactory socket_factory = null;
/*      */   
/*  123 */   private Hashtable config = null;
/*      */   
/*  125 */   private Proxy proxy = null;
/*      */   
/*      */   private UserInfo userinfo;
/*  128 */   private String hostKeyAlias = null;
/*  129 */   private int serverAliveInterval = 0;
/*  130 */   private int serverAliveCountMax = 1;
/*      */   
/*      */   protected boolean daemon_thread = false;
/*      */   
/*  134 */   String host = "127.0.0.1";
/*  135 */   int port = 22;
/*      */   
/*  137 */   String username = null;
/*  138 */   byte[] password = null;
/*      */   
/*      */   JSch jsch;
/*      */   
/*      */   private boolean in_kex;
/*      */   int[] uncompress_len;
/*      */   private int s2ccipher_size;
/*      */   private int c2scipher_size;
/*      */   Runnable thread;
/*      */   private GlobalRequestReply grr;
/*      */   
/*      */   public void connect() throws JSchException {
/*  150 */     connect(this.timeout);
/*      */   }
/*      */   
/*      */   public void connect(int paramInt) throws JSchException {
/*  154 */     if (this.isConnected) {
/*  155 */       throw new JSchException("session is already connected");
/*      */     }
/*      */     
/*  158 */     this.io = new IO();
/*  159 */     if (random == null) {
/*      */       try {
/*  161 */         Class clazz = Class.forName(getConfig("random"));
/*  162 */         random = (Random)clazz.newInstance();
/*      */       } catch (Exception exception) {
/*      */         
/*  165 */         throw new JSchException(exception.toString(), exception);
/*      */       } 
/*      */     }
/*  168 */     Packet.setRandom(random);
/*      */     
/*  170 */     if (JSch.getLogger().isEnabled(1)) {
/*  171 */       JSch.getLogger().log(1, "Connecting to " + this.host + " port " + this.port);
/*      */     }
/*      */ 
/*      */     
/*      */     try {
/*      */       byte b1;
/*      */       
/*  178 */       if (this.proxy == null) {
/*      */         InputStream inputStream;
/*      */         OutputStream outputStream;
/*  181 */         if (this.socket_factory == null) {
/*  182 */           this.socket = Util.createSocket(this.host, this.port, paramInt);
/*  183 */           inputStream = this.socket.getInputStream();
/*  184 */           outputStream = this.socket.getOutputStream();
/*      */         } else {
/*      */           
/*  187 */           this.socket = this.socket_factory.createSocket(this.host, this.port);
/*  188 */           inputStream = this.socket_factory.getInputStream(this.socket);
/*  189 */           outputStream = this.socket_factory.getOutputStream(this.socket);
/*      */         } 
/*      */         
/*  192 */         this.socket.setTcpNoDelay(true);
/*  193 */         this.io.setInputStream(inputStream);
/*  194 */         this.io.setOutputStream(outputStream);
/*      */       } else {
/*      */         
/*  197 */         synchronized (this.proxy) {
/*  198 */           this.proxy.connect(this.socket_factory, this.host, this.port, paramInt);
/*  199 */           this.io.setInputStream(this.proxy.getInputStream());
/*  200 */           this.io.setOutputStream(this.proxy.getOutputStream());
/*  201 */           this.socket = this.proxy.getSocket();
/*      */         } 
/*      */       } 
/*      */       
/*  205 */       if (paramInt > 0 && this.socket != null) {
/*  206 */         this.socket.setSoTimeout(paramInt);
/*      */       }
/*      */       
/*  209 */       this.isConnected = true;
/*      */       
/*  211 */       if (JSch.getLogger().isEnabled(1)) {
/*  212 */         JSch.getLogger().log(1, "Connection established");
/*      */       }
/*      */ 
/*      */       
/*  216 */       this.jsch.addSession(this);
/*      */ 
/*      */ 
/*      */       
/*  220 */       byte[] arrayOfByte = new byte[this.V_C.length + 1];
/*  221 */       System.arraycopy(this.V_C, 0, arrayOfByte, 0, this.V_C.length);
/*  222 */       arrayOfByte[arrayOfByte.length - 1] = 10;
/*  223 */       this.io.put(arrayOfByte, 0, arrayOfByte.length);
/*      */ 
/*      */       
/*      */       while (true) {
/*  227 */         b1 = 0;
/*  228 */         int i = 0;
/*  229 */         while (b1 < this.buf.buffer.length) {
/*  230 */           i = this.io.getByte();
/*  231 */           if (i < 0)
/*  232 */             break;  this.buf.buffer[b1] = (byte)i; b1++;
/*  233 */           if (i == 10)
/*      */             break; 
/*  235 */         }  if (i < 0) {
/*  236 */           throw new JSchException("connection is closed by foreign host");
/*      */         }
/*      */ 
/*      */         
/*  240 */         b1--;
/*  241 */         if (this.buf.buffer[b1 - 1] == 10 && b1 > 0 && this.buf.buffer[b1 - 1] == 13) {
/*  242 */           b1--;
/*      */         }
/*      */ 
/*      */         
/*  246 */         if (b1 <= 3 || (b1 != this.buf.buffer.length && (this.buf.buffer[0] != 83 || this.buf.buffer[1] != 83 || this.buf.buffer[2] != 72 || this.buf.buffer[3] != 45))) {
/*      */           continue;
/*      */         }
/*      */ 
/*      */         
/*      */         break;
/*      */       } 
/*      */ 
/*      */       
/*  255 */       if (b1 == this.buf.buffer.length || b1 < 7 || (this.buf.buffer[4] == 49 && this.buf.buffer[6] != 57))
/*      */       {
/*      */ 
/*      */         
/*  259 */         throw new JSchException("invalid server's version string");
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  264 */       this.V_S = new byte[b1]; System.arraycopy(this.buf.buffer, 0, this.V_S, 0, b1);
/*      */ 
/*      */       
/*  267 */       if (JSch.getLogger().isEnabled(1)) {
/*  268 */         JSch.getLogger().log(1, "Remote version string: " + new String(this.V_S));
/*      */         
/*  270 */         JSch.getLogger().log(1, "Local version string: " + new String(this.V_C));
/*      */       } 
/*      */ 
/*      */       
/*  274 */       send_kexinit();
/*      */       
/*  276 */       this.buf = read(this.buf);
/*  277 */       if (this.buf.getCommand() != 20) {
/*  278 */         throw new JSchException("invalid protocol: " + this.buf.getCommand());
/*      */       }
/*      */       
/*  281 */       if (JSch.getLogger().isEnabled(1)) {
/*  282 */         JSch.getLogger().log(1, "SSH_MSG_KEXINIT received");
/*      */       }
/*      */ 
/*      */       
/*  286 */       KeyExchange keyExchange = receive_kexinit(this.buf);
/*      */       
/*      */       do {
/*  289 */         this.buf = read(this.buf);
/*  290 */         if (keyExchange.getState() == this.buf.getCommand()) {
/*  291 */           boolean bool2 = keyExchange.next(this.buf);
/*  292 */           if (!bool2) {
/*      */             
/*  294 */             this.in_kex = false;
/*  295 */             throw new JSchException("verify: " + bool2);
/*      */           } 
/*      */         } else {
/*      */           
/*  299 */           this.in_kex = false;
/*  300 */           throw new JSchException("invalid protocol(kex): " + this.buf.getCommand());
/*      */         } 
/*  302 */       } while (keyExchange.getState() != 0);
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/*  307 */         checkHost(this.host, this.port, keyExchange);
/*      */       } catch (JSchException jSchException) {
/*  309 */         this.in_kex = false;
/*  310 */         throw jSchException;
/*      */       } 
/*      */       
/*  313 */       send_newkeys();
/*      */ 
/*      */       
/*  316 */       this.buf = read(this.buf);
/*      */       
/*  318 */       if (this.buf.getCommand() == 21) {
/*      */         
/*  320 */         if (JSch.getLogger().isEnabled(1)) {
/*  321 */           JSch.getLogger().log(1, "SSH_MSG_NEWKEYS received");
/*      */         }
/*      */ 
/*      */         
/*  325 */         receive_newkeys(this.buf, keyExchange);
/*      */       } else {
/*      */         
/*  328 */         this.in_kex = false;
/*  329 */         throw new JSchException("invalid protocol(newkyes): " + this.buf.getCommand());
/*      */       } 
/*      */       
/*  332 */       boolean bool = false;
/*  333 */       boolean bool1 = false;
/*      */       
/*  335 */       UserAuth userAuth = null;
/*      */       try {
/*  337 */         Class clazz = Class.forName(getConfig("userauth.none"));
/*  338 */         userAuth = (UserAuth)clazz.newInstance();
/*      */       } catch (Exception exception) {
/*      */         
/*  341 */         throw new JSchException(exception.toString(), exception);
/*      */       } 
/*      */       
/*  344 */       bool = userAuth.start(this);
/*      */       
/*  346 */       String str1 = getConfig("PreferredAuthentications");
/*  347 */       String[] arrayOfString1 = Util.split(str1, ",");
/*      */       
/*  349 */       String str2 = null;
/*  350 */       if (!bool) {
/*  351 */         str2 = ((UserAuthNone)userAuth).getMethods();
/*  352 */         if (str2 != null) {
/*  353 */           str2 = str2.toLowerCase();
/*      */         
/*      */         }
/*      */         else {
/*      */           
/*  358 */           str2 = str1;
/*      */         } 
/*      */       } 
/*      */       
/*  362 */       String[] arrayOfString2 = Util.split(str2, ",");
/*      */       
/*  364 */       byte b2 = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  372 */       while (!bool && arrayOfString1 != null && b2 < arrayOfString1.length) {
/*      */         
/*  374 */         String str = arrayOfString1[b2++];
/*  375 */         boolean bool2 = false;
/*  376 */         for (byte b = 0; b < arrayOfString2.length; b++) {
/*  377 */           if (arrayOfString2[b].equals(str)) {
/*  378 */             bool2 = true;
/*      */             break;
/*      */           } 
/*      */         } 
/*  382 */         if (!bool2) {
/*      */           continue;
/*      */         }
/*      */ 
/*      */ 
/*      */         
/*  388 */         if (JSch.getLogger().isEnabled(1)) {
/*  389 */           String str3 = "Authentications that can continue: ";
/*  390 */           for (int i = b2 - 1; i < arrayOfString1.length; i++) {
/*  391 */             str3 = str3 + arrayOfString1[i];
/*  392 */             if (i + 1 < arrayOfString1.length)
/*  393 */               str3 = str3 + ","; 
/*      */           } 
/*  395 */           JSch.getLogger().log(1, str3);
/*      */           
/*  397 */           JSch.getLogger().log(1, "Next authentication method: " + str);
/*      */         } 
/*      */ 
/*      */         
/*  401 */         userAuth = null;
/*      */         try {
/*  403 */           Class clazz = null;
/*  404 */           if (getConfig("userauth." + str) != null) {
/*  405 */             clazz = Class.forName(getConfig("userauth." + str));
/*  406 */             userAuth = (UserAuth)clazz.newInstance();
/*      */           } 
/*      */         } catch (Exception exception) {
/*      */           
/*  410 */           if (JSch.getLogger().isEnabled(2)) {
/*  411 */             JSch.getLogger().log(2, "failed to load " + str + " method");
/*      */           }
/*      */         } 
/*      */ 
/*      */         
/*  416 */         if (userAuth != null) {
/*  417 */           bool1 = false;
/*      */           try {
/*  419 */             bool = userAuth.start(this);
/*  420 */             if (bool && JSch.getLogger().isEnabled(1))
/*      */             {
/*  422 */               JSch.getLogger().log(1, "Authentication succeeded (" + str + ").");
/*      */             }
/*      */           }
/*      */           catch (JSchAuthCancelException jSchAuthCancelException) {
/*      */             
/*  427 */             bool1 = true;
/*      */           } catch (JSchPartialAuthException jSchPartialAuthException) {
/*      */             
/*  430 */             str2 = jSchPartialAuthException.getMethods();
/*  431 */             arrayOfString2 = Util.split(str2, ",");
/*  432 */             b2 = 0;
/*      */             
/*  434 */             bool1 = false;
/*      */           }
/*      */           catch (RuntimeException runtimeException) {
/*      */             
/*  438 */             throw runtimeException;
/*      */ 
/*      */           
/*      */           }
/*  442 */           catch (Exception exception) {
/*      */             break;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  449 */       if (!bool) {
/*  450 */         if (bool1)
/*  451 */           throw new JSchException("Auth cancel"); 
/*  452 */         throw new JSchException("Auth fail");
/*      */       } 
/*      */       
/*  455 */       if (paramInt > 0 || this.timeout > 0) {
/*  456 */         this.socket.setSoTimeout(this.timeout);
/*      */       }
/*      */       
/*  459 */       this.isAuthed = true;
/*      */       
/*  461 */       synchronized (this.lock) {
/*  462 */         if (this.isConnected) {
/*  463 */           this.connectThread = new Thread(this);
/*  464 */           this.connectThread.setName("Connect thread " + this.host + " session");
/*  465 */           if (this.daemon_thread) {
/*  466 */             this.connectThread.setDaemon(this.daemon_thread);
/*      */           }
/*  468 */           this.connectThread.start();
/*      */         
/*      */         }
/*      */       
/*      */       }
/*      */     
/*      */     }
/*      */     catch (Exception exception) {
/*      */       
/*  477 */       this.in_kex = false;
/*  478 */       if (this.isConnected) {
/*      */         try {
/*  480 */           this.packet.reset();
/*  481 */           this.buf.putByte((byte)1);
/*  482 */           this.buf.putInt(3);
/*  483 */           this.buf.putString(exception.toString().getBytes());
/*  484 */           this.buf.putString("en".getBytes());
/*  485 */           write(this.packet);
/*  486 */           disconnect();
/*      */         }
/*  488 */         catch (Exception exception1) {}
/*      */       }
/*      */       
/*  491 */       this.isConnected = false;
/*      */       
/*  493 */       if (exception instanceof RuntimeException) throw (RuntimeException)exception; 
/*  494 */       if (exception instanceof JSchException) throw (JSchException)exception; 
/*  495 */       throw new JSchException("Session.connect: " + exception);
/*      */     } finally {
/*      */       
/*  498 */       Util.bzero(this.password);
/*  499 */       this.password = null;
/*      */     } 
/*      */   }
/*      */   
/*      */   private KeyExchange receive_kexinit(Buffer paramBuffer) throws Exception {
/*  504 */     int i = paramBuffer.getInt();
/*  505 */     if (i != paramBuffer.getLength()) {
/*  506 */       paramBuffer.getByte();
/*  507 */       this.I_S = new byte[paramBuffer.index - 5];
/*      */     } else {
/*      */       
/*  510 */       this.I_S = new byte[i - 1 - paramBuffer.getByte()];
/*      */     } 
/*  512 */     System.arraycopy(paramBuffer.buffer, paramBuffer.s, this.I_S, 0, this.I_S.length);
/*      */     
/*  514 */     if (!this.in_kex) {
/*  515 */       send_kexinit();
/*      */     }
/*      */     
/*  518 */     this.guess = KeyExchange.guess(this.I_S, this.I_C);
/*  519 */     if (this.guess == null) {
/*  520 */       throw new JSchException("Algorithm negotiation fail");
/*      */     }
/*      */     
/*  523 */     if (!this.isAuthed && (this.guess[2].equals("none") || this.guess[3].equals("none")))
/*      */     {
/*      */       
/*  526 */       throw new JSchException("NONE Cipher should not be chosen before authentification is successed.");
/*      */     }
/*      */     
/*  529 */     KeyExchange keyExchange = null;
/*      */     try {
/*  531 */       Class clazz = Class.forName(getConfig(this.guess[0]));
/*  532 */       keyExchange = (KeyExchange)clazz.newInstance();
/*      */     } catch (Exception exception) {
/*      */       
/*  535 */       throw new JSchException(exception.toString(), exception);
/*      */     } 
/*      */     
/*  538 */     keyExchange.init(this, this.V_S, this.V_C, this.I_S, this.I_C);
/*  539 */     return keyExchange;
/*      */   }
/*      */   public void rekey() throws Exception { send_kexinit(); } private void send_kexinit() throws Exception { if (this.in_kex) return;  String str1 = getConfig("cipher.c2s"); String str2 = getConfig("cipher.s2c"); String[] arrayOfString = checkCiphers(getConfig("CheckCiphers")); if (arrayOfString != null && arrayOfString.length > 0) { str1 = Util.diffString(str1, arrayOfString); str2 = Util.diffString(str2, arrayOfString); if (str1 == null || str2 == null) throw new JSchException("There are not any available ciphers.");  }  this.in_kex = true; Buffer buffer = new Buffer(); Packet packet = new Packet(buffer); packet.reset(); buffer.putByte((byte)20); synchronized (random) { random.fill(buffer.buffer, buffer.index, 16); buffer.skip(16); }  buffer.putString(getConfig("kex").getBytes()); buffer.putString(getConfig("server_host_key").getBytes()); buffer.putString(str1.getBytes()); buffer.putString(str2.getBytes()); buffer.putString(getConfig("mac.c2s").getBytes()); buffer.putString(getConfig("mac.s2c").getBytes()); buffer.putString(getConfig("compression.c2s").getBytes()); buffer.putString(getConfig("compression.s2c").getBytes()); buffer.putString(getConfig("lang.c2s").getBytes()); buffer.putString(getConfig("lang.s2c").getBytes()); buffer.putByte((byte)0); buffer.putInt(0); buffer.setOffSet(5); this.I_C = new byte[buffer.getLength()]; buffer.getByte(this.I_C); write(packet); if (JSch.getLogger().isEnabled(1)) JSch.getLogger().log(1, "SSH_MSG_KEXINIT sent");  } private void send_newkeys() throws Exception { this.packet.reset(); this.buf.putByte((byte)21); write(this.packet); if (JSch.getLogger().isEnabled(1)) JSch.getLogger().log(1, "SSH_MSG_NEWKEYS sent");  } private void checkHost(String paramString, int paramInt, KeyExchange paramKeyExchange) throws JSchException { String str1 = getConfig("StrictHostKeyChecking"); if (this.hostKeyAlias != null) paramString = this.hostKeyAlias;  byte[] arrayOfByte = paramKeyExchange.getHostKey(); String str2 = paramKeyExchange.getKeyType(); String str3 = paramKeyExchange.getFingerPrint(); if (this.hostKeyAlias == null && paramInt != 22) paramString = "[" + paramString + "]:" + paramInt;  HostKeyRepository hostKeyRepository = this.jsch.getHostKeyRepository(); int i = 0; synchronized (hostKeyRepository) { i = hostKeyRepository.check(paramString, arrayOfByte); }  boolean bool = false; if ((str1.equals("ask") || str1.equals("yes")) && i == 2) { String str = null; synchronized (hostKeyRepository) { str = hostKeyRepository.getKnownHostsRepositoryID(); }  if (str == null) str = "known_hosts";  boolean bool1 = false; if (this.userinfo != null) { String str5 = "WARNING: REMOTE HOST IDENTIFICATION HAS CHANGED!\nIT IS POSSIBLE THAT SOMEONE IS DOING SOMETHING NASTY!\nSomeone could be eavesdropping on you right now (man-in-the-middle attack)!\nIt is also possible that the " + str2 + " host key has just been changed.\n" + "The fingerprint for the " + str2 + " key sent by the remote host is\n" + str3 + ".\n" + "Please contact your system administrator.\n" + "Add correct host key in " + str + " to get rid of this message."; if (str1.equals("ask")) { bool1 = this.userinfo.promptYesNo(str5 + "\nDo you want to delete the old key and insert the new key?"); } else { this.userinfo.showMessage(str5); }  }  if (!bool1) throw new JSchException("HostKey has been changed: " + paramString);  synchronized (hostKeyRepository) { hostKeyRepository.remove(paramString, str2.equals("DSA") ? "ssh-dss" : "ssh-rsa", null); bool = true; }  }  if ((str1.equals("ask") || str1.equals("yes")) && i != 0 && !bool) { if (str1.equals("yes")) throw new JSchException("reject HostKey: " + this.host);  if (this.userinfo != null) { boolean bool1 = this.userinfo.promptYesNo("The authenticity of host '" + this.host + "' can't be established.\n" + str2 + " key fingerprint is " + str3 + ".\n" + "Are you sure you want to continue connecting?"); if (!bool1) throw new JSchException("reject HostKey: " + this.host);  bool = true; } else { if (i == 1) throw new JSchException("UnknownHostKey: " + this.host + ". " + str2 + " key fingerprint is " + str3);  throw new JSchException("HostKey has been changed: " + this.host); }  }  if (str1.equals("no") && 1 == i) bool = true;  if (i == 0 && JSch.getLogger().isEnabled(1)) JSch.getLogger().log(1, "Host '" + this.host + "' is known and mathces the " + str2 + " host key");  if (bool && JSch.getLogger().isEnabled(2)) JSch.getLogger().log(2, "Permanently added '" + this.host + "' (" + str2 + ") to the list of known hosts.");  String str4 = getConfig("HashKnownHosts"); if (str4.equals("yes") && hostKeyRepository instanceof KnownHosts) { this.hostkey = ((KnownHosts)hostKeyRepository).createHashedHostKey(paramString, arrayOfByte); } else { this.hostkey = new HostKey(paramString, arrayOfByte); }  if (bool) synchronized (hostKeyRepository) { hostKeyRepository.add(this.hostkey, this.userinfo); }   } public Channel openChannel(String paramString) throws JSchException { if (!this.isConnected) throw new JSchException("session is down");  try { Channel channel = Channel.getChannel(paramString); addChannel(channel); channel.init(); return channel; } catch (Exception exception) { return null; }  } public void encode(Packet paramPacket) throws Exception { if (this.deflater != null) paramPacket.buffer.index = this.deflater.compress(paramPacket.buffer.buffer, 5, paramPacket.buffer.index);  if (this.c2scipher != null) { paramPacket.padding(this.c2scipher_size); byte b = paramPacket.buffer.buffer[4]; synchronized (random) { random.fill(paramPacket.buffer.buffer, paramPacket.buffer.index - b, b); }  } else { paramPacket.padding(8); }  if (this.c2smac != null) { this.c2smac.update(this.seqo); this.c2smac.update(paramPacket.buffer.buffer, 0, paramPacket.buffer.index); this.c2smac.doFinal(paramPacket.buffer.buffer, paramPacket.buffer.index); }  if (this.c2scipher != null) { byte[] arrayOfByte = paramPacket.buffer.buffer; this.c2scipher.update(arrayOfByte, 0, paramPacket.buffer.index, arrayOfByte, 0); }  if (this.c2smac != null) paramPacket.buffer.skip(this.c2smac.getBlockSize());  } public Buffer read(Buffer paramBuffer) throws Exception { int i = 0; while (true) { paramBuffer.reset(); this.io.getByte(paramBuffer.buffer, paramBuffer.index, this.s2ccipher_size); paramBuffer.index += this.s2ccipher_size; if (this.s2ccipher != null) this.s2ccipher.update(paramBuffer.buffer, 0, this.s2ccipher_size, paramBuffer.buffer, 0);  i = paramBuffer.buffer[0] << 24 & 0xFF000000 | paramBuffer.buffer[1] << 16 & 0xFF0000 | paramBuffer.buffer[2] << 8 & 0xFF00 | paramBuffer.buffer[3] & 0xFF; if (i < 5 || i > 32764) throw new IOException("invalid data");  i = i + 4 - this.s2ccipher_size; if (paramBuffer.index + i > paramBuffer.buffer.length) { byte[] arrayOfByte = new byte[paramBuffer.index + i]; System.arraycopy(paramBuffer.buffer, 0, arrayOfByte, 0, paramBuffer.index); paramBuffer.buffer = arrayOfByte; }  if (i % this.s2ccipher_size != 0) { String str = "Bad packet length " + i; if (JSch.getLogger().isEnabled(4)) JSch.getLogger().log(4, str);  this.packet.reset(); paramBuffer.putByte((byte)1); paramBuffer.putInt(3); paramBuffer.putString(str.getBytes()); paramBuffer.putString("en".getBytes()); write(this.packet); disconnect(); throw new JSchException("SSH_MSG_DISCONNECT: " + str); }  if (i > 0) { this.io.getByte(paramBuffer.buffer, paramBuffer.index, i); paramBuffer.index += i; if (this.s2ccipher != null) this.s2ccipher.update(paramBuffer.buffer, this.s2ccipher_size, i, paramBuffer.buffer, this.s2ccipher_size);  }  if (this.s2cmac != null) { this.s2cmac.update(this.seqi); this.s2cmac.update(paramBuffer.buffer, 0, paramBuffer.index); this.s2cmac.doFinal(this.s2cmac_result1, 0); this.io.getByte(this.s2cmac_result2, 0, this.s2cmac_result2.length); if (!Arrays.equals(this.s2cmac_result1, this.s2cmac_result2)) throw new IOException("MAC Error");  }  this.seqi++; if (this.inflater != null) { byte b = paramBuffer.buffer[4]; this.uncompress_len[0] = paramBuffer.index - 5 - b; byte[] arrayOfByte = this.inflater.uncompress(paramBuffer.buffer, 5, this.uncompress_len); if (arrayOfByte != null) { paramBuffer.buffer = arrayOfByte; paramBuffer.index = 5 + this.uncompress_len[0]; } else { System.err.println("fail in inflater"); break; }  }  int j = paramBuffer.getCommand() & 0xFF; if (j == 1) { paramBuffer.rewind(); paramBuffer.getInt(); paramBuffer.getShort(); int k = paramBuffer.getInt(); byte[] arrayOfByte1 = paramBuffer.getString(); byte[] arrayOfByte2 = paramBuffer.getString(); throw new JSchException("SSH_MSG_DISCONNECT: " + k + " " + new String(arrayOfByte1) + " " + new String(arrayOfByte2)); }  if (j == 2) continue;  if (j == 3) { paramBuffer.rewind(); paramBuffer.getInt(); paramBuffer.getShort(); int k = paramBuffer.getInt(); if (JSch.getLogger().isEnabled(1)) JSch.getLogger().log(1, "Received SSH_MSG_UNIMPLEMENTED for " + k);  continue; }  if (j == 4) { paramBuffer.rewind(); paramBuffer.getInt(); paramBuffer.getShort(); continue; }  if (j == 93) { paramBuffer.rewind(); paramBuffer.getInt(); paramBuffer.getShort(); Channel channel = Channel.getChannel(paramBuffer.getInt(), this); if (channel == null) continue;  channel.addRemoteWindowSize(paramBuffer.getInt()); continue; }  if (j == 52) { this.isAuthed = true; if (this.inflater == null && this.deflater == null) { String str = this.guess[6]; initDeflater(str); str = this.guess[7]; initInflater(str); }  }  break; }  paramBuffer.rewind(); return paramBuffer; } byte[] getSessionId() { return this.session_id; } private void receive_newkeys(Buffer paramBuffer, KeyExchange paramKeyExchange) throws Exception { updateKeys(paramKeyExchange); this.in_kex = false; } private void updateKeys(KeyExchange paramKeyExchange) throws Exception { byte[] arrayOfByte1 = paramKeyExchange.getK(); byte[] arrayOfByte2 = paramKeyExchange.getH(); HASH hASH = paramKeyExchange.getHash(); if (this.session_id == null) { this.session_id = new byte[arrayOfByte2.length]; System.arraycopy(arrayOfByte2, 0, this.session_id, 0, arrayOfByte2.length); }  this.buf.reset(); this.buf.putMPInt(arrayOfByte1); this.buf.putByte(arrayOfByte2); this.buf.putByte((byte)65); this.buf.putByte(this.session_id); hASH.update(this.buf.buffer, 0, this.buf.index); this.IVc2s = hASH.digest(); int i = this.buf.index - this.session_id.length - 1; this.buf.buffer[i] = (byte)(this.buf.buffer[i] + 1); hASH.update(this.buf.buffer, 0, this.buf.index); this.IVs2c = hASH.digest(); this.buf.buffer[i] = (byte)(this.buf.buffer[i] + 1); hASH.update(this.buf.buffer, 0, this.buf.index); this.Ec2s = hASH.digest(); this.buf.buffer[i] = (byte)(this.buf.buffer[i] + 1); hASH.update(this.buf.buffer, 0, this.buf.index); this.Es2c = hASH.digest(); this.buf.buffer[i] = (byte)(this.buf.buffer[i] + 1); hASH.update(this.buf.buffer, 0, this.buf.index); this.MACc2s = hASH.digest(); this.buf.buffer[i] = (byte)(this.buf.buffer[i] + 1); hASH.update(this.buf.buffer, 0, this.buf.index); this.MACs2c = hASH.digest(); try { String str = this.guess[3]; Class clazz = Class.forName(getConfig(str)); this.s2ccipher = (Cipher)clazz.newInstance(); while (this.s2ccipher.getBlockSize() > this.Es2c.length) { this.buf.reset(); this.buf.putMPInt(arrayOfByte1); this.buf.putByte(arrayOfByte2); this.buf.putByte(this.Es2c); hASH.update(this.buf.buffer, 0, this.buf.index); byte[] arrayOfByte3 = hASH.digest(); byte[] arrayOfByte4 = new byte[this.Es2c.length + arrayOfByte3.length]; System.arraycopy(this.Es2c, 0, arrayOfByte4, 0, this.Es2c.length); System.arraycopy(arrayOfByte3, 0, arrayOfByte4, this.Es2c.length, arrayOfByte3.length); this.Es2c = arrayOfByte4; }  this.s2ccipher.init(1, this.Es2c, this.IVs2c); this.s2ccipher_size = this.s2ccipher.getIVSize(); str = this.guess[5]; clazz = Class.forName(getConfig(str)); this.s2cmac = (MAC)clazz.newInstance(); this.s2cmac.init(this.MACs2c); this.s2cmac_result1 = new byte[this.s2cmac.getBlockSize()]; this.s2cmac_result2 = new byte[this.s2cmac.getBlockSize()]; str = this.guess[2]; clazz = Class.forName(getConfig(str)); this.c2scipher = (Cipher)clazz.newInstance(); while (this.c2scipher.getBlockSize() > this.Ec2s.length) { this.buf.reset(); this.buf.putMPInt(arrayOfByte1); this.buf.putByte(arrayOfByte2); this.buf.putByte(this.Ec2s); hASH.update(this.buf.buffer, 0, this.buf.index); byte[] arrayOfByte3 = hASH.digest(); byte[] arrayOfByte4 = new byte[this.Ec2s.length + arrayOfByte3.length]; System.arraycopy(this.Ec2s, 0, arrayOfByte4, 0, this.Ec2s.length); System.arraycopy(arrayOfByte3, 0, arrayOfByte4, this.Ec2s.length, arrayOfByte3.length); this.Ec2s = arrayOfByte4; }  this.c2scipher.init(0, this.Ec2s, this.IVc2s); this.c2scipher_size = this.c2scipher.getIVSize(); str = this.guess[4]; clazz = Class.forName(getConfig(str)); this.c2smac = (MAC)clazz.newInstance(); this.c2smac.init(this.MACc2s); str = this.guess[6]; initDeflater(str); str = this.guess[7]; initInflater(str); } catch (Exception exception) { if (exception instanceof JSchException) throw exception;  throw new JSchException(exception.toString(), exception); }  } void write(Packet paramPacket, Channel paramChannel, int paramInt) throws Exception { while (true) { while (this.in_kex) { try { Thread.sleep(10L); } catch (InterruptedException interruptedException) {} }  synchronized (paramChannel) { if (paramChannel.rwsize >= paramInt) { paramChannel.rwsize -= paramInt; break; }  }  if (paramChannel.close || !paramChannel.isConnected()) throw new IOException("channel is broken");  boolean bool = false; int i = 0; byte b = 0; int j = -1; synchronized (paramChannel) { if (paramChannel.rwsize > 0) { int k = paramChannel.rwsize; if (k > paramInt) k = paramInt;  if (k != paramInt) i = paramPacket.shift(k, (this.c2smac != null) ? this.c2smac.getBlockSize() : 0);  b = paramPacket.buffer.getCommand(); j = paramChannel.getRecipient(); paramInt -= k; paramChannel.rwsize -= k; bool = true; }  }  if (bool) { _write(paramPacket); if (paramInt == 0) return;  paramPacket.unshift(b, j, i, paramInt); }  synchronized (paramChannel) { if (this.in_kex) continue;  if (paramChannel.rwsize >= paramInt) { paramChannel.rwsize -= paramInt; break; }  try { paramChannel.notifyme++; paramChannel.wait(100L); } catch (InterruptedException interruptedException) {  } finally { paramChannel.notifyme--; }  }  }  _write(paramPacket); } public void write(Packet paramPacket) throws Exception { while (this.in_kex) { byte b = paramPacket.buffer.getCommand(); if (b == 20 || b == 21 || b == 30 || b == 31 || b == 31 || b == 32 || b == 33 || b == 34 || b == 1) break;  try { Thread.sleep(10L); } catch (InterruptedException interruptedException) {} }  _write(paramPacket); } private void _write(Packet paramPacket) throws Exception { synchronized (this.lock) { encode(paramPacket); if (this.io != null) { this.io.put(paramPacket); this.seqo++; }  }  } public void run() { this.thread = this; Buffer buffer = new Buffer(); Packet packet = new Packet(buffer); int i = 0; int[] arrayOfInt1 = new int[1]; int[] arrayOfInt2 = new int[1]; KeyExchange keyExchange = null; byte b = 0; try { while (this.isConnected && this.thread != null) { byte[] arrayOfByte; Channel channel; int k, m, n, i1, i2; boolean bool; String str; Thread thread; try { buffer = read(buffer); b = 0; } catch (InterruptedIOException interruptedIOException) { if (!this.in_kex && b < this.serverAliveCountMax) { sendKeepAliveMsg(); b++; continue; }  throw interruptedIOException; }  int j = buffer.getCommand() & 0xFF; if (keyExchange != null && keyExchange.getState() == j) { boolean bool1 = keyExchange.next(buffer); if (!bool1) throw new JSchException("verify: " + bool1);  continue; }  switch (j) { case 20: keyExchange = receive_kexinit(buffer); continue;case 21: send_newkeys(); receive_newkeys(buffer, keyExchange); keyExchange = null; continue;case 94: buffer.getInt(); buffer.getByte(); buffer.getByte(); i = buffer.getInt(); channel = Channel.getChannel(i, this); arrayOfByte = buffer.getString(arrayOfInt1, arrayOfInt2); if (channel == null) continue;  if (arrayOfInt2[0] == 0) continue;  try { channel.write(arrayOfByte, arrayOfInt1[0], arrayOfInt2[0]); } catch (Exception exception) { try { channel.disconnect(); } catch (Exception exception1) {} continue; }  k = arrayOfInt2[0]; channel.setLocalWindowSize(channel.lwsize - k); if (channel.lwsize < channel.lwsize_max / 2) { packet.reset(); buffer.putByte((byte)93); buffer.putInt(channel.getRecipient()); buffer.putInt(channel.lwsize_max - channel.lwsize); write(packet); channel.setLocalWindowSize(channel.lwsize_max); }  continue;case 95: buffer.getInt(); buffer.getShort(); i = buffer.getInt(); channel = Channel.getChannel(i, this); buffer.getInt(); arrayOfByte = buffer.getString(arrayOfInt1, arrayOfInt2); if (channel == null) continue;  if (arrayOfInt2[0] == 0) continue;  channel.write_ext(arrayOfByte, arrayOfInt1[0], arrayOfInt2[0]); k = arrayOfInt2[0]; channel.setLocalWindowSize(channel.lwsize - k); if (channel.lwsize < channel.lwsize_max / 2) { packet.reset(); buffer.putByte((byte)93); buffer.putInt(channel.getRecipient()); buffer.putInt(channel.lwsize_max - channel.lwsize); write(packet); channel.setLocalWindowSize(channel.lwsize_max); }  continue;case 93: buffer.getInt(); buffer.getShort(); i = buffer.getInt(); channel = Channel.getChannel(i, this); if (channel == null) continue;  channel.addRemoteWindowSize(buffer.getInt()); continue;case 96: buffer.getInt(); buffer.getShort(); i = buffer.getInt(); channel = Channel.getChannel(i, this); if (channel != null) channel.eof_remote();  continue;case 97: buffer.getInt(); buffer.getShort(); i = buffer.getInt(); channel = Channel.getChannel(i, this); if (channel != null) channel.disconnect();  continue;case 91: buffer.getInt(); buffer.getShort(); i = buffer.getInt(); channel = Channel.getChannel(i, this); if (channel == null); m = buffer.getInt(); n = buffer.getInt(); i1 = buffer.getInt(); channel.setRemoteWindowSize(n); channel.setRemotePacketSize(i1); channel.setRecipient(m); continue;case 92: buffer.getInt(); buffer.getShort(); i = buffer.getInt(); channel = Channel.getChannel(i, this); if (channel == null); i2 = buffer.getInt(); channel.exitstatus = i2; channel.close = true; channel.eof_remote = true; channel.setRecipient(0); continue;case 98: buffer.getInt(); buffer.getShort(); i = buffer.getInt(); arrayOfByte = buffer.getString(); bool = (buffer.getByte() != 0) ? true : false; channel = Channel.getChannel(i, this); if (channel != null) { byte b1 = 100; if ((new String(arrayOfByte)).equals("exit-status")) { i = buffer.getInt(); channel.setExitStatus(i); b1 = 99; }  if (bool) { packet.reset(); buffer.putByte(b1); buffer.putInt(channel.getRecipient()); write(packet); }  }  continue;case 90: buffer.getInt(); buffer.getShort(); arrayOfByte = buffer.getString(); str = new String(arrayOfByte); if (!"forwarded-tcpip".equals(str) && (!"x11".equals(str) || !this.x11_forwarding) && (!"auth-agent@openssh.com".equals(str) || !this.agent_forwarding)) { packet.reset(); buffer.putByte((byte)92); buffer.putInt(buffer.getInt()); buffer.putInt(1); buffer.putString("".getBytes()); buffer.putString("".getBytes()); write(packet); } else { channel = Channel.getChannel(str); addChannel(channel); channel.getData(buffer); channel.init(); Thread thread1 = new Thread(channel); thread1.setName("Channel " + str + " " + this.host); if (this.daemon_thread) thread1.setDaemon(this.daemon_thread);  thread1.start(); continue; } case 99: buffer.getInt(); buffer.getShort(); i = buffer.getInt(); channel = Channel.getChannel(i, this); if (channel == null) continue;  channel.reply = 1; continue;case 100: buffer.getInt(); buffer.getShort(); i = buffer.getInt(); channel = Channel.getChannel(i, this); if (channel == null) continue;  channel.reply = 0; continue;case 80: buffer.getInt(); buffer.getShort(); arrayOfByte = buffer.getString(); bool = (buffer.getByte() != 0) ? true : false; if (bool) { packet.reset(); buffer.putByte((byte)82); write(packet); }  continue;case 81: case 82: thread = this.grr.getThread(); if (thread != null) { this.grr.setReply((j == 81) ? 1 : 0); thread.interrupt(); }  continue; }  throw new IOException("Unknown SSH message type " + j); }  } catch (Exception exception) { if (JSch.getLogger().isEnabled(1)) JSch.getLogger().log(1, "Caught an exception, leaving main loop due to " + exception.getMessage());  }  try { disconnect(); } catch (NullPointerException nullPointerException) {  } catch (Exception exception) {} this.isConnected = false; } public void disconnect() { if (!this.isConnected) return;  if (JSch.getLogger().isEnabled(1)) JSch.getLogger().log(1, "Disconnecting from " + this.host + " port " + this.port);  Channel.disconnect(this); this.isConnected = false; PortWatcher.delPort(this); ChannelForwardedTCPIP.delPort(this); synchronized (this.lock) { if (this.connectThread != null) { Thread.yield(); this.connectThread.interrupt(); this.connectThread = null; }  }  this.thread = null; try { if (this.io != null) { if (this.io.in != null) this.io.in.close();  if (this.io.out != null) this.io.out.close();  if (this.io.out_ext != null) this.io.out_ext.close();  }  if (this.proxy == null) { if (this.socket != null) this.socket.close();  } else { synchronized (this.proxy) { this.proxy.close(); }  this.proxy = null; }  } catch (Exception exception) {} this.io = null; this.socket = null; this.jsch.removeSession(this); } public int setPortForwardingL(int paramInt1, String paramString, int paramInt2) throws JSchException { return setPortForwardingL("127.0.0.1", paramInt1, paramString, paramInt2); } public int setPortForwardingL(String paramString1, int paramInt1, String paramString2, int paramInt2) throws JSchException { return setPortForwardingL(paramString1, paramInt1, paramString2, paramInt2, null); } public int setPortForwardingL(String paramString1, int paramInt1, String paramString2, int paramInt2, ServerSocketFactory paramServerSocketFactory) throws JSchException { PortWatcher portWatcher = PortWatcher.addPort(this, paramString1, paramInt1, paramString2, paramInt2, paramServerSocketFactory); Thread thread = new Thread(portWatcher); thread.setName("PortWatcher Thread for " + paramString2); if (this.daemon_thread) thread.setDaemon(this.daemon_thread);  thread.start(); return portWatcher.lport; } public void delPortForwardingL(int paramInt) throws JSchException { delPortForwardingL("127.0.0.1", paramInt); } public void delPortForwardingL(String paramString, int paramInt) throws JSchException { PortWatcher.delPort(this, paramString, paramInt); } public String[] getPortForwardingL() throws JSchException { return PortWatcher.getPortForwarding(this); } public void setPortForwardingR(int paramInt1, String paramString, int paramInt2) throws JSchException { setPortForwardingR(null, paramInt1, paramString, paramInt2, (SocketFactory)null); } public void setPortForwardingR(String paramString1, int paramInt1, String paramString2, int paramInt2) throws JSchException { setPortForwardingR(paramString1, paramInt1, paramString2, paramInt2, (SocketFactory)null); } public void setPortForwardingR(int paramInt1, String paramString, int paramInt2, SocketFactory paramSocketFactory) throws JSchException { setPortForwardingR(null, paramInt1, paramString, paramInt2, paramSocketFactory); } public void setPortForwardingR(String paramString1, int paramInt1, String paramString2, int paramInt2, SocketFactory paramSocketFactory) throws JSchException { ChannelForwardedTCPIP.addPort(this, paramString1, paramInt1, paramString2, paramInt2, paramSocketFactory); setPortForwarding(paramString1, paramInt1); } public void setPortForwardingR(int paramInt, String paramString) throws JSchException { setPortForwardingR((String)null, paramInt, paramString, (Object[])null); } public void setPortForwardingR(int paramInt, String paramString, Object[] paramArrayOfObject) throws JSchException { setPortForwardingR((String)null, paramInt, paramString, paramArrayOfObject); } public void setPortForwardingR(String paramString1, int paramInt, String paramString2, Object[] paramArrayOfObject) throws JSchException { ChannelForwardedTCPIP.addPort(this, paramString1, paramInt, paramString2, paramArrayOfObject); setPortForwarding(paramString1, paramInt); } private class GlobalRequestReply {
/*  542 */     private Thread thread; private int reply; private final Session this$0; private GlobalRequestReply(Session this$0) { Session.this = Session.this; this.thread = null; this.reply = -1; } void setThread(Thread param1Thread) { this.thread = param1Thread; this.reply = -1; } Thread getThread() { return this.thread; } void setReply(int param1Int) { this.reply = param1Int; } int getReply() { return this.reply; } } private void setPortForwarding(String paramString, int paramInt) throws JSchException { synchronized (this.grr) { Buffer buffer = new Buffer(100); Packet packet = new Packet(buffer); String str = ChannelForwardedTCPIP.normalize(paramString); try { packet.reset(); buffer.putByte((byte)80); buffer.putString("tcpip-forward".getBytes()); buffer.putByte((byte)1); buffer.putString(str.getBytes()); buffer.putInt(paramInt); write(packet); } catch (Exception exception) { if (exception instanceof Throwable) throw new JSchException(exception.toString(), exception);  throw new JSchException(exception.toString()); }  this.grr.setThread(Thread.currentThread()); try { Thread.sleep(10000L); } catch (Exception exception) {} int i = this.grr.getReply(); this.grr.setThread(null); if (i == 0) throw new JSchException("remote port forwarding failed for listen port " + paramInt);  }  } public void delPortForwardingR(int paramInt) throws JSchException { ChannelForwardedTCPIP.delPort(this, paramInt); } Session(JSch paramJSch) throws JSchException { this.in_kex = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  803 */     this.uncompress_len = new int[1];
/*      */     
/*  805 */     this.s2ccipher_size = 8;
/*  806 */     this.c2scipher_size = 8;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1622 */     this.grr = new GlobalRequestReply();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1825 */     this.hostkey = null; this.jsch = paramJSch; this.buf = new Buffer(); this.packet = new Packet(this.buf); }
/* 1826 */   private void initDeflater(String paramString) throws JSchException { if (paramString.equals("none")) { this.deflater = null; return; }  String str = getConfig(paramString); if (str != null && (paramString.equals("zlib") || (this.isAuthed && paramString.equals("zlib@openssh.com")))) try { Class clazz = Class.forName(str); this.deflater = (Compression)clazz.newInstance(); int i = 6; try { i = Integer.parseInt(getConfig("compression_level")); } catch (Exception exception) {} this.deflater.init(1, i); } catch (Exception exception) { throw new JSchException(exception.toString(), exception); }   } private void initInflater(String paramString) throws JSchException { if (paramString.equals("none")) { this.inflater = null; return; }  String str = getConfig(paramString); if (str != null && (paramString.equals("zlib") || (this.isAuthed && paramString.equals("zlib@openssh.com")))) try { Class clazz = Class.forName(str); this.inflater = (Compression)clazz.newInstance(); this.inflater.init(0, 0); } catch (Exception exception) { throw new JSchException(exception.toString(), exception); }   } void addChannel(Channel paramChannel) { paramChannel.setSession(this); } public void setProxy(Proxy paramProxy) { this.proxy = paramProxy; } public void setHost(String paramString) { this.host = paramString; } public void setPort(int paramInt) { this.port = paramInt; } void setUserName(String paramString) { this.username = paramString; } public void setUserInfo(UserInfo paramUserInfo) { this.userinfo = paramUserInfo; } public UserInfo getUserInfo() { return this.userinfo; } public void setInputStream(InputStream paramInputStream) { this.in = paramInputStream; } public void setOutputStream(OutputStream paramOutputStream) { this.out = paramOutputStream; } public void setX11Host(String paramString) { ChannelX11.setHost(paramString); } public void setX11Port(int paramInt) { ChannelX11.setPort(paramInt); } public void setX11Cookie(String paramString) { ChannelX11.setCookie(paramString); } public void setPassword(String paramString) { if (paramString != null) this.password = Util.str2byte(paramString);  } public void setPassword(byte[] paramArrayOfbyte) { if (paramArrayOfbyte != null) { this.password = new byte[paramArrayOfbyte.length]; System.arraycopy(paramArrayOfbyte, 0, this.password, 0, paramArrayOfbyte.length); }  } public void setConfig(Properties paramProperties) { setConfig(paramProperties); } public void setConfig(Hashtable paramHashtable) { synchronized (this.lock) { if (this.config == null) this.config = new Hashtable();  for (Enumeration enumeration = paramHashtable.keys(); enumeration.hasMoreElements(); ) { String str = enumeration.nextElement(); this.config.put(str, (String)paramHashtable.get(str)); }  }  } public void setConfig(String paramString1, String paramString2) { synchronized (this.lock) { if (this.config == null) this.config = new Hashtable();  this.config.put(paramString1, paramString2); }  } public String getConfig(String paramString) { Object object = null; if (this.config != null) { object = this.config.get(paramString); if (object instanceof String) return (String)object;  }  this; object = JSch.getConfig(paramString); if (object instanceof String) return (String)object;  return null; } public void setSocketFactory(SocketFactory paramSocketFactory) { this.socket_factory = paramSocketFactory; } public boolean isConnected() { return this.isConnected; } public int getTimeout() { return this.timeout; } public void setTimeout(int paramInt) throws JSchException { if (this.socket == null) { if (paramInt < 0) throw new JSchException("invalid timeout value");  this.timeout = paramInt; return; }  try { this.socket.setSoTimeout(paramInt); this.timeout = paramInt; } catch (Exception exception) { if (exception instanceof Throwable) throw new JSchException(exception.toString(), exception);  throw new JSchException(exception.toString()); }  } public String getServerVersion() { return new String(this.V_S); } public String getClientVersion() { return new String(this.V_C); } public void setClientVersion(String paramString) { this.V_C = paramString.getBytes(); } public void sendIgnore() throws Exception { Buffer buffer = new Buffer(); Packet packet = new Packet(buffer); packet.reset(); buffer.putByte((byte)2); write(packet); } private static final byte[] keepalivemsg = "keepalive@jcraft.com".getBytes(); private HostKey hostkey; public void sendKeepAliveMsg() throws Exception { Buffer buffer = new Buffer(); Packet packet = new Packet(buffer); packet.reset(); buffer.putByte((byte)80); buffer.putString(keepalivemsg); buffer.putByte((byte)1); write(packet); } public HostKey getHostKey() { return this.hostkey; }
/* 1827 */   public String getHost() { return this.host; }
/* 1828 */   public String getUserName() { return this.username; } public int getPort() {
/* 1829 */     return this.port;
/*      */   } public void setHostKeyAlias(String paramString) {
/* 1831 */     this.hostKeyAlias = paramString;
/*      */   }
/*      */   public String getHostKeyAlias() {
/* 1834 */     return this.hostKeyAlias;
/*      */   }
/*      */   
/*      */   public void setServerAliveInterval(int paramInt) throws JSchException {
/* 1838 */     setTimeout(paramInt);
/* 1839 */     this.serverAliveInterval = paramInt;
/*      */   }
/*      */   public void setServerAliveCountMax(int paramInt) {
/* 1842 */     this.serverAliveCountMax = paramInt;
/*      */   }
/*      */   
/*      */   public int getServerAliveInterval() {
/* 1846 */     return this.serverAliveInterval;
/*      */   }
/*      */   public int getServerAliveCountMax() {
/* 1849 */     return this.serverAliveCountMax;
/*      */   }
/*      */   
/*      */   public void setDaemonThread(boolean paramBoolean) {
/* 1853 */     this.daemon_thread = paramBoolean;
/*      */   }
/*      */   
/*      */   private String[] checkCiphers(String paramString) {
/* 1857 */     if (paramString == null || paramString.length() == 0) {
/* 1858 */       return null;
/*      */     }
/* 1860 */     if (JSch.getLogger().isEnabled(1)) {
/* 1861 */       JSch.getLogger().log(1, "CheckCiphers: " + paramString);
/*      */     }
/*      */ 
/*      */     
/* 1865 */     Vector vector = new Vector();
/* 1866 */     String[] arrayOfString1 = Util.split(paramString, ",");
/* 1867 */     for (byte b = 0; b < arrayOfString1.length; b++) {
/* 1868 */       if (!checkCipher(getConfig(arrayOfString1[b]))) {
/* 1869 */         vector.addElement(arrayOfString1[b]);
/*      */       }
/*      */     } 
/* 1872 */     if (vector.size() == 0)
/* 1873 */       return null; 
/* 1874 */     String[] arrayOfString2 = new String[vector.size()];
/* 1875 */     System.arraycopy(vector.toArray(), 0, arrayOfString2, 0, vector.size());
/*      */     
/* 1877 */     if (JSch.getLogger().isEnabled(1)) {
/* 1878 */       for (byte b1 = 0; b1 < arrayOfString2.length; b1++) {
/* 1879 */         JSch.getLogger().log(1, arrayOfString2[b1] + " is not available.");
/*      */       }
/*      */     }
/*      */ 
/*      */     
/* 1884 */     return arrayOfString2;
/*      */   }
/*      */   
/*      */   static boolean checkCipher(String paramString) {
/*      */     try {
/* 1889 */       Class clazz = Class.forName(paramString);
/* 1890 */       Cipher cipher = (Cipher)clazz.newInstance();
/* 1891 */       cipher.init(0, new byte[cipher.getBlockSize()], new byte[cipher.getIVSize()]);
/*      */ 
/*      */       
/* 1894 */       return true;
/*      */     } catch (Exception exception) {
/*      */       
/* 1897 */       return false;
/*      */     } 
/*      */   }
/*      */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/Session.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */