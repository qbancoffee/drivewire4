/*     */ package com.jcraft.jsch;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.net.InetAddress;
/*     */ import java.net.Socket;
/*     */ import java.net.UnknownHostException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProxySOCKS4
/*     */   implements Proxy
/*     */ {
/*  42 */   private static int DEFAULTPORT = 1080;
/*     */   private String proxy_host;
/*     */   private int proxy_port;
/*     */   private InputStream in;
/*     */   private OutputStream out;
/*     */   private Socket socket;
/*     */   private String user;
/*     */   private String passwd;
/*     */   
/*     */   public ProxySOCKS4(String paramString) {
/*  52 */     int i = DEFAULTPORT;
/*  53 */     String str = paramString;
/*  54 */     if (paramString.indexOf(':') != -1) {
/*     */       try {
/*  56 */         str = paramString.substring(0, paramString.indexOf(':'));
/*  57 */         i = Integer.parseInt(paramString.substring(paramString.indexOf(':') + 1));
/*     */       }
/*  59 */       catch (Exception exception) {}
/*     */     }
/*     */     
/*  62 */     this.proxy_host = str;
/*  63 */     this.proxy_port = i;
/*     */   }
/*     */   public ProxySOCKS4(String paramString, int paramInt) {
/*  66 */     this.proxy_host = paramString;
/*  67 */     this.proxy_port = paramInt;
/*     */   }
/*     */   public void setUserPasswd(String paramString1, String paramString2) {
/*  70 */     this.user = paramString1;
/*  71 */     this.passwd = paramString2;
/*     */   }
/*     */   public void connect(SocketFactory paramSocketFactory, String paramString, int paramInt1, int paramInt2) throws JSchException {
/*     */     try {
/*  75 */       if (paramSocketFactory == null) {
/*  76 */         this.socket = Util.createSocket(this.proxy_host, this.proxy_port, paramInt2);
/*     */         
/*  78 */         this.in = this.socket.getInputStream();
/*  79 */         this.out = this.socket.getOutputStream();
/*     */       } else {
/*     */         
/*  82 */         this.socket = paramSocketFactory.createSocket(this.proxy_host, this.proxy_port);
/*  83 */         this.in = paramSocketFactory.getInputStream(this.socket);
/*  84 */         this.out = paramSocketFactory.getOutputStream(this.socket);
/*     */       } 
/*  86 */       if (paramInt2 > 0) {
/*  87 */         this.socket.setSoTimeout(paramInt2);
/*     */       }
/*  89 */       this.socket.setTcpNoDelay(true);
/*     */       
/*  91 */       byte[] arrayOfByte = new byte[1024];
/*  92 */       int i = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 112 */       i = 0;
/* 113 */       arrayOfByte[i++] = 4;
/* 114 */       arrayOfByte[i++] = 1;
/*     */       
/* 116 */       arrayOfByte[i++] = (byte)(paramInt1 >>> 8);
/* 117 */       arrayOfByte[i++] = (byte)(paramInt1 & 0xFF);
/*     */       
/*     */       try {
/* 120 */         InetAddress inetAddress = InetAddress.getByName(paramString);
/* 121 */         byte[] arrayOfByte1 = inetAddress.getAddress();
/* 122 */         for (byte b1 = 0; b1 < arrayOfByte1.length; b1++) {
/* 123 */           arrayOfByte[i++] = arrayOfByte1[b1];
/*     */         }
/*     */       } catch (UnknownHostException unknownHostException) {
/*     */         
/* 127 */         throw new JSchException("ProxySOCKS4: " + unknownHostException.toString(), unknownHostException);
/*     */       } 
/*     */       
/* 130 */       if (this.user != null) {
/* 131 */         System.arraycopy(this.user.getBytes(), 0, arrayOfByte, i, this.user.length());
/* 132 */         i += this.user.length();
/*     */       } 
/* 134 */       arrayOfByte[i++] = 0;
/* 135 */       this.out.write(arrayOfByte, 0, i);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 164 */       byte b = 8;
/* 165 */       int j = 0;
/* 166 */       while (j < b) {
/* 167 */         int k = this.in.read(arrayOfByte, j, b - j);
/* 168 */         if (k <= 0) {
/* 169 */           throw new JSchException("ProxySOCKS4: stream is closed");
/*     */         }
/* 171 */         j += k;
/*     */       } 
/* 173 */       if (arrayOfByte[0] != 0) {
/* 174 */         throw new JSchException("ProxySOCKS4: server returns VN " + arrayOfByte[0]);
/*     */       }
/* 176 */       if (arrayOfByte[1] != 90) { try {
/* 177 */           this.socket.close();
/* 178 */         } catch (Exception exception) {}
/*     */         
/* 180 */         String str = "ProxySOCKS4: server returns CD " + arrayOfByte[1];
/* 181 */         throw new JSchException(str); }
/*     */     
/*     */     } catch (RuntimeException runtimeException) {
/*     */       
/* 185 */       throw runtimeException;
/*     */     } catch (Exception exception) {
/*     */       try {
/* 188 */         if (this.socket != null) this.socket.close(); 
/* 189 */       } catch (Exception exception1) {}
/*     */       
/* 191 */       throw new JSchException("ProxySOCKS4: " + exception.toString());
/*     */     } 
/*     */   }
/* 194 */   public InputStream getInputStream() { return this.in; }
/* 195 */   public OutputStream getOutputStream() { return this.out; } public Socket getSocket() {
/* 196 */     return this.socket;
/*     */   } public void close() {
/*     */     try {
/* 199 */       if (this.in != null) this.in.close(); 
/* 200 */       if (this.out != null) this.out.close(); 
/* 201 */       if (this.socket != null) this.socket.close();
/*     */     
/* 203 */     } catch (Exception exception) {}
/*     */     
/* 205 */     this.in = null;
/* 206 */     this.out = null;
/* 207 */     this.socket = null;
/*     */   }
/*     */   public static int getDefaultPort() {
/* 210 */     return DEFAULTPORT;
/*     */   }
/*     */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/ProxySOCKS4.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */