/*    */ package com.jcraft.jsch;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class RequestPtyReq
/*    */   extends Request
/*    */ {
/* 33 */   private String ttype = "vt100";
/* 34 */   private int tcol = 80;
/* 35 */   private int trow = 24;
/* 36 */   private int twp = 640;
/* 37 */   private int thp = 480;
/*    */   
/* 39 */   private byte[] terminal_mode = "".getBytes();
/*    */ 
/*    */   
/*    */   void setCode(String paramString) {}
/*    */   
/*    */   void setTType(String paramString) {
/* 45 */     this.ttype = paramString;
/*    */   }
/*    */   
/*    */   void setTerminalMode(byte[] paramArrayOfbyte) {
/* 49 */     this.terminal_mode = paramArrayOfbyte;
/*    */   }
/*    */   
/*    */   void setTSize(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 53 */     this.tcol = paramInt1;
/* 54 */     this.trow = paramInt2;
/* 55 */     this.twp = paramInt3;
/* 56 */     this.thp = paramInt4;
/*    */   }
/*    */   
/*    */   public void request(Session paramSession, Channel paramChannel) throws Exception {
/* 60 */     super.request(paramSession, paramChannel);
/*    */     
/* 62 */     Buffer buffer = new Buffer();
/* 63 */     Packet packet = new Packet(buffer);
/*    */     
/* 65 */     packet.reset();
/* 66 */     buffer.putByte((byte)98);
/* 67 */     buffer.putInt(paramChannel.getRecipient());
/* 68 */     buffer.putString("pty-req".getBytes());
/* 69 */     buffer.putByte((byte)(waitForReply() ? 1 : 0));
/* 70 */     buffer.putString(this.ttype.getBytes());
/* 71 */     buffer.putInt(this.tcol);
/* 72 */     buffer.putInt(this.trow);
/* 73 */     buffer.putInt(this.twp);
/* 74 */     buffer.putInt(this.thp);
/* 75 */     buffer.putString(this.terminal_mode);
/* 76 */     write(packet);
/*    */   }
/*    */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/RequestPtyReq.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */