/*     */ package com.jcraft.jsch;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.net.Socket;
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ChannelX11
/*     */   extends Channel
/*     */ {
/*     */   private static final int LOCAL_WINDOW_SIZE_MAX = 131072;
/*     */   private static final int LOCAL_MAXIMUM_PACKET_SIZE = 16384;
/*     */   private static final int TIMEOUT = 10000;
/*  41 */   private static String host = "127.0.0.1";
/*  42 */   private static int port = 6000;
/*     */   
/*     */   private boolean init = true;
/*     */   
/*  46 */   static byte[] cookie = null;
/*  47 */   private static byte[] cookie_hex = null;
/*     */   
/*  49 */   private static Hashtable faked_cookie_pool = new Hashtable();
/*  50 */   private static Hashtable faked_cookie_hex_pool = new Hashtable();
/*     */   
/*  52 */   private static byte[] table = new byte[] { 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 97, 98, 99, 100, 101, 102 };
/*     */ 
/*     */   
/*  55 */   private Socket socket = null; private byte[] cache;
/*     */   
/*     */   static int revtable(byte paramByte) {
/*  58 */     for (byte b = 0; b < table.length; b++) {
/*  59 */       if (table[b] == paramByte) return b; 
/*     */     } 
/*  61 */     return 0;
/*     */   }
/*     */   static void setCookie(String paramString) {
/*  64 */     cookie_hex = paramString.getBytes();
/*  65 */     cookie = new byte[16];
/*  66 */     for (byte b = 0; b < 16; b++)
/*  67 */       cookie[b] = (byte)(revtable(cookie_hex[b * 2]) << 4 & 0xF0 | revtable(cookie_hex[b * 2 + 1]) & 0xF); 
/*     */   }
/*     */   
/*     */   static void setHost(String paramString) {
/*  71 */     host = paramString; } static void setPort(int paramInt) {
/*  72 */     port = paramInt;
/*     */   } static byte[] getFakedCookie(Session paramSession) {
/*  74 */     synchronized (faked_cookie_hex_pool) {
/*  75 */       byte[] arrayOfByte = (byte[])faked_cookie_hex_pool.get(paramSession);
/*  76 */       if (arrayOfByte == null) {
/*  77 */         Random random = Session.random;
/*  78 */         arrayOfByte = new byte[16];
/*  79 */         synchronized (random) {
/*  80 */           random.fill(arrayOfByte, 0, 16);
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  89 */         faked_cookie_pool.put(paramSession, arrayOfByte);
/*  90 */         byte[] arrayOfByte1 = new byte[32];
/*  91 */         for (byte b = 0; b < 16; b++) {
/*  92 */           arrayOfByte1[2 * b] = table[arrayOfByte[b] >>> 4 & 0xF];
/*  93 */           arrayOfByte1[2 * b + 1] = table[arrayOfByte[b] & 0xF];
/*     */         } 
/*  95 */         faked_cookie_hex_pool.put(paramSession, arrayOfByte1);
/*  96 */         arrayOfByte = arrayOfByte1;
/*     */       } 
/*  98 */       return arrayOfByte;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/*     */     try {
/* 129 */       this.socket = Util.createSocket(host, port, 10000);
/* 130 */       this.socket.setTcpNoDelay(true);
/* 131 */       this.io = new IO();
/* 132 */       this.io.setInputStream(this.socket.getInputStream());
/* 133 */       this.io.setOutputStream(this.socket.getOutputStream());
/* 134 */       sendOpenConfirmation();
/*     */     } catch (Exception exception) {
/*     */       
/* 137 */       sendOpenFailure(1);
/* 138 */       this.close = true;
/* 139 */       disconnect();
/*     */       
/*     */       return;
/*     */     } 
/* 143 */     this.thread = Thread.currentThread();
/* 144 */     Buffer buffer = new Buffer(this.rmpsize);
/* 145 */     Packet packet = new Packet(buffer);
/* 146 */     int i = 0;
/*     */ 
/*     */     
/*     */     try {
/* 150 */       while (this.thread != null && this.io != null && this.io.in != null) {
/* 151 */         i = this.io.in.read(buffer.buffer, 14, buffer.buffer.length - 14 - 32 - 20);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 156 */         if (i <= 0) {
/* 157 */           eof();
/*     */           break;
/*     */         } 
/* 160 */         if (this.close)
/* 161 */           break;  packet.reset();
/* 162 */         buffer.putByte((byte)94);
/* 163 */         buffer.putInt(this.recipient);
/* 164 */         buffer.putInt(i);
/* 165 */         buffer.skip(i);
/* 166 */         getSession().write(packet, this, i);
/*     */       }
/*     */     
/* 169 */     } catch (Exception exception) {}
/*     */ 
/*     */     
/* 172 */     disconnect();
/*     */   }
/*     */   
/* 175 */   ChannelX11() { this.cache = new byte[0]; setLocalWindowSizeMax(131072); setLocalWindowSize(131072); setLocalPacketSize(16384);
/*     */     this.type = "x11".getBytes();
/* 177 */     this.connected = true; } private byte[] addCache(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) { byte[] arrayOfByte = new byte[this.cache.length + paramInt2];
/* 178 */     System.arraycopy(paramArrayOfbyte, paramInt1, arrayOfByte, this.cache.length, paramInt2);
/* 179 */     if (this.cache.length > 0)
/* 180 */       System.arraycopy(this.cache, 0, arrayOfByte, 0, this.cache.length); 
/* 181 */     this.cache = arrayOfByte;
/* 182 */     return this.cache; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void write(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException {
/* 188 */     if (this.init) {
/*     */       
/* 190 */       Session session = null;
/*     */       try {
/* 192 */         session = getSession();
/*     */       } catch (JSchException jSchException) {
/*     */         
/* 195 */         throw new IOException(jSchException.toString());
/*     */       } 
/*     */       
/* 198 */       paramArrayOfbyte = addCache(paramArrayOfbyte, paramInt1, paramInt2);
/* 199 */       paramInt1 = 0;
/* 200 */       paramInt2 = paramArrayOfbyte.length;
/*     */       
/* 202 */       if (paramInt2 < 9) {
/*     */         return;
/*     */       }
/* 205 */       int i = (paramArrayOfbyte[paramInt1 + 6] & 0xFF) * 256 + (paramArrayOfbyte[paramInt1 + 7] & 0xFF);
/* 206 */       int j = (paramArrayOfbyte[paramInt1 + 8] & 0xFF) * 256 + (paramArrayOfbyte[paramInt1 + 9] & 0xFF);
/*     */       
/* 208 */       if ((paramArrayOfbyte[paramInt1] & 0xFF) != 66)
/*     */       {
/* 210 */         if ((paramArrayOfbyte[paramInt1] & 0xFF) == 108) {
/* 211 */           i = i >>> 8 & 0xFF | i << 8 & 0xFF00;
/* 212 */           j = j >>> 8 & 0xFF | j << 8 & 0xFF00;
/*     */         } 
/*     */       }
/*     */ 
/*     */ 
/*     */       
/* 218 */       if (paramInt2 < 12 + i + (-i & 0x3) + j) {
/*     */         return;
/*     */       }
/* 221 */       byte[] arrayOfByte1 = new byte[j];
/* 222 */       System.arraycopy(paramArrayOfbyte, paramInt1 + 12 + i + (-i & 0x3), arrayOfByte1, 0, j);
/* 223 */       byte[] arrayOfByte2 = null;
/*     */       
/* 225 */       synchronized (faked_cookie_pool) {
/* 226 */         arrayOfByte2 = (byte[])faked_cookie_pool.get(session);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 242 */       if (equals(arrayOfByte1, arrayOfByte2)) {
/* 243 */         if (cookie != null) {
/* 244 */           System.arraycopy(cookie, 0, paramArrayOfbyte, paramInt1 + 12 + i + (-i & 0x3), j);
/*     */         }
/*     */       } else {
/*     */         
/* 248 */         this.thread = null;
/* 249 */         eof();
/* 250 */         this.io.close();
/* 251 */         disconnect();
/*     */       } 
/* 253 */       this.init = false;
/* 254 */       this.io.put(paramArrayOfbyte, paramInt1, paramInt2);
/* 255 */       this.cache = null;
/*     */       return;
/*     */     } 
/* 258 */     this.io.put(paramArrayOfbyte, paramInt1, paramInt2);
/*     */   }
/*     */   
/*     */   private static boolean equals(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) {
/* 262 */     if (paramArrayOfbyte1.length != paramArrayOfbyte2.length) return false; 
/* 263 */     for (byte b = 0; b < paramArrayOfbyte1.length; b++) {
/* 264 */       if (paramArrayOfbyte1[b] != paramArrayOfbyte2[b]) return false; 
/*     */     } 
/* 266 */     return true;
/*     */   }
/*     */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/ChannelX11.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */