package com.jcraft.jsch;

public interface Compression {
  public static final int INFLATER = 0;
  
  public static final int DEFLATER = 1;
  
  void init(int paramInt1, int paramInt2);
  
  int compress(byte[] paramArrayOfbyte, int paramInt1, int paramInt2);
  
  byte[] uncompress(byte[] paramArrayOfbyte, int paramInt, int[] paramArrayOfint);
}


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/Compression.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */