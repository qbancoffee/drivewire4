/*     */ package com.jcraft.jsch;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class IdentityFile
/*     */   implements Identity
/*     */ {
/*     */   String identity;
/*     */   byte[] key;
/*     */   byte[] iv;
/*     */   private JSch jsch;
/*     */   private HASH hash;
/*     */   private byte[] encoded_data;
/*     */   private Cipher cipher;
/*     */   private byte[] P_array;
/*     */   private byte[] Q_array;
/*     */   private byte[] G_array;
/*     */   private byte[] pub_array;
/*     */   private byte[] prv_array;
/*     */   private byte[] n_array;
/*     */   private byte[] e_array;
/*     */   private byte[] d_array;
/*  57 */   private String algname = "ssh-rsa";
/*     */   
/*     */   private static final int ERROR = 0;
/*     */   
/*     */   private static final int RSA = 1;
/*     */   
/*     */   private static final int DSS = 2;
/*     */   private static final int UNKNOWN = 3;
/*     */   private static final int OPENSSH = 0;
/*     */   private static final int FSECURE = 1;
/*     */   private static final int PUTTY = 2;
/*  68 */   private int type = 0;
/*  69 */   private int keytype = 0;
/*     */   
/*  71 */   private byte[] publickeyblob = null;
/*     */   
/*     */   private boolean encrypted = true;
/*     */   
/*     */   static IdentityFile newInstance(String paramString1, String paramString2, JSch paramJSch) throws JSchException {
/*  76 */     byte[] arrayOfByte1 = null;
/*  77 */     byte[] arrayOfByte2 = null;
/*     */     
/*  79 */     File file = null;
/*  80 */     FileInputStream fileInputStream = null;
/*     */     try {
/*  82 */       file = new File(paramString1);
/*  83 */       fileInputStream = new FileInputStream(paramString1);
/*  84 */       arrayOfByte1 = new byte[(int)file.length()];
/*  85 */       int i = 0;
/*     */       while (true) {
/*  87 */         int j = fileInputStream.read(arrayOfByte1, i, arrayOfByte1.length - i);
/*  88 */         if (j <= 0)
/*     */           break; 
/*  90 */         i += j;
/*     */       } 
/*  92 */       fileInputStream.close();
/*     */     } catch (Exception exception) {
/*     */       try {
/*  95 */         if (fileInputStream != null) fileInputStream.close(); 
/*  96 */       } catch (Exception exception1) {}
/*  97 */       if (exception instanceof Throwable)
/*  98 */         throw new JSchException(exception.toString(), exception); 
/*  99 */       throw new JSchException(exception.toString());
/*     */     } 
/*     */     
/* 102 */     String str = paramString2;
/* 103 */     if (paramString2 == null) {
/* 104 */       str = paramString1 + ".pub";
/*     */     }
/*     */     
/*     */     try {
/* 108 */       file = new File(str);
/* 109 */       fileInputStream = new FileInputStream(str);
/* 110 */       arrayOfByte2 = new byte[(int)file.length()];
/* 111 */       int i = 0;
/*     */       while (true) {
/* 113 */         int j = fileInputStream.read(arrayOfByte2, i, arrayOfByte2.length - i);
/* 114 */         if (j <= 0)
/*     */           break; 
/* 116 */         i += j;
/*     */       } 
/* 118 */       fileInputStream.close();
/*     */     } catch (Exception exception) {
/*     */       try {
/* 121 */         if (fileInputStream != null) fileInputStream.close(); 
/* 122 */       } catch (Exception exception1) {}
/* 123 */       if (paramString2 != null) {
/*     */         
/* 125 */         if (exception instanceof Throwable)
/* 126 */           throw new JSchException(exception.toString(), exception); 
/* 127 */         throw new JSchException(exception.toString());
/*     */       } 
/*     */     } 
/* 130 */     return newInstance(paramString1, arrayOfByte1, arrayOfByte2, paramJSch);
/*     */   }
/*     */   
/*     */   static IdentityFile newInstance(String paramString, byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, JSch paramJSch) throws JSchException {
/*     */     try {
/* 135 */       return new IdentityFile(paramString, paramArrayOfbyte1, paramArrayOfbyte2, paramJSch);
/*     */     } finally {
/*     */       
/* 138 */       Util.bzero(paramArrayOfbyte1);
/*     */     } 
/*     */   }
/*     */   
/*     */   private IdentityFile(String paramString, byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, JSch paramJSch) throws JSchException {
/* 143 */     this.identity = paramString;
/* 144 */     this.jsch = paramJSch;
/*     */     
/*     */     try {
/* 147 */       Class clazz = Class.forName(JSch.getConfig("3des-cbc"));
/* 148 */       this.cipher = (Cipher)clazz.newInstance();
/* 149 */       this.key = new byte[this.cipher.getBlockSize()];
/* 150 */       this.iv = new byte[this.cipher.getIVSize()];
/* 151 */       clazz = Class.forName(JSch.getConfig("md5"));
/* 152 */       this.hash = (HASH)clazz.newInstance();
/* 153 */       this.hash.init();
/*     */       
/* 155 */       byte[] arrayOfByte = paramArrayOfbyte1;
/* 156 */       int i = arrayOfByte.length;
/*     */       
/* 158 */       byte b1 = 0;
/* 159 */       while (b1 < i) {
/* 160 */         if (arrayOfByte[b1] == 66 && arrayOfByte[b1 + 1] == 69 && arrayOfByte[b1 + 2] == 71 && arrayOfByte[b1 + 3] == 73) {
/* 161 */           b1 += 6;
/* 162 */           if (arrayOfByte[b1] == 68 && arrayOfByte[b1 + 1] == 83 && arrayOfByte[b1 + 2] == 65) { this.type = 2; }
/* 163 */           else if (arrayOfByte[b1] == 82 && arrayOfByte[b1 + 1] == 83 && arrayOfByte[b1 + 2] == 65) { this.type = 1; }
/* 164 */           else if (arrayOfByte[b1] == 83 && arrayOfByte[b1 + 1] == 83 && arrayOfByte[b1 + 2] == 72)
/* 165 */           { this.type = 3;
/* 166 */             this.keytype = 1; }
/*     */           
/*     */           else
/*     */           
/* 170 */           { throw new JSchException("invalid privatekey: " + this.identity); }
/*     */           
/* 172 */           b1 += 3;
/*     */           continue;
/*     */         } 
/* 175 */         if (arrayOfByte[b1] == 65 && arrayOfByte[b1 + 1] == 69 && arrayOfByte[b1 + 2] == 83 && arrayOfByte[b1 + 3] == 45 && arrayOfByte[b1 + 4] == 50 && arrayOfByte[b1 + 5] == 53 && arrayOfByte[b1 + 6] == 54 && arrayOfByte[b1 + 7] == 45) {
/*     */           
/* 177 */           b1 += 8;
/* 178 */           if (Session.checkCipher(JSch.getConfig("aes256-cbc"))) {
/* 179 */             clazz = Class.forName(JSch.getConfig("aes256-cbc"));
/* 180 */             this.cipher = (Cipher)clazz.newInstance();
/* 181 */             this.key = new byte[this.cipher.getBlockSize()];
/* 182 */             this.iv = new byte[this.cipher.getIVSize()];
/*     */             continue;
/*     */           } 
/* 185 */           throw new JSchException("privatekey: aes256-cbc is not available " + this.identity);
/*     */         } 
/*     */ 
/*     */         
/* 189 */         if (arrayOfByte[b1] == 67 && arrayOfByte[b1 + 1] == 66 && arrayOfByte[b1 + 2] == 67 && arrayOfByte[b1 + 3] == 44) {
/* 190 */           b1 += 4;
/* 191 */           for (byte b = 0; b < this.iv.length; b++) {
/* 192 */             this.iv[b] = (byte)((a2b(arrayOfByte[b1++]) << 4 & 0xF0) + (a2b(arrayOfByte[b1++]) & 0xF));
/*     */           }
/*     */           
/*     */           continue;
/*     */         } 
/* 197 */         if (arrayOfByte[b1] == 13 && b1 + 1 < arrayOfByte.length && arrayOfByte[b1 + 1] == 10) {
/*     */           
/* 199 */           b1++;
/*     */           continue;
/*     */         } 
/* 202 */         if (arrayOfByte[b1] == 10 && b1 + 1 < arrayOfByte.length) {
/* 203 */           if (arrayOfByte[b1 + 1] == 10) { b1 += 2; break; }
/* 204 */            if (arrayOfByte[b1 + 1] == 13 && b1 + 2 < arrayOfByte.length && arrayOfByte[b1 + 2] == 10) {
/*     */             
/* 206 */             b1 += 3; break;
/*     */           } 
/* 208 */           boolean bool = false;
/* 209 */           for (int j = b1 + 1; j < arrayOfByte.length && 
/* 210 */             arrayOfByte[j] != 10; j++) {
/*     */             
/* 212 */             if (arrayOfByte[j] == 58) { bool = true; break; }
/*     */           
/* 214 */           }  if (!bool) {
/* 215 */             b1++;
/* 216 */             this.encrypted = false;
/*     */             break;
/*     */           } 
/*     */         } 
/* 220 */         b1++;
/*     */       } 
/*     */       
/* 223 */       if (this.type == 0) {
/* 224 */         throw new JSchException("invalid privatekey: " + this.identity);
/*     */       }
/*     */       
/* 227 */       byte b2 = b1;
/* 228 */       while (b1 < i) {
/* 229 */         if (arrayOfByte[b1] == 10) {
/* 230 */           boolean bool = (arrayOfByte[b1 - 1] == 13) ? true : false;
/* 231 */           System.arraycopy(arrayOfByte, b1 + 1, arrayOfByte, b1 - (bool ? 1 : 0), i - b1 - 1 - (bool ? 1 : 0));
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 236 */           if (bool) i--; 
/* 237 */           i--;
/*     */           continue;
/*     */         } 
/* 240 */         if (arrayOfByte[b1] == 45)
/* 241 */           break;  b1++;
/*     */       } 
/* 243 */       this.encoded_data = Util.fromBase64(arrayOfByte, b2, b1 - b2);
/*     */       
/* 245 */       if (this.encoded_data.length > 4 && this.encoded_data[0] == 63 && this.encoded_data[1] == 111 && this.encoded_data[2] == -7 && this.encoded_data[3] == -21) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 251 */         Buffer buffer = new Buffer(this.encoded_data);
/* 252 */         buffer.getInt();
/* 253 */         buffer.getInt();
/* 254 */         byte[] arrayOfByte1 = buffer.getString();
/*     */         
/* 256 */         byte[] arrayOfByte2 = buffer.getString();
/* 257 */         String str = new String(arrayOfByte2);
/*     */         
/* 259 */         if (str.equals("3des-cbc")) {
/* 260 */           buffer.getInt();
/* 261 */           byte[] arrayOfByte3 = new byte[this.encoded_data.length - buffer.getOffSet()];
/* 262 */           buffer.getByte(arrayOfByte3);
/* 263 */           this.encoded_data = arrayOfByte3;
/* 264 */           this.encrypted = true;
/* 265 */           throw new JSchException("unknown privatekey format: " + this.identity);
/*     */         } 
/* 267 */         if (str.equals("none")) {
/* 268 */           buffer.getInt();
/*     */ 
/*     */           
/* 271 */           this.encrypted = false;
/*     */           
/* 273 */           byte[] arrayOfByte3 = new byte[this.encoded_data.length - buffer.getOffSet()];
/* 274 */           buffer.getByte(arrayOfByte3);
/* 275 */           this.encoded_data = arrayOfByte3;
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 280 */       if (paramArrayOfbyte2 == null) {
/*     */         return;
/*     */       }
/*     */       
/* 284 */       arrayOfByte = paramArrayOfbyte2;
/* 285 */       i = arrayOfByte.length;
/*     */       
/* 287 */       if (arrayOfByte.length > 4 && arrayOfByte[0] == 45 && arrayOfByte[1] == 45 && arrayOfByte[2] == 45 && arrayOfByte[3] == 45) {
/*     */         
/* 289 */         b1 = 0; 
/* 290 */         do { b1++; } while (i > b1 && arrayOfByte[b1] != 10);
/* 291 */         if (i <= b1)
/* 292 */           return;  while (b1 < i) {
/* 293 */           if (arrayOfByte[b1] == 10) {
/* 294 */             boolean bool = false;
/* 295 */             for (int j = b1 + 1; j < i && 
/* 296 */               arrayOfByte[j] != 10; j++) {
/* 297 */               if (arrayOfByte[j] == 58) { bool = true; break; }
/*     */             
/* 299 */             }  if (!bool) {
/* 300 */               b1++;
/*     */               break;
/*     */             } 
/*     */           } 
/* 304 */           b1++;
/*     */         } 
/* 306 */         if (i <= b1)
/*     */           return; 
/* 308 */         b2 = b1;
/* 309 */         while (b1 < i) {
/* 310 */           if (arrayOfByte[b1] == 10) {
/* 311 */             System.arraycopy(arrayOfByte, b1 + 1, arrayOfByte, b1, i - b1 - 1);
/* 312 */             i--;
/*     */             continue;
/*     */           } 
/* 315 */           if (arrayOfByte[b1] == 45)
/* 316 */             break;  b1++;
/*     */         } 
/* 318 */         this.publickeyblob = Util.fromBase64(arrayOfByte, b2, b1 - b2);
/*     */         
/* 320 */         if (this.type == 3 && this.publickeyblob.length > 8) {
/* 321 */           if (this.publickeyblob[8] == 100) {
/* 322 */             this.type = 2;
/*     */           }
/* 324 */           else if (this.publickeyblob[8] == 114) {
/* 325 */             this.type = 1;
/*     */           } 
/*     */         }
/*     */       } else {
/*     */         
/* 330 */         if (arrayOfByte[0] != 115 || arrayOfByte[1] != 115 || arrayOfByte[2] != 104 || arrayOfByte[3] != 45)
/* 331 */           return;  b1 = 0;
/* 332 */         for (; b1 < i && arrayOfByte[b1] != 32; b1++); b1++;
/* 333 */         if (b1 >= i)
/* 334 */           return;  b2 = b1;
/* 335 */         for (; b1 < i && arrayOfByte[b1] != 32 && arrayOfByte[b1] != 10; b1++);
/* 336 */         this.publickeyblob = Util.fromBase64(arrayOfByte, b2, b1 - b2);
/* 337 */         if (this.publickeyblob.length < 11) {
/* 338 */           if (JSch.getLogger().isEnabled(2)) {
/* 339 */             JSch.getLogger().log(2, "failed to parse the public key");
/*     */           }
/*     */           
/* 342 */           this.publickeyblob = null;
/*     */         }
/*     */       
/*     */       } 
/*     */     } catch (Exception exception) {
/*     */       
/* 348 */       if (exception instanceof JSchException) throw (JSchException)exception; 
/* 349 */       if (exception instanceof Throwable)
/* 350 */         throw new JSchException(exception.toString(), exception); 
/* 351 */       throw new JSchException(exception.toString());
/*     */     } 
/*     */   }
/*     */   
/*     */   public String getAlgName() {
/* 356 */     if (this.type == 1) return "ssh-rsa"; 
/* 357 */     return "ssh-dss";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean setPassphrase(byte[] paramArrayOfbyte) throws JSchException {
/*     */     try {
/* 368 */       if (this.encrypted) {
/* 369 */         if (paramArrayOfbyte == null) return false; 
/* 370 */         byte[] arrayOfByte1 = paramArrayOfbyte;
/* 371 */         int i = this.hash.getBlockSize();
/* 372 */         byte[] arrayOfByte2 = new byte[this.key.length / i * i + ((this.key.length % i == 0) ? 0 : i)];
/*     */         
/* 374 */         byte[] arrayOfByte3 = null;
/* 375 */         if (this.keytype == 0) {
/* 376 */           for (int j = 0; j + i <= arrayOfByte2.length; ) {
/* 377 */             if (arrayOfByte3 != null) this.hash.update(arrayOfByte3, 0, arrayOfByte3.length); 
/* 378 */             this.hash.update(arrayOfByte1, 0, arrayOfByte1.length);
/* 379 */             this.hash.update(this.iv, 0, (this.iv.length > 8) ? 8 : this.iv.length);
/* 380 */             arrayOfByte3 = this.hash.digest();
/* 381 */             System.arraycopy(arrayOfByte3, 0, arrayOfByte2, j, arrayOfByte3.length);
/* 382 */             j += arrayOfByte3.length;
/*     */           } 
/* 384 */           System.arraycopy(arrayOfByte2, 0, this.key, 0, this.key.length);
/*     */         }
/* 386 */         else if (this.keytype == 1) {
/* 387 */           for (int j = 0; j + i <= arrayOfByte2.length; ) {
/* 388 */             if (arrayOfByte3 != null) this.hash.update(arrayOfByte3, 0, arrayOfByte3.length); 
/* 389 */             this.hash.update(arrayOfByte1, 0, arrayOfByte1.length);
/* 390 */             arrayOfByte3 = this.hash.digest();
/* 391 */             System.arraycopy(arrayOfByte3, 0, arrayOfByte2, j, arrayOfByte3.length);
/* 392 */             j += arrayOfByte3.length;
/*     */           } 
/* 394 */           System.arraycopy(arrayOfByte2, 0, this.key, 0, this.key.length);
/*     */         } 
/* 396 */         Util.bzero(arrayOfByte1);
/*     */       } 
/* 398 */       if (decrypt()) {
/* 399 */         this.encrypted = false;
/* 400 */         return true;
/*     */       } 
/* 402 */       this.P_array = this.Q_array = this.G_array = this.pub_array = this.prv_array = null;
/* 403 */       return false;
/*     */     } catch (Exception exception) {
/*     */       
/* 406 */       if (exception instanceof JSchException) throw (JSchException)exception; 
/* 407 */       if (exception instanceof Throwable)
/* 408 */         throw new JSchException(exception.toString(), exception); 
/* 409 */       throw new JSchException(exception.toString());
/*     */     } 
/*     */   }
/*     */   
/*     */   public byte[] getPublicKeyBlob() {
/* 414 */     if (this.publickeyblob != null) return this.publickeyblob; 
/* 415 */     if (this.type == 1) return getPublicKeyBlob_rsa(); 
/* 416 */     return getPublicKeyBlob_dss();
/*     */   }
/*     */   
/*     */   byte[] getPublicKeyBlob_rsa() {
/* 420 */     if (this.e_array == null) return null; 
/* 421 */     Buffer buffer = new Buffer("ssh-rsa".length() + 4 + this.e_array.length + 4 + this.n_array.length + 4);
/*     */ 
/*     */     
/* 424 */     buffer.putString("ssh-rsa".getBytes());
/* 425 */     buffer.putString(this.e_array);
/* 426 */     buffer.putString(this.n_array);
/* 427 */     return buffer.buffer;
/*     */   }
/*     */   
/*     */   byte[] getPublicKeyBlob_dss() {
/* 431 */     if (this.P_array == null) return null; 
/* 432 */     Buffer buffer = new Buffer("ssh-dss".length() + 4 + this.P_array.length + 4 + this.Q_array.length + 4 + this.G_array.length + 4 + this.pub_array.length + 4);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 437 */     buffer.putString("ssh-dss".getBytes());
/* 438 */     buffer.putString(this.P_array);
/* 439 */     buffer.putString(this.Q_array);
/* 440 */     buffer.putString(this.G_array);
/* 441 */     buffer.putString(this.pub_array);
/* 442 */     return buffer.buffer;
/*     */   }
/*     */   
/*     */   public byte[] getSignature(byte[] paramArrayOfbyte) {
/* 446 */     if (this.type == 1) return getSignature_rsa(paramArrayOfbyte); 
/* 447 */     return getSignature_dss(paramArrayOfbyte);
/*     */   }
/*     */   
/*     */   byte[] getSignature_rsa(byte[] paramArrayOfbyte) {
/*     */     try {
/* 452 */       this; Class clazz = Class.forName(JSch.getConfig("signature.rsa"));
/* 453 */       SignatureRSA signatureRSA = (SignatureRSA)clazz.newInstance();
/*     */       
/* 455 */       signatureRSA.init();
/* 456 */       signatureRSA.setPrvKey(this.d_array, this.n_array);
/*     */       
/* 458 */       signatureRSA.update(paramArrayOfbyte);
/* 459 */       byte[] arrayOfByte = signatureRSA.sign();
/* 460 */       Buffer buffer = new Buffer("ssh-rsa".length() + 4 + arrayOfByte.length + 4);
/*     */       
/* 462 */       buffer.putString("ssh-rsa".getBytes());
/* 463 */       buffer.putString(arrayOfByte);
/* 464 */       return buffer.buffer;
/*     */     }
/* 466 */     catch (Exception exception) {
/*     */       
/* 468 */       return null;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   byte[] getSignature_dss(byte[] paramArrayOfbyte) {
/*     */     try {
/* 496 */       this; Class clazz = Class.forName(JSch.getConfig("signature.dss"));
/* 497 */       SignatureDSA signatureDSA = (SignatureDSA)clazz.newInstance();
/* 498 */       signatureDSA.init();
/* 499 */       signatureDSA.setPrvKey(this.prv_array, this.P_array, this.Q_array, this.G_array);
/*     */       
/* 501 */       signatureDSA.update(paramArrayOfbyte);
/* 502 */       byte[] arrayOfByte = signatureDSA.sign();
/* 503 */       Buffer buffer = new Buffer("ssh-dss".length() + 4 + arrayOfByte.length + 4);
/*     */       
/* 505 */       buffer.putString("ssh-dss".getBytes());
/* 506 */       buffer.putString(arrayOfByte);
/* 507 */       return buffer.buffer;
/*     */     }
/* 509 */     catch (Exception exception) {
/*     */ 
/*     */       
/* 512 */       return null;
/*     */     } 
/*     */   }
/*     */   public boolean decrypt() {
/* 516 */     if (this.type == 1) return decrypt_rsa(); 
/* 517 */     return decrypt_dss();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean decrypt_rsa() {
/*     */     try {
/*     */       byte[] arrayOfByte6;
/* 529 */       if (this.encrypted) {
/* 530 */         if (this.keytype == 0) {
/* 531 */           this.cipher.init(1, this.key, this.iv);
/* 532 */           arrayOfByte6 = new byte[this.encoded_data.length];
/* 533 */           this.cipher.update(this.encoded_data, 0, this.encoded_data.length, arrayOfByte6, 0);
/*     */         }
/* 535 */         else if (this.keytype == 1) {
/* 536 */           for (byte b = 0; b < this.iv.length; ) { this.iv[b] = 0; b++; }
/* 537 */            this.cipher.init(1, this.key, this.iv);
/* 538 */           arrayOfByte6 = new byte[this.encoded_data.length];
/* 539 */           this.cipher.update(this.encoded_data, 0, this.encoded_data.length, arrayOfByte6, 0);
/*     */         } else {
/*     */           
/* 542 */           return false;
/*     */         } 
/*     */       } else {
/*     */         
/* 546 */         if (this.n_array != null) return true; 
/* 547 */         arrayOfByte6 = this.encoded_data;
/*     */       } 
/*     */       
/* 550 */       if (this.keytype == 1) {
/* 551 */         Buffer buffer = new Buffer(arrayOfByte6);
/* 552 */         int k = buffer.getInt();
/* 553 */         if (arrayOfByte6.length != k + 4) {
/* 554 */           return false;
/*     */         }
/* 556 */         this.e_array = buffer.getMPIntBits();
/* 557 */         this.d_array = buffer.getMPIntBits();
/* 558 */         this.n_array = buffer.getMPIntBits();
/* 559 */         byte[] arrayOfByte9 = buffer.getMPIntBits();
/* 560 */         byte[] arrayOfByte7 = buffer.getMPIntBits();
/* 561 */         byte[] arrayOfByte8 = buffer.getMPIntBits();
/* 562 */         return true;
/*     */       } 
/*     */       
/* 565 */       int i = 0;
/* 566 */       int j = 0;
/*     */       
/* 568 */       if (arrayOfByte6[i] != 48) return false; 
/* 569 */       i++;
/* 570 */       j = arrayOfByte6[i++] & 0xFF;
/* 571 */       if ((j & 0x80) != 0) {
/* 572 */         int k = j & 0x7F; j = 0;
/* 573 */         for (; k-- > 0; j = (j << 8) + (arrayOfByte6[i++] & 0xFF));
/*     */       } 
/*     */       
/* 576 */       if (arrayOfByte6[i] != 2) return false; 
/* 577 */       i++;
/* 578 */       j = arrayOfByte6[i++] & 0xFF;
/* 579 */       if ((j & 0x80) != 0) {
/* 580 */         int k = j & 0x7F; j = 0;
/* 581 */         for (; k-- > 0; j = (j << 8) + (arrayOfByte6[i++] & 0xFF));
/*     */       } 
/* 583 */       i += j;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 589 */       i++;
/* 590 */       j = arrayOfByte6[i++] & 0xFF;
/* 591 */       if ((j & 0x80) != 0) {
/* 592 */         int k = j & 0x7F; j = 0;
/* 593 */         for (; k-- > 0; j = (j << 8) + (arrayOfByte6[i++] & 0xFF));
/*     */       } 
/* 595 */       this.n_array = new byte[j];
/* 596 */       System.arraycopy(arrayOfByte6, i, this.n_array, 0, j);
/* 597 */       i += j;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 605 */       i++;
/* 606 */       j = arrayOfByte6[i++] & 0xFF;
/* 607 */       if ((j & 0x80) != 0) {
/* 608 */         int k = j & 0x7F; j = 0;
/* 609 */         for (; k-- > 0; j = (j << 8) + (arrayOfByte6[i++] & 0xFF));
/*     */       } 
/* 611 */       this.e_array = new byte[j];
/* 612 */       System.arraycopy(arrayOfByte6, i, this.e_array, 0, j);
/* 613 */       i += j;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 621 */       i++;
/* 622 */       j = arrayOfByte6[i++] & 0xFF;
/* 623 */       if ((j & 0x80) != 0) {
/* 624 */         int k = j & 0x7F; j = 0;
/* 625 */         for (; k-- > 0; j = (j << 8) + (arrayOfByte6[i++] & 0xFF));
/*     */       } 
/* 627 */       this.d_array = new byte[j];
/* 628 */       System.arraycopy(arrayOfByte6, i, this.d_array, 0, j);
/* 629 */       i += j;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 638 */       i++;
/* 639 */       j = arrayOfByte6[i++] & 0xFF;
/* 640 */       if ((j & 0x80) != 0) {
/* 641 */         int k = j & 0x7F; j = 0;
/* 642 */         for (; k-- > 0; j = (j << 8) + (arrayOfByte6[i++] & 0xFF));
/*     */       } 
/* 644 */       byte[] arrayOfByte1 = new byte[j];
/* 645 */       System.arraycopy(arrayOfByte6, i, arrayOfByte1, 0, j);
/* 646 */       i += j;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 654 */       i++;
/* 655 */       j = arrayOfByte6[i++] & 0xFF;
/* 656 */       if ((j & 0x80) != 0) {
/* 657 */         int k = j & 0x7F; j = 0;
/* 658 */         for (; k-- > 0; j = (j << 8) + (arrayOfByte6[i++] & 0xFF));
/*     */       } 
/* 660 */       byte[] arrayOfByte2 = new byte[j];
/* 661 */       System.arraycopy(arrayOfByte6, i, arrayOfByte2, 0, j);
/* 662 */       i += j;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 670 */       i++;
/* 671 */       j = arrayOfByte6[i++] & 0xFF;
/* 672 */       if ((j & 0x80) != 0) {
/* 673 */         int k = j & 0x7F; j = 0;
/* 674 */         for (; k-- > 0; j = (j << 8) + (arrayOfByte6[i++] & 0xFF));
/*     */       } 
/* 676 */       byte[] arrayOfByte3 = new byte[j];
/* 677 */       System.arraycopy(arrayOfByte6, i, arrayOfByte3, 0, j);
/* 678 */       i += j;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 686 */       i++;
/* 687 */       j = arrayOfByte6[i++] & 0xFF;
/* 688 */       if ((j & 0x80) != 0) {
/* 689 */         int k = j & 0x7F; j = 0;
/* 690 */         for (; k-- > 0; j = (j << 8) + (arrayOfByte6[i++] & 0xFF));
/*     */       } 
/* 692 */       byte[] arrayOfByte4 = new byte[j];
/* 693 */       System.arraycopy(arrayOfByte6, i, arrayOfByte4, 0, j);
/* 694 */       i += j;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 702 */       i++;
/* 703 */       j = arrayOfByte6[i++] & 0xFF;
/* 704 */       if ((j & 0x80) != 0) {
/* 705 */         int k = j & 0x7F; j = 0;
/* 706 */         for (; k-- > 0; j = (j << 8) + (arrayOfByte6[i++] & 0xFF));
/*     */       } 
/* 708 */       byte[] arrayOfByte5 = new byte[j];
/* 709 */       System.arraycopy(arrayOfByte6, i, arrayOfByte5, 0, j);
/* 710 */       i += j;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*     */     catch (Exception exception) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 721 */       return false;
/*     */     } 
/* 723 */     return true;
/*     */   }
/*     */   
/*     */   boolean decrypt_dss() {
/*     */     try {
/*     */       byte[] arrayOfByte;
/* 729 */       if (this.encrypted) {
/* 730 */         if (this.keytype == 0) {
/* 731 */           this.cipher.init(1, this.key, this.iv);
/* 732 */           arrayOfByte = new byte[this.encoded_data.length];
/* 733 */           this.cipher.update(this.encoded_data, 0, this.encoded_data.length, arrayOfByte, 0);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         }
/* 741 */         else if (this.keytype == 1) {
/* 742 */           for (byte b = 0; b < this.iv.length; ) { this.iv[b] = 0; b++; }
/* 743 */            this.cipher.init(1, this.key, this.iv);
/* 744 */           arrayOfByte = new byte[this.encoded_data.length];
/* 745 */           this.cipher.update(this.encoded_data, 0, this.encoded_data.length, arrayOfByte, 0);
/*     */         } else {
/*     */           
/* 748 */           return false;
/*     */         } 
/*     */       } else {
/*     */         
/* 752 */         if (this.P_array != null) return true; 
/* 753 */         arrayOfByte = this.encoded_data;
/*     */       } 
/*     */       
/* 756 */       if (this.keytype == 1) {
/* 757 */         Buffer buffer = new Buffer(arrayOfByte);
/* 758 */         int k = buffer.getInt();
/* 759 */         if (arrayOfByte.length != k + 4) {
/* 760 */           return false;
/*     */         }
/* 762 */         this.P_array = buffer.getMPIntBits();
/* 763 */         this.G_array = buffer.getMPIntBits();
/* 764 */         this.Q_array = buffer.getMPIntBits();
/* 765 */         this.pub_array = buffer.getMPIntBits();
/* 766 */         this.prv_array = buffer.getMPIntBits();
/* 767 */         return true;
/*     */       } 
/*     */       
/* 770 */       int i = 0;
/* 771 */       int j = 0;
/* 772 */       if (arrayOfByte[i] != 48) return false; 
/* 773 */       i++;
/* 774 */       j = arrayOfByte[i++] & 0xFF;
/* 775 */       if ((j & 0x80) != 0) {
/* 776 */         int k = j & 0x7F; j = 0;
/* 777 */         for (; k-- > 0; j = (j << 8) + (arrayOfByte[i++] & 0xFF));
/*     */       } 
/* 779 */       if (arrayOfByte[i] != 2) return false; 
/* 780 */       i++;
/* 781 */       j = arrayOfByte[i++] & 0xFF;
/* 782 */       if ((j & 0x80) != 0) {
/* 783 */         int k = j & 0x7F; j = 0;
/* 784 */         for (; k-- > 0; j = (j << 8) + (arrayOfByte[i++] & 0xFF));
/*     */       } 
/* 786 */       i += j;
/*     */       
/* 788 */       i++;
/* 789 */       j = arrayOfByte[i++] & 0xFF;
/* 790 */       if ((j & 0x80) != 0) {
/* 791 */         int k = j & 0x7F; j = 0;
/* 792 */         for (; k-- > 0; j = (j << 8) + (arrayOfByte[i++] & 0xFF));
/*     */       } 
/* 794 */       this.P_array = new byte[j];
/* 795 */       System.arraycopy(arrayOfByte, i, this.P_array, 0, j);
/* 796 */       i += j;
/*     */       
/* 798 */       i++;
/* 799 */       j = arrayOfByte[i++] & 0xFF;
/* 800 */       if ((j & 0x80) != 0) {
/* 801 */         int k = j & 0x7F; j = 0;
/* 802 */         for (; k-- > 0; j = (j << 8) + (arrayOfByte[i++] & 0xFF));
/*     */       } 
/* 804 */       this.Q_array = new byte[j];
/* 805 */       System.arraycopy(arrayOfByte, i, this.Q_array, 0, j);
/* 806 */       i += j;
/*     */       
/* 808 */       i++;
/* 809 */       j = arrayOfByte[i++] & 0xFF;
/* 810 */       if ((j & 0x80) != 0) {
/* 811 */         int k = j & 0x7F; j = 0;
/* 812 */         for (; k-- > 0; j = (j << 8) + (arrayOfByte[i++] & 0xFF));
/*     */       } 
/* 814 */       this.G_array = new byte[j];
/* 815 */       System.arraycopy(arrayOfByte, i, this.G_array, 0, j);
/* 816 */       i += j;
/*     */       
/* 818 */       i++;
/* 819 */       j = arrayOfByte[i++] & 0xFF;
/* 820 */       if ((j & 0x80) != 0) {
/* 821 */         int k = j & 0x7F; j = 0;
/* 822 */         for (; k-- > 0; j = (j << 8) + (arrayOfByte[i++] & 0xFF));
/*     */       } 
/* 824 */       this.pub_array = new byte[j];
/* 825 */       System.arraycopy(arrayOfByte, i, this.pub_array, 0, j);
/* 826 */       i += j;
/*     */       
/* 828 */       i++;
/* 829 */       j = arrayOfByte[i++] & 0xFF;
/* 830 */       if ((j & 0x80) != 0) {
/* 831 */         int k = j & 0x7F; j = 0;
/* 832 */         for (; k-- > 0; j = (j << 8) + (arrayOfByte[i++] & 0xFF));
/*     */       } 
/* 834 */       this.prv_array = new byte[j];
/* 835 */       System.arraycopy(arrayOfByte, i, this.prv_array, 0, j);
/* 836 */       i += j;
/*     */     
/*     */     }
/*     */     catch (Exception exception) {
/*     */       
/* 841 */       return false;
/*     */     } 
/* 843 */     return true;
/*     */   }
/*     */   
/*     */   public boolean isEncrypted() {
/* 847 */     return this.encrypted;
/*     */   }
/*     */   
/*     */   public String getName() {
/* 851 */     return this.identity;
/*     */   }
/*     */   
/*     */   private byte a2b(byte paramByte) {
/* 855 */     if (48 <= paramByte && paramByte <= 57) return (byte)(paramByte - 48); 
/* 856 */     if (97 <= paramByte && paramByte <= 122) return (byte)(paramByte - 97 + 10); 
/* 857 */     return (byte)(paramByte - 65 + 10);
/*     */   }
/*     */   
/*     */   public boolean equals(Object paramObject) {
/* 861 */     if (!(paramObject instanceof IdentityFile)) return super.equals(paramObject); 
/* 862 */     IdentityFile identityFile = (IdentityFile)paramObject;
/* 863 */     return getName().equals(identityFile.getName());
/*     */   }
/*     */   
/*     */   public void clear() {
/* 867 */     Util.bzero(this.encoded_data);
/* 868 */     Util.bzero(this.prv_array);
/* 869 */     Util.bzero(this.d_array);
/* 870 */     Util.bzero(this.key);
/* 871 */     Util.bzero(this.iv);
/*     */   }
/*     */   
/*     */   public void finalize() {
/* 875 */     clear();
/*     */   }
/*     */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/IdentityFile.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */