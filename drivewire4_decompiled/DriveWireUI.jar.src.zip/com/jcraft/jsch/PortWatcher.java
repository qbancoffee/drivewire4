/*     */ package com.jcraft.jsch;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.net.InetAddress;
/*     */ import java.net.ServerSocket;
/*     */ import java.net.Socket;
/*     */ import java.net.UnknownHostException;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class PortWatcher
/*     */   implements Runnable
/*     */ {
/*  36 */   private static Vector pool = new Vector();
/*  37 */   private static InetAddress anyLocalAddress = null;
/*     */   
/*     */   Session session;
/*     */   int lport;
/*     */   int rport;
/*     */   
/*     */   static {
/*     */     try {
/*  45 */       anyLocalAddress = InetAddress.getByName("0.0.0.0");
/*  46 */     } catch (UnknownHostException unknownHostException) {}
/*     */   }
/*     */ 
/*     */   
/*     */   String host;
/*     */   
/*     */   InetAddress boundaddress;
/*     */   
/*     */   Runnable thread;
/*     */   
/*     */   ServerSocket ss;
/*     */   
/*     */   static String[] getPortForwarding(Session paramSession) {
/*  59 */     Vector vector = new Vector();
/*  60 */     synchronized (pool) {
/*  61 */       for (byte b1 = 0; b1 < pool.size(); b1++) {
/*  62 */         PortWatcher portWatcher = pool.elementAt(b1);
/*  63 */         if (portWatcher.session == paramSession) {
/*  64 */           vector.addElement(portWatcher.lport + ":" + portWatcher.host + ":" + portWatcher.rport);
/*     */         }
/*     */       } 
/*     */     } 
/*  68 */     String[] arrayOfString = new String[vector.size()];
/*  69 */     for (byte b = 0; b < vector.size(); b++) {
/*  70 */       arrayOfString[b] = vector.elementAt(b);
/*     */     }
/*  72 */     return arrayOfString;
/*     */   }
/*     */   static PortWatcher getPort(Session paramSession, String paramString, int paramInt) throws JSchException {
/*     */     InetAddress inetAddress;
/*     */     try {
/*  77 */       inetAddress = InetAddress.getByName(paramString);
/*     */     } catch (UnknownHostException unknownHostException) {
/*     */       
/*  80 */       throw new JSchException("PortForwardingL: invalid address " + paramString + " specified.", unknownHostException);
/*     */     } 
/*  82 */     synchronized (pool) {
/*  83 */       for (byte b = 0; b < pool.size(); b++) {
/*  84 */         PortWatcher portWatcher = pool.elementAt(b);
/*  85 */         if (portWatcher.session == paramSession && portWatcher.lport == paramInt && ((
/*  86 */           anyLocalAddress != null && portWatcher.boundaddress.equals(anyLocalAddress)) || portWatcher.boundaddress.equals(inetAddress)))
/*     */         {
/*     */           
/*  89 */           return portWatcher;
/*     */         }
/*     */       } 
/*  92 */       return null;
/*     */     } 
/*     */   }
/*     */   static PortWatcher addPort(Session paramSession, String paramString1, int paramInt1, String paramString2, int paramInt2, ServerSocketFactory paramServerSocketFactory) throws JSchException {
/*  96 */     if (getPort(paramSession, paramString1, paramInt1) != null) {
/*  97 */       throw new JSchException("PortForwardingL: local port " + paramString1 + ":" + paramInt1 + " is already registered.");
/*     */     }
/*  99 */     PortWatcher portWatcher = new PortWatcher(paramSession, paramString1, paramInt1, paramString2, paramInt2, paramServerSocketFactory);
/* 100 */     pool.addElement(portWatcher);
/* 101 */     return portWatcher;
/*     */   }
/*     */   static void delPort(Session paramSession, String paramString, int paramInt) throws JSchException {
/* 104 */     PortWatcher portWatcher = getPort(paramSession, paramString, paramInt);
/* 105 */     if (portWatcher == null) {
/* 106 */       throw new JSchException("PortForwardingL: local port " + paramString + ":" + paramInt + " is not registered.");
/*     */     }
/* 108 */     portWatcher.delete();
/* 109 */     pool.removeElement(portWatcher);
/*     */   }
/*     */   static void delPort(Session paramSession) {
/* 112 */     synchronized (pool) {
/* 113 */       PortWatcher[] arrayOfPortWatcher = new PortWatcher[pool.size()];
/* 114 */       byte b1 = 0;
/* 115 */       for (byte b2 = 0; b2 < pool.size(); b2++) {
/* 116 */         PortWatcher portWatcher = pool.elementAt(b2);
/* 117 */         if (portWatcher.session == paramSession) {
/* 118 */           portWatcher.delete();
/* 119 */           arrayOfPortWatcher[b1++] = portWatcher;
/*     */         } 
/*     */       } 
/* 122 */       for (byte b3 = 0; b3 < b1; b3++) {
/* 123 */         PortWatcher portWatcher = arrayOfPortWatcher[b3];
/* 124 */         pool.removeElement(portWatcher);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   PortWatcher(Session paramSession, String paramString1, int paramInt1, String paramString2, int paramInt2, ServerSocketFactory paramServerSocketFactory) throws JSchException {
/* 132 */     this.session = paramSession;
/* 133 */     this.lport = paramInt1;
/* 134 */     this.host = paramString2;
/* 135 */     this.rport = paramInt2;
/*     */     try {
/* 137 */       this.boundaddress = InetAddress.getByName(paramString1);
/* 138 */       this.ss = (paramServerSocketFactory == null) ? new ServerSocket(paramInt1, 0, this.boundaddress) : paramServerSocketFactory.createServerSocket(paramInt1, 0, this.boundaddress);
/*     */     
/*     */     }
/*     */     catch (Exception exception) {
/*     */ 
/*     */       
/* 144 */       String str = "PortForwardingL: local port " + paramString1 + ":" + paramInt1 + " cannot be bound.";
/* 145 */       if (exception instanceof Throwable)
/* 146 */         throw new JSchException(str, exception); 
/* 147 */       throw new JSchException(str);
/*     */     } 
/* 149 */     if (paramInt1 == 0) {
/* 150 */       int i = this.ss.getLocalPort();
/* 151 */       if (i != -1)
/* 152 */         this.lport = i; 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void run() {
/* 157 */     this.thread = this;
/*     */     try {
/* 159 */       while (this.thread != null) {
/* 160 */         Socket socket = this.ss.accept();
/* 161 */         socket.setTcpNoDelay(true);
/* 162 */         InputStream inputStream = socket.getInputStream();
/* 163 */         OutputStream outputStream = socket.getOutputStream();
/* 164 */         ChannelDirectTCPIP channelDirectTCPIP = new ChannelDirectTCPIP();
/* 165 */         channelDirectTCPIP.init();
/* 166 */         channelDirectTCPIP.setInputStream(inputStream);
/* 167 */         channelDirectTCPIP.setOutputStream(outputStream);
/* 168 */         this.session.addChannel(channelDirectTCPIP);
/* 169 */         channelDirectTCPIP.setHost(this.host);
/* 170 */         channelDirectTCPIP.setPort(this.rport);
/* 171 */         channelDirectTCPIP.setOrgIPAddress(socket.getInetAddress().getHostAddress());
/* 172 */         channelDirectTCPIP.setOrgPort(socket.getPort());
/* 173 */         channelDirectTCPIP.connect();
/* 174 */         if (channelDirectTCPIP.exitstatus != -1);
/*     */       }
/*     */     
/*     */     }
/* 178 */     catch (Exception exception) {}
/*     */ 
/*     */ 
/*     */     
/* 182 */     delete();
/*     */   }
/*     */   
/*     */   void delete() {
/* 186 */     this.thread = null;
/*     */     try {
/* 188 */       if (this.ss != null) this.ss.close(); 
/* 189 */       this.ss = null;
/*     */     }
/* 191 */     catch (Exception exception) {}
/*     */   }
/*     */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/PortWatcher.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */