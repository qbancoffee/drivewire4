/*     */ package com.jcraft.jsch;
/*     */ 
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SftpATTRS
/*     */ {
/*     */   static final int S_ISUID = 2048;
/*     */   static final int S_ISGID = 1024;
/*     */   static final int S_ISVTX = 512;
/*     */   static final int S_IRUSR = 256;
/*     */   static final int S_IWUSR = 128;
/*     */   static final int S_IXUSR = 64;
/*     */   static final int S_IREAD = 256;
/*     */   static final int S_IWRITE = 128;
/*     */   static final int S_IEXEC = 64;
/*     */   static final int S_IRGRP = 32;
/*     */   static final int S_IWGRP = 16;
/*     */   static final int S_IXGRP = 8;
/*     */   static final int S_IROTH = 4;
/*     */   static final int S_IWOTH = 2;
/*     */   static final int S_IXOTH = 1;
/*     */   private static final int pmask = 4095;
/*     */   public static final int SSH_FILEXFER_ATTR_SIZE = 1;
/*     */   public static final int SSH_FILEXFER_ATTR_UIDGID = 2;
/*     */   public static final int SSH_FILEXFER_ATTR_PERMISSIONS = 4;
/*     */   public static final int SSH_FILEXFER_ATTR_ACMODTIME = 8;
/*     */   public static final int SSH_FILEXFER_ATTR_EXTENDED = -2147483648;
/*     */   static final int S_IFDIR = 16384;
/*     */   static final int S_IFLNK = 40960;
/*     */   
/*     */   public String getPermissionsString() {
/*  73 */     StringBuffer stringBuffer = new StringBuffer(10);
/*     */     
/*  75 */     if (isDir()) { stringBuffer.append('d'); }
/*  76 */     else if (isLink()) { stringBuffer.append('l'); }
/*  77 */     else { stringBuffer.append('-'); }
/*     */     
/*  79 */     if ((this.permissions & 0x100) != 0) { stringBuffer.append('r'); }
/*  80 */     else { stringBuffer.append('-'); }
/*     */     
/*  82 */     if ((this.permissions & 0x80) != 0) { stringBuffer.append('w'); }
/*  83 */     else { stringBuffer.append('-'); }
/*     */     
/*  85 */     if ((this.permissions & 0x800) != 0) { stringBuffer.append('s'); }
/*  86 */     else if ((this.permissions & 0x40) != 0) { stringBuffer.append('x'); }
/*  87 */     else { stringBuffer.append('-'); }
/*     */     
/*  89 */     if ((this.permissions & 0x20) != 0) { stringBuffer.append('r'); }
/*  90 */     else { stringBuffer.append('-'); }
/*     */     
/*  92 */     if ((this.permissions & 0x10) != 0) { stringBuffer.append('w'); }
/*  93 */     else { stringBuffer.append('-'); }
/*     */     
/*  95 */     if ((this.permissions & 0x400) != 0) { stringBuffer.append('s'); }
/*  96 */     else if ((this.permissions & 0x8) != 0) { stringBuffer.append('x'); }
/*  97 */     else { stringBuffer.append('-'); }
/*     */     
/*  99 */     if ((this.permissions & 0x4) != 0) { stringBuffer.append('r'); }
/* 100 */     else { stringBuffer.append('-'); }
/*     */     
/* 102 */     if ((this.permissions & 0x2) != 0) { stringBuffer.append('w'); }
/* 103 */     else { stringBuffer.append('-'); }
/*     */     
/* 105 */     if ((this.permissions & 0x1) != 0) { stringBuffer.append('x'); }
/* 106 */     else { stringBuffer.append('-'); }
/* 107 */      return stringBuffer.toString();
/*     */   }
/*     */   
/*     */   public String getAtimeString() {
/* 111 */     SimpleDateFormat simpleDateFormat = new SimpleDateFormat();
/* 112 */     return simpleDateFormat.format(new Date(this.atime));
/*     */   }
/*     */   
/*     */   public String getMtimeString() {
/* 116 */     Date date = new Date(this.mtime * 1000L);
/* 117 */     return date.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 129 */   int flags = 0;
/*     */   long size;
/*     */   int uid;
/*     */   int gid;
/*     */   int permissions;
/*     */   int atime;
/*     */   int mtime;
/* 136 */   String[] extended = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static SftpATTRS getATTR(Buffer paramBuffer) {
/* 142 */     SftpATTRS sftpATTRS = new SftpATTRS();
/* 143 */     sftpATTRS.flags = paramBuffer.getInt();
/* 144 */     if ((sftpATTRS.flags & 0x1) != 0) sftpATTRS.size = paramBuffer.getLong(); 
/* 145 */     if ((sftpATTRS.flags & 0x2) != 0) {
/* 146 */       sftpATTRS.uid = paramBuffer.getInt(); sftpATTRS.gid = paramBuffer.getInt();
/*     */     } 
/* 148 */     if ((sftpATTRS.flags & 0x4) != 0) {
/* 149 */       sftpATTRS.permissions = paramBuffer.getInt();
/*     */     }
/* 151 */     if ((sftpATTRS.flags & 0x8) != 0) {
/* 152 */       sftpATTRS.atime = paramBuffer.getInt();
/*     */     }
/* 154 */     if ((sftpATTRS.flags & 0x8) != 0) {
/* 155 */       sftpATTRS.mtime = paramBuffer.getInt();
/*     */     }
/* 157 */     if ((sftpATTRS.flags & Integer.MIN_VALUE) != 0) {
/* 158 */       int i = paramBuffer.getInt();
/* 159 */       if (i > 0) {
/* 160 */         sftpATTRS.extended = new String[i * 2];
/* 161 */         for (byte b = 0; b < i; b++) {
/* 162 */           sftpATTRS.extended[b * 2] = new String(paramBuffer.getString());
/* 163 */           sftpATTRS.extended[b * 2 + 1] = new String(paramBuffer.getString());
/*     */         } 
/*     */       } 
/*     */     } 
/* 167 */     return sftpATTRS;
/*     */   }
/*     */   
/*     */   int length() {
/* 171 */     int i = 4;
/*     */     
/* 173 */     if ((this.flags & 0x1) != 0) i += 8; 
/* 174 */     if ((this.flags & 0x2) != 0) i += 8; 
/* 175 */     if ((this.flags & 0x4) != 0) i += 4; 
/* 176 */     if ((this.flags & 0x8) != 0) i += 8; 
/* 177 */     if ((this.flags & Integer.MIN_VALUE) != 0) {
/* 178 */       i += 4;
/* 179 */       int j = this.extended.length / 2;
/* 180 */       if (j > 0) {
/* 181 */         for (byte b = 0; b < j; b++) {
/* 182 */           i += 4; i += this.extended[b * 2].length();
/* 183 */           i += 4; i += this.extended[b * 2 + 1].length();
/*     */         } 
/*     */       }
/*     */     } 
/* 187 */     return i;
/*     */   }
/*     */   
/*     */   void dump(Buffer paramBuffer) {
/* 191 */     paramBuffer.putInt(this.flags);
/* 192 */     if ((this.flags & 0x1) != 0) paramBuffer.putLong(this.size); 
/* 193 */     if ((this.flags & 0x2) != 0) {
/* 194 */       paramBuffer.putInt(this.uid); paramBuffer.putInt(this.gid);
/*     */     } 
/* 196 */     if ((this.flags & 0x4) != 0) {
/* 197 */       paramBuffer.putInt(this.permissions);
/*     */     }
/* 199 */     if ((this.flags & 0x8) != 0) paramBuffer.putInt(this.atime); 
/* 200 */     if ((this.flags & 0x8) != 0) paramBuffer.putInt(this.mtime); 
/* 201 */     if ((this.flags & Integer.MIN_VALUE) != 0) {
/* 202 */       int i = this.extended.length / 2;
/* 203 */       if (i > 0)
/* 204 */         for (byte b = 0; b < i; b++) {
/* 205 */           paramBuffer.putString(this.extended[b * 2].getBytes());
/* 206 */           paramBuffer.putString(this.extended[b * 2 + 1].getBytes());
/*     */         }  
/*     */     } 
/*     */   }
/*     */   
/*     */   void setFLAGS(int paramInt) {
/* 212 */     this.flags = paramInt;
/*     */   }
/*     */   public void setSIZE(long paramLong) {
/* 215 */     this.flags |= 0x1;
/* 216 */     this.size = paramLong;
/*     */   }
/*     */   public void setUIDGID(int paramInt1, int paramInt2) {
/* 219 */     this.flags |= 0x2;
/* 220 */     this.uid = paramInt1;
/* 221 */     this.gid = paramInt2;
/*     */   }
/*     */   public void setACMODTIME(int paramInt1, int paramInt2) {
/* 224 */     this.flags |= 0x8;
/* 225 */     this.atime = paramInt1;
/* 226 */     this.mtime = paramInt2;
/*     */   }
/*     */   public void setPERMISSIONS(int paramInt) {
/* 229 */     this.flags |= 0x4;
/* 230 */     paramInt = this.permissions & 0xFFFFF000 | paramInt & 0xFFF;
/* 231 */     this.permissions = paramInt;
/*     */   }
/*     */   
/*     */   public boolean isDir() {
/* 235 */     return ((this.flags & 0x4) != 0 && (this.permissions & 0x4000) == 16384);
/*     */   }
/*     */   
/*     */   public boolean isLink() {
/* 239 */     return ((this.flags & 0x4) != 0 && (this.permissions & 0xA000) == 40960);
/*     */   }
/*     */   
/* 242 */   public int getFlags() { return this.flags; }
/* 243 */   public long getSize() { return this.size; }
/* 244 */   public int getUId() { return this.uid; }
/* 245 */   public int getGId() { return this.gid; }
/* 246 */   public int getPermissions() { return this.permissions; }
/* 247 */   public int getATime() { return this.atime; }
/* 248 */   public int getMTime() { return this.mtime; } public String[] getExtended() {
/* 249 */     return this.extended;
/*     */   }
/*     */   public String toString() {
/* 252 */     return getPermissionsString() + " " + getUId() + " " + getGId() + " " + getSize() + " " + getMtimeString();
/*     */   }
/*     */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/SftpATTRS.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */