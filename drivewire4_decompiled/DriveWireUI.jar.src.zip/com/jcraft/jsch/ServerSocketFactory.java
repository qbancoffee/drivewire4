package com.jcraft.jsch;

import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;

public interface ServerSocketFactory {
  ServerSocket createServerSocket(int paramInt1, int paramInt2, InetAddress paramInetAddress) throws IOException;
}


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/ServerSocketFactory.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */