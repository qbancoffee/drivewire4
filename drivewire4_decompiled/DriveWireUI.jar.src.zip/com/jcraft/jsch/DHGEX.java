/*     */ package com.jcraft.jsch;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DHGEX
/*     */   extends KeyExchange
/*     */ {
/*     */   private static final int SSH_MSG_KEX_DH_GEX_GROUP = 31;
/*     */   private static final int SSH_MSG_KEX_DH_GEX_INIT = 32;
/*     */   private static final int SSH_MSG_KEX_DH_GEX_REPLY = 33;
/*     */   private static final int SSH_MSG_KEX_DH_GEX_REQUEST = 34;
/*  39 */   static int min = 1024;
/*     */ 
/*     */   
/*  42 */   static int preferred = 1024;
/*  43 */   static int max = 1024;
/*     */ 
/*     */   
/*     */   static final int RSA = 0;
/*     */   
/*     */   static final int DSS = 1;
/*     */   
/*  50 */   private int type = 0;
/*     */   
/*     */   private int state;
/*     */   
/*     */   DH dh;
/*     */   
/*     */   byte[] V_S;
/*     */   
/*     */   byte[] V_C;
/*     */   
/*     */   byte[] I_S;
/*     */   
/*     */   byte[] I_C;
/*     */   
/*     */   private Buffer buf;
/*     */   
/*     */   private Packet packet;
/*     */   private byte[] p;
/*     */   private byte[] g;
/*     */   private byte[] e;
/*     */   
/*     */   public void init(Session paramSession, byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[] paramArrayOfbyte3, byte[] paramArrayOfbyte4) throws Exception {
/*  72 */     this.session = paramSession;
/*  73 */     this.V_S = paramArrayOfbyte1;
/*  74 */     this.V_C = paramArrayOfbyte2;
/*  75 */     this.I_S = paramArrayOfbyte3;
/*  76 */     this.I_C = paramArrayOfbyte4;
/*     */     
/*     */     try {
/*  79 */       Class clazz = Class.forName(paramSession.getConfig("sha-1"));
/*  80 */       this.sha = (HASH)clazz.newInstance();
/*  81 */       this.sha.init();
/*     */     } catch (Exception exception) {
/*     */       
/*  84 */       System.err.println(exception);
/*     */     } 
/*     */     
/*  87 */     this.buf = new Buffer();
/*  88 */     this.packet = new Packet(this.buf);
/*     */     
/*     */     try {
/*  91 */       Class clazz = Class.forName(paramSession.getConfig("dh"));
/*  92 */       this.dh = (DH)clazz.newInstance();
/*  93 */       this.dh.init();
/*     */     }
/*     */     catch (Exception exception) {
/*     */       
/*  97 */       throw exception;
/*     */     } 
/*     */     
/* 100 */     this.packet.reset();
/* 101 */     this.buf.putByte((byte)34);
/* 102 */     this.buf.putInt(min);
/* 103 */     this.buf.putInt(preferred);
/* 104 */     this.buf.putInt(max);
/* 105 */     paramSession.write(this.packet);
/*     */     
/* 107 */     if (JSch.getLogger().isEnabled(1)) {
/* 108 */       JSch.getLogger().log(1, "SSH_MSG_KEX_DH_GEX_REQUEST(" + min + "<" + preferred + "<" + max + ") sent");
/*     */       
/* 110 */       JSch.getLogger().log(1, "expecting SSH_MSG_KEX_DH_GEX_GROUP");
/*     */     } 
/*     */ 
/*     */     
/* 114 */     this.state = 31; } public boolean next(Buffer paramBuffer) throws Exception { int i; int j; byte[] arrayOfByte1;
/*     */     byte[] arrayOfByte2;
/*     */     byte[] arrayOfByte3;
/*     */     String str;
/*     */     boolean bool;
/* 119 */     switch (this.state) {
/*     */ 
/*     */ 
/*     */       
/*     */       case 31:
/* 124 */         paramBuffer.getInt();
/* 125 */         paramBuffer.getByte();
/* 126 */         j = paramBuffer.getByte();
/* 127 */         if (j != 31) {
/* 128 */           System.err.println("type: must be SSH_MSG_KEX_DH_GEX_GROUP " + j);
/* 129 */           return false;
/*     */         } 
/*     */         
/* 132 */         this.p = paramBuffer.getMPInt();
/* 133 */         this.g = paramBuffer.getMPInt();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 143 */         this.dh.setP(this.p);
/* 144 */         this.dh.setG(this.g);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 151 */         this.e = this.dh.getE();
/*     */         
/* 153 */         this.packet.reset();
/* 154 */         this.buf.putByte((byte)32);
/* 155 */         this.buf.putMPInt(this.e);
/* 156 */         this.session.write(this.packet);
/*     */         
/* 158 */         if (JSch.getLogger().isEnabled(1)) {
/* 159 */           JSch.getLogger().log(1, "SSH_MSG_KEX_DH_GEX_INIT sent");
/*     */           
/* 161 */           JSch.getLogger().log(1, "expecting SSH_MSG_KEX_DH_GEX_REPLY");
/*     */         } 
/*     */ 
/*     */         
/* 165 */         this.state = 33;
/* 166 */         return true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 33:
/* 175 */         j = paramBuffer.getInt();
/* 176 */         j = paramBuffer.getByte();
/* 177 */         j = paramBuffer.getByte();
/* 178 */         if (j != 33) {
/* 179 */           System.err.println("type: must be SSH_MSG_KEX_DH_GEX_REPLY " + j);
/* 180 */           return false;
/*     */         } 
/*     */         
/* 183 */         this.K_S = paramBuffer.getString();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 192 */         arrayOfByte1 = paramBuffer.getMPInt();
/* 193 */         arrayOfByte2 = paramBuffer.getString();
/*     */         
/* 195 */         this.dh.setF(arrayOfByte1);
/* 196 */         this.K = this.dh.getK();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 216 */         this.buf.reset();
/* 217 */         this.buf.putString(this.V_C); this.buf.putString(this.V_S);
/* 218 */         this.buf.putString(this.I_C); this.buf.putString(this.I_S);
/* 219 */         this.buf.putString(this.K_S);
/* 220 */         this.buf.putInt(min); this.buf.putInt(preferred); this.buf.putInt(max);
/* 221 */         this.buf.putMPInt(this.p); this.buf.putMPInt(this.g); this.buf.putMPInt(this.e); this.buf.putMPInt(arrayOfByte1);
/* 222 */         this.buf.putMPInt(this.K);
/*     */         
/* 224 */         arrayOfByte3 = new byte[this.buf.getLength()];
/* 225 */         this.buf.getByte(arrayOfByte3);
/* 226 */         this.sha.update(arrayOfByte3, 0, arrayOfByte3.length);
/*     */         
/* 228 */         this.H = this.sha.digest();
/*     */ 
/*     */ 
/*     */         
/* 232 */         i = 0;
/* 233 */         j = 0;
/* 234 */         j = this.K_S[i++] << 24 & 0xFF000000 | this.K_S[i++] << 16 & 0xFF0000 | this.K_S[i++] << 8 & 0xFF00 | this.K_S[i++] & 0xFF;
/*     */         
/* 236 */         str = new String(this.K_S, i, j);
/* 237 */         i += j;
/*     */         
/* 239 */         bool = false;
/* 240 */         if (str.equals("ssh-rsa")) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 245 */           this.type = 0;
/*     */           
/* 247 */           j = this.K_S[i++] << 24 & 0xFF000000 | this.K_S[i++] << 16 & 0xFF0000 | this.K_S[i++] << 8 & 0xFF00 | this.K_S[i++] & 0xFF;
/*     */           
/* 249 */           byte[] arrayOfByte4 = new byte[j]; System.arraycopy(this.K_S, i, arrayOfByte4, 0, j); i += j;
/* 250 */           byte[] arrayOfByte5 = arrayOfByte4;
/* 251 */           j = this.K_S[i++] << 24 & 0xFF000000 | this.K_S[i++] << 16 & 0xFF0000 | this.K_S[i++] << 8 & 0xFF00 | this.K_S[i++] & 0xFF;
/*     */           
/* 253 */           arrayOfByte4 = new byte[j]; System.arraycopy(this.K_S, i, arrayOfByte4, 0, j); i += j;
/* 254 */           byte[] arrayOfByte6 = arrayOfByte4;
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 259 */           SignatureRSA signatureRSA = null;
/*     */           try {
/* 261 */             Class clazz = Class.forName(this.session.getConfig("signature.rsa"));
/* 262 */             signatureRSA = (SignatureRSA)clazz.newInstance();
/* 263 */             signatureRSA.init();
/*     */           } catch (Exception exception) {
/*     */             
/* 266 */             System.err.println(exception);
/*     */           } 
/*     */           
/* 269 */           signatureRSA.setPubKey(arrayOfByte5, arrayOfByte6);
/* 270 */           signatureRSA.update(this.H);
/* 271 */           bool = signatureRSA.verify(arrayOfByte2);
/*     */           
/* 273 */           if (JSch.getLogger().isEnabled(1)) {
/* 274 */             JSch.getLogger().log(1, "ssh_rsa_verify: signature " + bool);
/*     */           
/*     */           }
/*     */         
/*     */         }
/* 279 */         else if (str.equals("ssh-dss")) {
/* 280 */           byte[] arrayOfByte4 = null;
/*     */ 
/*     */           
/* 283 */           this.type = 1;
/*     */           
/* 285 */           j = this.K_S[i++] << 24 & 0xFF000000 | this.K_S[i++] << 16 & 0xFF0000 | this.K_S[i++] << 8 & 0xFF00 | this.K_S[i++] & 0xFF;
/*     */           
/* 287 */           byte[] arrayOfByte5 = new byte[j]; System.arraycopy(this.K_S, i, arrayOfByte5, 0, j); i += j;
/* 288 */           this.p = arrayOfByte5;
/* 289 */           j = this.K_S[i++] << 24 & 0xFF000000 | this.K_S[i++] << 16 & 0xFF0000 | this.K_S[i++] << 8 & 0xFF00 | this.K_S[i++] & 0xFF;
/*     */           
/* 291 */           arrayOfByte5 = new byte[j]; System.arraycopy(this.K_S, i, arrayOfByte5, 0, j); i += j;
/* 292 */           arrayOfByte4 = arrayOfByte5;
/* 293 */           j = this.K_S[i++] << 24 & 0xFF000000 | this.K_S[i++] << 16 & 0xFF0000 | this.K_S[i++] << 8 & 0xFF00 | this.K_S[i++] & 0xFF;
/*     */           
/* 295 */           arrayOfByte5 = new byte[j]; System.arraycopy(this.K_S, i, arrayOfByte5, 0, j); i += j;
/* 296 */           this.g = arrayOfByte5;
/* 297 */           j = this.K_S[i++] << 24 & 0xFF000000 | this.K_S[i++] << 16 & 0xFF0000 | this.K_S[i++] << 8 & 0xFF00 | this.K_S[i++] & 0xFF;
/*     */           
/* 299 */           arrayOfByte5 = new byte[j]; System.arraycopy(this.K_S, i, arrayOfByte5, 0, j); i += j;
/* 300 */           arrayOfByte1 = arrayOfByte5;
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 305 */           SignatureDSA signatureDSA = null;
/*     */           try {
/* 307 */             Class clazz = Class.forName(this.session.getConfig("signature.dss"));
/* 308 */             signatureDSA = (SignatureDSA)clazz.newInstance();
/* 309 */             signatureDSA.init();
/*     */           } catch (Exception exception) {
/*     */             
/* 312 */             System.err.println(exception);
/*     */           } 
/*     */           
/* 315 */           signatureDSA.setPubKey(arrayOfByte1, this.p, arrayOfByte4, this.g);
/* 316 */           signatureDSA.update(this.H);
/* 317 */           bool = signatureDSA.verify(arrayOfByte2);
/*     */           
/* 319 */           if (JSch.getLogger().isEnabled(1)) {
/* 320 */             JSch.getLogger().log(1, "ssh_dss_verify: signature " + bool);
/*     */           
/*     */           }
/*     */         }
/*     */         else {
/*     */           
/* 326 */           System.err.println("unknown alg");
/*     */         } 
/* 328 */         this.state = 0;
/* 329 */         return bool;
/*     */     } 
/* 331 */     return false; }
/*     */ 
/*     */   
/*     */   public String getKeyType() {
/* 335 */     if (this.type == 1) return "DSA"; 
/* 336 */     return "RSA";
/*     */   }
/*     */   public int getState() {
/* 339 */     return this.state;
/*     */   }
/*     */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/DHGEX.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */