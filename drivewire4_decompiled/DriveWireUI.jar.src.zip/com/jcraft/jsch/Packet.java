/*     */ package com.jcraft.jsch;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Packet
/*     */ {
/*  34 */   private static Random random = null; static void setRandom(Random paramRandom) {
/*  35 */     random = paramRandom;
/*     */   }
/*     */   Buffer buffer;
/*  38 */   byte[] ba4 = new byte[4];
/*     */   public Packet(Buffer paramBuffer) {
/*  40 */     this.buffer = paramBuffer;
/*     */   }
/*     */   public void reset() {
/*  43 */     this.buffer.index = 5;
/*     */   }
/*     */   void padding(int paramInt) {
/*  46 */     int i = this.buffer.index;
/*  47 */     int j = -i & paramInt - 1;
/*  48 */     if (j < paramInt) {
/*  49 */       j += paramInt;
/*     */     }
/*  51 */     i = i + j - 4;
/*  52 */     this.ba4[0] = (byte)(i >>> 24);
/*  53 */     this.ba4[1] = (byte)(i >>> 16);
/*  54 */     this.ba4[2] = (byte)(i >>> 8);
/*  55 */     this.ba4[3] = (byte)i;
/*  56 */     System.arraycopy(this.ba4, 0, this.buffer.buffer, 0, 4);
/*  57 */     this.buffer.buffer[4] = (byte)j;
/*  58 */     synchronized (random) {
/*  59 */       random.fill(this.buffer.buffer, this.buffer.index, j);
/*     */     } 
/*  61 */     this.buffer.skip(j);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int shift(int paramInt1, int paramInt2) {
/*  72 */     int i = paramInt1 + 5 + 9;
/*  73 */     int j = -i & 0xF;
/*  74 */     if (j < 16) j += 16; 
/*  75 */     i += j;
/*  76 */     i += paramInt2;
/*     */ 
/*     */     
/*  79 */     if (this.buffer.buffer.length < i + this.buffer.index - 5 - 9 - paramInt1) {
/*  80 */       byte[] arrayOfByte = new byte[i + this.buffer.index - 5 - 9 - paramInt1];
/*  81 */       System.arraycopy(this.buffer.buffer, 0, arrayOfByte, 0, this.buffer.buffer.length);
/*  82 */       this.buffer.buffer = arrayOfByte;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  92 */     System.arraycopy(this.buffer.buffer, paramInt1 + 5 + 9, this.buffer.buffer, i, this.buffer.index - 5 - 9 - paramInt1);
/*     */ 
/*     */ 
/*     */     
/*  96 */     this.buffer.index = 10;
/*  97 */     this.buffer.putInt(paramInt1);
/*  98 */     this.buffer.index = paramInt1 + 5 + 9;
/*  99 */     return i;
/*     */   }
/*     */   void unshift(byte paramByte, int paramInt1, int paramInt2, int paramInt3) {
/* 102 */     System.arraycopy(this.buffer.buffer, paramInt2, this.buffer.buffer, 14, paramInt3);
/*     */ 
/*     */     
/* 105 */     this.buffer.buffer[5] = paramByte;
/* 106 */     this.buffer.index = 6;
/* 107 */     this.buffer.putInt(paramInt1);
/* 108 */     this.buffer.putInt(paramInt3);
/* 109 */     this.buffer.index = paramInt3 + 5 + 9;
/*     */   }
/*     */   Buffer getBuffer() {
/* 112 */     return this.buffer;
/*     */   }
/*     */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/Packet.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */