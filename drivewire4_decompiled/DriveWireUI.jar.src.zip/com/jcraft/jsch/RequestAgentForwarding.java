/*    */ package com.jcraft.jsch;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class RequestAgentForwarding
/*    */   extends Request
/*    */ {
/*    */   public void request(Session paramSession, Channel paramChannel) throws Exception {
/* 34 */     super.request(paramSession, paramChannel);
/*    */     
/* 36 */     setReply(false);
/*    */     
/* 38 */     Buffer buffer = new Buffer();
/* 39 */     Packet packet = new Packet(buffer);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 45 */     packet.reset();
/* 46 */     buffer.putByte((byte)98);
/* 47 */     buffer.putInt(paramChannel.getRecipient());
/* 48 */     buffer.putString("auth-agent-req@openssh.com".getBytes());
/* 49 */     buffer.putByte((byte)(waitForReply() ? 1 : 0));
/* 50 */     write(packet);
/* 51 */     paramSession.agent_forwarding = true;
/*    */   }
/*    */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/RequestAgentForwarding.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */