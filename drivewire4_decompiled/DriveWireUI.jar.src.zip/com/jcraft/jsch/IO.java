/*     */ package com.jcraft.jsch;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.net.SocketException;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class IO
/*     */ {
/*     */   InputStream in;
/*     */   OutputStream out;
/*     */   OutputStream out_ext;
/*     */   private boolean in_dontclose = false;
/*     */   private boolean out_dontclose = false;
/*     */   private boolean out_ext_dontclose = false;
/*     */   
/*     */   void setOutputStream(OutputStream paramOutputStream) {
/*  43 */     this.out = paramOutputStream;
/*     */   } void setOutputStream(OutputStream paramOutputStream, boolean paramBoolean) {
/*  45 */     this.out_dontclose = paramBoolean;
/*  46 */     setOutputStream(paramOutputStream);
/*     */   } void setExtOutputStream(OutputStream paramOutputStream) {
/*  48 */     this.out_ext = paramOutputStream;
/*     */   } void setExtOutputStream(OutputStream paramOutputStream, boolean paramBoolean) {
/*  50 */     this.out_ext_dontclose = paramBoolean;
/*  51 */     setExtOutputStream(paramOutputStream);
/*     */   } void setInputStream(InputStream paramInputStream) {
/*  53 */     this.in = paramInputStream;
/*     */   } void setInputStream(InputStream paramInputStream, boolean paramBoolean) {
/*  55 */     this.in_dontclose = paramBoolean;
/*  56 */     setInputStream(paramInputStream);
/*     */   }
/*     */   
/*     */   public void put(Packet paramPacket) throws IOException, SocketException {
/*  60 */     this.out.write(paramPacket.buffer.buffer, 0, paramPacket.buffer.index);
/*  61 */     this.out.flush();
/*     */   }
/*     */   void put(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException {
/*  64 */     this.out.write(paramArrayOfbyte, paramInt1, paramInt2);
/*  65 */     this.out.flush();
/*     */   }
/*     */   void put_ext(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException {
/*  68 */     this.out_ext.write(paramArrayOfbyte, paramInt1, paramInt2);
/*  69 */     this.out_ext.flush();
/*     */   }
/*     */   
/*     */   int getByte() throws IOException {
/*  73 */     return this.in.read();
/*     */   }
/*     */   
/*     */   void getByte(byte[] paramArrayOfbyte) throws IOException {
/*  77 */     getByte(paramArrayOfbyte, 0, paramArrayOfbyte.length);
/*     */   }
/*     */   
/*     */   void getByte(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException {
/*     */     do {
/*  82 */       int i = this.in.read(paramArrayOfbyte, paramInt1, paramInt2);
/*  83 */       if (i < 0) {
/*  84 */         throw new IOException("End of IO Stream Read");
/*     */       }
/*  86 */       paramInt1 += i;
/*  87 */       paramInt2 -= i;
/*     */     }
/*  89 */     while (paramInt2 > 0);
/*     */   }
/*     */   
/*     */   void out_close() {
/*     */     try {
/*  94 */       if (this.out != null && !this.out_dontclose) this.out.close(); 
/*  95 */       this.out = null;
/*     */     }
/*  97 */     catch (Exception exception) {}
/*     */   }
/*     */   
/*     */   public void close() {
/*     */     try {
/* 102 */       if (this.in != null && !this.in_dontclose) this.in.close(); 
/* 103 */       this.in = null;
/*     */     }
/* 105 */     catch (Exception exception) {}
/*     */     
/* 107 */     out_close();
/*     */     
/*     */     try {
/* 110 */       if (this.out_ext != null && !this.out_ext_dontclose) this.out_ext.close(); 
/* 111 */       this.out_ext = null;
/*     */     }
/* 113 */     catch (Exception exception) {}
/*     */   }
/*     */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/IO.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */