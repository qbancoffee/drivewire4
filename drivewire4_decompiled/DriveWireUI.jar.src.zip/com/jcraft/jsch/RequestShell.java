/*    */ package com.jcraft.jsch;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class RequestShell
/*    */   extends Request
/*    */ {
/*    */   public void request(Session paramSession, Channel paramChannel) throws Exception {
/* 34 */     super.request(paramSession, paramChannel);
/*    */     
/* 36 */     Buffer buffer = new Buffer();
/* 37 */     Packet packet = new Packet(buffer);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 44 */     packet.reset();
/* 45 */     buffer.putByte((byte)98);
/* 46 */     buffer.putInt(paramChannel.getRecipient());
/* 47 */     buffer.putString("shell".getBytes());
/* 48 */     buffer.putByte((byte)(waitForReply() ? 1 : 0));
/* 49 */     write(packet);
/*    */   }
/*    */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/RequestShell.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */