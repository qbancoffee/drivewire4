/*     */ package com.jcraft.jsch;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class DHG1
/*     */   extends KeyExchange
/*     */ {
/*  34 */   static final byte[] g = new byte[] { 2 };
/*  35 */   static final byte[] p = new byte[] { 0, -1, -1, -1, -1, -1, -1, -1, -1, -55, 15, -38, -94, 33, 104, -62, 52, -60, -58, 98, -117, Byte.MIN_VALUE, -36, 28, -47, 41, 2, 78, 8, -118, 103, -52, 116, 2, 11, -66, -90, 59, 19, -101, 34, 81, 74, 8, 121, -114, 52, 4, -35, -17, -107, 25, -77, -51, 58, 67, 27, 48, 43, 10, 109, -14, 95, 20, 55, 79, -31, 53, 109, 109, 81, -62, 69, -28, -123, -75, 118, 98, 94, 126, -58, -12, 76, 66, -23, -90, 55, -19, 107, 11, -1, 92, -74, -12, 6, -73, -19, -18, 56, 107, -5, 90, -119, -97, -91, -82, -97, 36, 17, 124, 75, 31, -26, 73, 40, 102, 81, -20, -26, 83, -127, -1, -1, -1, -1, -1, -1, -1, -1 };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int SSH_MSG_KEXDH_INIT = 30;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static final int SSH_MSG_KEXDH_REPLY = 31;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final int RSA = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static final int DSS = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  60 */   private int type = 0;
/*     */ 
/*     */   
/*     */   private int state;
/*     */ 
/*     */   
/*     */   DH dh;
/*     */   
/*     */   byte[] V_S;
/*     */   
/*     */   byte[] V_C;
/*     */   
/*     */   byte[] I_S;
/*     */   
/*     */   byte[] I_C;
/*     */   
/*     */   byte[] e;
/*     */   
/*     */   private Buffer buf;
/*     */   
/*     */   private Packet packet;
/*     */ 
/*     */   
/*     */   public void init(Session paramSession, byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[] paramArrayOfbyte3, byte[] paramArrayOfbyte4) throws Exception {
/*  84 */     this.session = paramSession;
/*  85 */     this.V_S = paramArrayOfbyte1;
/*  86 */     this.V_C = paramArrayOfbyte2;
/*  87 */     this.I_S = paramArrayOfbyte3;
/*  88 */     this.I_C = paramArrayOfbyte4;
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  93 */       Class clazz = Class.forName(paramSession.getConfig("sha-1"));
/*  94 */       this.sha = (HASH)clazz.newInstance();
/*  95 */       this.sha.init();
/*     */     } catch (Exception exception) {
/*     */       
/*  98 */       System.err.println(exception);
/*     */     } 
/*     */     
/* 101 */     this.buf = new Buffer();
/* 102 */     this.packet = new Packet(this.buf);
/*     */     
/*     */     try {
/* 105 */       Class clazz = Class.forName(paramSession.getConfig("dh"));
/* 106 */       this.dh = (DH)clazz.newInstance();
/* 107 */       this.dh.init();
/*     */     }
/*     */     catch (Exception exception) {
/*     */       
/* 111 */       throw exception;
/*     */     } 
/*     */     
/* 114 */     this.dh.setP(p);
/* 115 */     this.dh.setG(g);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 122 */     this.e = this.dh.getE();
/*     */     
/* 124 */     this.packet.reset();
/* 125 */     this.buf.putByte((byte)30);
/* 126 */     this.buf.putMPInt(this.e);
/* 127 */     paramSession.write(this.packet);
/*     */     
/* 129 */     if (JSch.getLogger().isEnabled(1)) {
/* 130 */       JSch.getLogger().log(1, "SSH_MSG_KEXDH_INIT sent");
/*     */       
/* 132 */       JSch.getLogger().log(1, "expecting SSH_MSG_KEXDH_REPLY");
/*     */     } 
/*     */ 
/*     */     
/* 136 */     this.state = 31; } public boolean next(Buffer paramBuffer) throws Exception { int i; int j;
/*     */     byte[] arrayOfByte1;
/*     */     byte[] arrayOfByte2;
/*     */     byte[] arrayOfByte3;
/*     */     String str;
/*     */     boolean bool;
/* 142 */     switch (this.state) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 31:
/* 149 */         j = paramBuffer.getInt();
/* 150 */         j = paramBuffer.getByte();
/* 151 */         j = paramBuffer.getByte();
/* 152 */         if (j != 31) {
/* 153 */           System.err.println("type: must be 31 " + j);
/* 154 */           return false;
/*     */         } 
/*     */         
/* 157 */         this.K_S = paramBuffer.getString();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 165 */         arrayOfByte1 = paramBuffer.getMPInt();
/* 166 */         arrayOfByte2 = paramBuffer.getString();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 175 */         this.dh.setF(arrayOfByte1);
/* 176 */         this.K = this.dh.getK();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 190 */         this.buf.reset();
/* 191 */         this.buf.putString(this.V_C); this.buf.putString(this.V_S);
/* 192 */         this.buf.putString(this.I_C); this.buf.putString(this.I_S);
/* 193 */         this.buf.putString(this.K_S);
/* 194 */         this.buf.putMPInt(this.e); this.buf.putMPInt(arrayOfByte1);
/* 195 */         this.buf.putMPInt(this.K);
/* 196 */         arrayOfByte3 = new byte[this.buf.getLength()];
/* 197 */         this.buf.getByte(arrayOfByte3);
/* 198 */         this.sha.update(arrayOfByte3, 0, arrayOfByte3.length);
/* 199 */         this.H = this.sha.digest();
/*     */ 
/*     */         
/* 202 */         i = 0;
/* 203 */         j = 0;
/* 204 */         j = this.K_S[i++] << 24 & 0xFF000000 | this.K_S[i++] << 16 & 0xFF0000 | this.K_S[i++] << 8 & 0xFF00 | this.K_S[i++] & 0xFF;
/*     */         
/* 206 */         str = new String(this.K_S, i, j);
/* 207 */         i += j;
/*     */         
/* 209 */         bool = false;
/*     */         
/* 211 */         if (str.equals("ssh-rsa")) {
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 216 */           this.type = 0;
/*     */           
/* 218 */           j = this.K_S[i++] << 24 & 0xFF000000 | this.K_S[i++] << 16 & 0xFF0000 | this.K_S[i++] << 8 & 0xFF00 | this.K_S[i++] & 0xFF;
/*     */           
/* 220 */           byte[] arrayOfByte4 = new byte[j]; System.arraycopy(this.K_S, i, arrayOfByte4, 0, j); i += j;
/* 221 */           byte[] arrayOfByte5 = arrayOfByte4;
/* 222 */           j = this.K_S[i++] << 24 & 0xFF000000 | this.K_S[i++] << 16 & 0xFF0000 | this.K_S[i++] << 8 & 0xFF00 | this.K_S[i++] & 0xFF;
/*     */           
/* 224 */           arrayOfByte4 = new byte[j]; System.arraycopy(this.K_S, i, arrayOfByte4, 0, j); i += j;
/* 225 */           byte[] arrayOfByte6 = arrayOfByte4;
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 230 */           SignatureRSA signatureRSA = null;
/*     */           try {
/* 232 */             Class clazz = Class.forName(this.session.getConfig("signature.rsa"));
/* 233 */             signatureRSA = (SignatureRSA)clazz.newInstance();
/* 234 */             signatureRSA.init();
/*     */           } catch (Exception exception) {
/*     */             
/* 237 */             System.err.println(exception);
/*     */           } 
/*     */           
/* 240 */           signatureRSA.setPubKey(arrayOfByte5, arrayOfByte6);
/* 241 */           signatureRSA.update(this.H);
/* 242 */           bool = signatureRSA.verify(arrayOfByte2);
/*     */           
/* 244 */           if (JSch.getLogger().isEnabled(1)) {
/* 245 */             JSch.getLogger().log(1, "ssh_rsa_verify: signature " + bool);
/*     */           
/*     */           }
/*     */         
/*     */         }
/* 250 */         else if (str.equals("ssh-dss")) {
/* 251 */           byte[] arrayOfByte4 = null;
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 256 */           this.type = 1;
/*     */           
/* 258 */           j = this.K_S[i++] << 24 & 0xFF000000 | this.K_S[i++] << 16 & 0xFF0000 | this.K_S[i++] << 8 & 0xFF00 | this.K_S[i++] & 0xFF;
/*     */           
/* 260 */           byte[] arrayOfByte5 = new byte[j]; System.arraycopy(this.K_S, i, arrayOfByte5, 0, j); i += j;
/* 261 */           byte[] arrayOfByte6 = arrayOfByte5;
/* 262 */           j = this.K_S[i++] << 24 & 0xFF000000 | this.K_S[i++] << 16 & 0xFF0000 | this.K_S[i++] << 8 & 0xFF00 | this.K_S[i++] & 0xFF;
/*     */           
/* 264 */           arrayOfByte5 = new byte[j]; System.arraycopy(this.K_S, i, arrayOfByte5, 0, j); i += j;
/* 265 */           arrayOfByte4 = arrayOfByte5;
/* 266 */           j = this.K_S[i++] << 24 & 0xFF000000 | this.K_S[i++] << 16 & 0xFF0000 | this.K_S[i++] << 8 & 0xFF00 | this.K_S[i++] & 0xFF;
/*     */           
/* 268 */           arrayOfByte5 = new byte[j]; System.arraycopy(this.K_S, i, arrayOfByte5, 0, j); i += j;
/* 269 */           byte[] arrayOfByte7 = arrayOfByte5;
/* 270 */           j = this.K_S[i++] << 24 & 0xFF000000 | this.K_S[i++] << 16 & 0xFF0000 | this.K_S[i++] << 8 & 0xFF00 | this.K_S[i++] & 0xFF;
/*     */           
/* 272 */           arrayOfByte5 = new byte[j]; System.arraycopy(this.K_S, i, arrayOfByte5, 0, j); i += j;
/* 273 */           arrayOfByte1 = arrayOfByte5;
/*     */ 
/*     */           
/* 276 */           SignatureDSA signatureDSA = null;
/*     */           try {
/* 278 */             Class clazz = Class.forName(this.session.getConfig("signature.dss"));
/* 279 */             signatureDSA = (SignatureDSA)clazz.newInstance();
/* 280 */             signatureDSA.init();
/*     */           } catch (Exception exception) {
/*     */             
/* 283 */             System.err.println(exception);
/*     */           } 
/* 285 */           signatureDSA.setPubKey(arrayOfByte1, arrayOfByte6, arrayOfByte4, arrayOfByte7);
/* 286 */           signatureDSA.update(this.H);
/* 287 */           bool = signatureDSA.verify(arrayOfByte2);
/*     */           
/* 289 */           if (JSch.getLogger().isEnabled(1)) {
/* 290 */             JSch.getLogger().log(1, "ssh_dss_verify: signature " + bool);
/*     */           
/*     */           }
/*     */         }
/*     */         else {
/*     */           
/* 296 */           System.err.println("unknown alg");
/*     */         } 
/* 298 */         this.state = 0;
/* 299 */         return bool;
/*     */     } 
/* 301 */     return false; }
/*     */ 
/*     */   
/*     */   public String getKeyType() {
/* 305 */     if (this.type == 1) return "DSA"; 
/* 306 */     return "RSA";
/*     */   }
/*     */   public int getState() {
/* 309 */     return this.state;
/*     */   }
/*     */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/DHG1.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */