/*     */ package com.jcraft.jsch;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class KeyPairDSA
/*     */   extends KeyPair
/*     */ {
/*     */   private byte[] P_array;
/*     */   private byte[] Q_array;
/*     */   private byte[] G_array;
/*     */   private byte[] pub_array;
/*     */   private byte[] prv_array;
/*  40 */   private int key_size = 1024;
/*     */   
/*     */   public KeyPairDSA(JSch paramJSch) {
/*  43 */     super(paramJSch);
/*     */   }
/*     */   
/*     */   void generate(int paramInt) throws JSchException {
/*  47 */     this.key_size = paramInt;
/*     */     try {
/*  49 */       this; Class clazz = Class.forName(JSch.getConfig("keypairgen.dsa"));
/*  50 */       KeyPairGenDSA keyPairGenDSA = (KeyPairGenDSA)clazz.newInstance();
/*  51 */       keyPairGenDSA.init(paramInt);
/*  52 */       this.P_array = keyPairGenDSA.getP();
/*  53 */       this.Q_array = keyPairGenDSA.getQ();
/*  54 */       this.G_array = keyPairGenDSA.getG();
/*  55 */       this.pub_array = keyPairGenDSA.getY();
/*  56 */       this.prv_array = keyPairGenDSA.getX();
/*     */       
/*  58 */       keyPairGenDSA = null;
/*     */     }
/*     */     catch (Exception exception) {
/*     */       
/*  62 */       if (exception instanceof Throwable)
/*  63 */         throw new JSchException(exception.toString(), exception); 
/*  64 */       throw new JSchException(exception.toString());
/*     */     } 
/*     */   }
/*     */   
/*  68 */   private static final byte[] begin = "-----BEGIN DSA PRIVATE KEY-----".getBytes();
/*  69 */   private static final byte[] end = "-----END DSA PRIVATE KEY-----".getBytes();
/*     */   
/*  71 */   byte[] getBegin() { return begin; } byte[] getEnd() {
/*  72 */     return end;
/*     */   }
/*     */   byte[] getPrivateKey() {
/*  75 */     int i = 1 + countLength(1) + 1 + 1 + countLength(this.P_array.length) + this.P_array.length + 1 + countLength(this.Q_array.length) + this.Q_array.length + 1 + countLength(this.G_array.length) + this.G_array.length + 1 + countLength(this.pub_array.length) + this.pub_array.length + 1 + countLength(this.prv_array.length) + this.prv_array.length;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  83 */     int j = 1 + countLength(i) + i;
/*     */ 
/*     */     
/*  86 */     byte[] arrayOfByte = new byte[j];
/*  87 */     int k = 0;
/*  88 */     k = writeSEQUENCE(arrayOfByte, k, i);
/*  89 */     k = writeINTEGER(arrayOfByte, k, new byte[1]);
/*  90 */     k = writeINTEGER(arrayOfByte, k, this.P_array);
/*  91 */     k = writeINTEGER(arrayOfByte, k, this.Q_array);
/*  92 */     k = writeINTEGER(arrayOfByte, k, this.G_array);
/*  93 */     k = writeINTEGER(arrayOfByte, k, this.pub_array);
/*  94 */     k = writeINTEGER(arrayOfByte, k, this.prv_array);
/*  95 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */   
/*     */   boolean parse(byte[] paramArrayOfbyte) {
/*     */     try {
/* 101 */       if (this.vendor == 1) {
/* 102 */         if (paramArrayOfbyte[0] != 48) {
/* 103 */           Buffer buffer = new Buffer(paramArrayOfbyte);
/* 104 */           buffer.getInt();
/* 105 */           this.P_array = buffer.getMPIntBits();
/* 106 */           this.G_array = buffer.getMPIntBits();
/* 107 */           this.Q_array = buffer.getMPIntBits();
/* 108 */           this.pub_array = buffer.getMPIntBits();
/* 109 */           this.prv_array = buffer.getMPIntBits();
/* 110 */           return true;
/*     */         } 
/* 112 */         return false;
/*     */       } 
/*     */       
/* 115 */       int i = 0;
/* 116 */       int j = 0;
/*     */       
/* 118 */       if (paramArrayOfbyte[i] != 48) return false; 
/* 119 */       i++;
/* 120 */       j = paramArrayOfbyte[i++] & 0xFF;
/* 121 */       if ((j & 0x80) != 0) {
/* 122 */         int k = j & 0x7F; j = 0;
/* 123 */         for (; k-- > 0; j = (j << 8) + (paramArrayOfbyte[i++] & 0xFF));
/*     */       } 
/*     */       
/* 126 */       if (paramArrayOfbyte[i] != 2) return false; 
/* 127 */       i++;
/* 128 */       j = paramArrayOfbyte[i++] & 0xFF;
/* 129 */       if ((j & 0x80) != 0) {
/* 130 */         int k = j & 0x7F; j = 0;
/* 131 */         for (; k-- > 0; j = (j << 8) + (paramArrayOfbyte[i++] & 0xFF));
/*     */       } 
/* 133 */       i += j;
/*     */       
/* 135 */       i++;
/* 136 */       j = paramArrayOfbyte[i++] & 0xFF;
/* 137 */       if ((j & 0x80) != 0) {
/* 138 */         int k = j & 0x7F; j = 0;
/* 139 */         for (; k-- > 0; j = (j << 8) + (paramArrayOfbyte[i++] & 0xFF));
/*     */       } 
/* 141 */       this.P_array = new byte[j];
/* 142 */       System.arraycopy(paramArrayOfbyte, i, this.P_array, 0, j);
/* 143 */       i += j;
/*     */       
/* 145 */       i++;
/* 146 */       j = paramArrayOfbyte[i++] & 0xFF;
/* 147 */       if ((j & 0x80) != 0) {
/* 148 */         int k = j & 0x7F; j = 0;
/* 149 */         for (; k-- > 0; j = (j << 8) + (paramArrayOfbyte[i++] & 0xFF));
/*     */       } 
/* 151 */       this.Q_array = new byte[j];
/* 152 */       System.arraycopy(paramArrayOfbyte, i, this.Q_array, 0, j);
/* 153 */       i += j;
/*     */       
/* 155 */       i++;
/* 156 */       j = paramArrayOfbyte[i++] & 0xFF;
/* 157 */       if ((j & 0x80) != 0) {
/* 158 */         int k = j & 0x7F; j = 0;
/* 159 */         for (; k-- > 0; j = (j << 8) + (paramArrayOfbyte[i++] & 0xFF));
/*     */       } 
/* 161 */       this.G_array = new byte[j];
/* 162 */       System.arraycopy(paramArrayOfbyte, i, this.G_array, 0, j);
/* 163 */       i += j;
/*     */       
/* 165 */       i++;
/* 166 */       j = paramArrayOfbyte[i++] & 0xFF;
/* 167 */       if ((j & 0x80) != 0) {
/* 168 */         int k = j & 0x7F; j = 0;
/* 169 */         for (; k-- > 0; j = (j << 8) + (paramArrayOfbyte[i++] & 0xFF));
/*     */       } 
/* 171 */       this.pub_array = new byte[j];
/* 172 */       System.arraycopy(paramArrayOfbyte, i, this.pub_array, 0, j);
/* 173 */       i += j;
/*     */       
/* 175 */       i++;
/* 176 */       j = paramArrayOfbyte[i++] & 0xFF;
/* 177 */       if ((j & 0x80) != 0) {
/* 178 */         int k = j & 0x7F; j = 0;
/* 179 */         for (; k-- > 0; j = (j << 8) + (paramArrayOfbyte[i++] & 0xFF));
/*     */       } 
/* 181 */       this.prv_array = new byte[j];
/* 182 */       System.arraycopy(paramArrayOfbyte, i, this.prv_array, 0, j);
/* 183 */       i += j;
/*     */     
/*     */     }
/*     */     catch (Exception exception) {
/*     */       
/* 188 */       return false;
/*     */     } 
/* 190 */     return true;
/*     */   }
/*     */   
/*     */   public byte[] getPublicKeyBlob() {
/* 194 */     byte[] arrayOfByte = super.getPublicKeyBlob();
/* 195 */     if (arrayOfByte != null) return arrayOfByte;
/*     */     
/* 197 */     if (this.P_array == null) return null;
/*     */     
/* 199 */     Buffer buffer = new Buffer(sshdss.length + 4 + this.P_array.length + 4 + this.Q_array.length + 4 + this.G_array.length + 4 + this.pub_array.length + 4);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 204 */     buffer.putString(sshdss);
/* 205 */     buffer.putString(this.P_array);
/* 206 */     buffer.putString(this.Q_array);
/* 207 */     buffer.putString(this.G_array);
/* 208 */     buffer.putString(this.pub_array);
/* 209 */     return buffer.buffer;
/*     */   }
/*     */   
/* 212 */   private static final byte[] sshdss = "ssh-dss".getBytes();
/* 213 */   byte[] getKeyTypeName() { return sshdss; } public int getKeyType() {
/* 214 */     return 1;
/*     */   } public int getKeySize() {
/* 216 */     return this.key_size;
/*     */   } public void dispose() {
/* 218 */     super.dispose();
/* 219 */     Util.bzero(this.prv_array);
/*     */   }
/*     */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/KeyPairDSA.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */