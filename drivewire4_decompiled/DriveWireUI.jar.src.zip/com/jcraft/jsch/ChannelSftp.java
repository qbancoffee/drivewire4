/*      */ package com.jcraft.jsch;
/*      */ 
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.FileOutputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.OutputStream;
/*      */ import java.io.PipedOutputStream;
/*      */ import java.util.Hashtable;
/*      */ import java.util.Vector;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class ChannelSftp
/*      */   extends ChannelSession
/*      */ {
/*      */   private static final byte SSH_FXP_INIT = 1;
/*      */   private static final byte SSH_FXP_VERSION = 2;
/*      */   private static final byte SSH_FXP_OPEN = 3;
/*      */   private static final byte SSH_FXP_CLOSE = 4;
/*      */   private static final byte SSH_FXP_READ = 5;
/*      */   private static final byte SSH_FXP_WRITE = 6;
/*      */   private static final byte SSH_FXP_LSTAT = 7;
/*      */   private static final byte SSH_FXP_FSTAT = 8;
/*      */   private static final byte SSH_FXP_SETSTAT = 9;
/*      */   private static final byte SSH_FXP_FSETSTAT = 10;
/*      */   private static final byte SSH_FXP_OPENDIR = 11;
/*      */   private static final byte SSH_FXP_READDIR = 12;
/*      */   private static final byte SSH_FXP_REMOVE = 13;
/*      */   private static final byte SSH_FXP_MKDIR = 14;
/*      */   private static final byte SSH_FXP_RMDIR = 15;
/*      */   private static final byte SSH_FXP_REALPATH = 16;
/*      */   private static final byte SSH_FXP_STAT = 17;
/*      */   private static final byte SSH_FXP_RENAME = 18;
/*      */   private static final byte SSH_FXP_READLINK = 19;
/*      */   private static final byte SSH_FXP_SYMLINK = 20;
/*      */   private static final byte SSH_FXP_STATUS = 101;
/*      */   private static final byte SSH_FXP_HANDLE = 102;
/*      */   private static final byte SSH_FXP_DATA = 103;
/*      */   private static final byte SSH_FXP_NAME = 104;
/*      */   private static final byte SSH_FXP_ATTRS = 105;
/*      */   private static final byte SSH_FXP_EXTENDED = -56;
/*      */   private static final byte SSH_FXP_EXTENDED_REPLY = -55;
/*      */   private static final int SSH_FXF_READ = 1;
/*      */   private static final int SSH_FXF_WRITE = 2;
/*      */   private static final int SSH_FXF_APPEND = 4;
/*      */   private static final int SSH_FXF_CREAT = 8;
/*      */   private static final int SSH_FXF_TRUNC = 16;
/*      */   private static final int SSH_FXF_EXCL = 32;
/*      */   private static final int SSH_FILEXFER_ATTR_SIZE = 1;
/*      */   private static final int SSH_FILEXFER_ATTR_UIDGID = 2;
/*      */   private static final int SSH_FILEXFER_ATTR_PERMISSIONS = 4;
/*      */   private static final int SSH_FILEXFER_ATTR_ACMODTIME = 8;
/*      */   private static final int SSH_FILEXFER_ATTR_EXTENDED = -2147483648;
/*      */   public static final int SSH_FX_OK = 0;
/*      */   public static final int SSH_FX_EOF = 1;
/*      */   public static final int SSH_FX_NO_SUCH_FILE = 2;
/*      */   public static final int SSH_FX_PERMISSION_DENIED = 3;
/*      */   public static final int SSH_FX_FAILURE = 4;
/*      */   public static final int SSH_FX_BAD_MESSAGE = 5;
/*      */   public static final int SSH_FX_NO_CONNECTION = 6;
/*      */   public static final int SSH_FX_CONNECTION_LOST = 7;
/*      */   public static final int SSH_FX_OP_UNSUPPORTED = 8;
/*      */   private static final int MAX_MSG_LENGTH = 262144;
/*      */   public static final int OVERWRITE = 0;
/*      */   public static final int RESUME = 1;
/*      */   public static final int APPEND = 2;
/*      */   private boolean interactive = false;
/*  132 */   private int seq = 1;
/*  133 */   private int[] ackid = new int[1];
/*      */   private Buffer buf;
/*  135 */   private Packet packet = new Packet(this.buf);
/*      */   
/*  137 */   private int client_version = 3;
/*  138 */   private int server_version = 3;
/*  139 */   private String version = String.valueOf(this.client_version);
/*      */   
/*  141 */   private Hashtable extensions = null;
/*  142 */   private InputStream io_in = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  160 */   private static final String file_separator = File.separator;
/*  161 */   private static final char file_separatorc = File.separatorChar;
/*  162 */   private static boolean fs_is_bs = ((byte)File.separatorChar == 92);
/*      */   
/*      */   private String cwd;
/*      */   
/*      */   private String home;
/*      */   private String lcwd;
/*      */   private static final String UTF8 = "UTF-8";
/*  169 */   private String fEncoding = "UTF-8";
/*      */   
/*      */   private boolean fEncoding_is_utf8 = true;
/*      */ 
/*      */   
/*      */   void init() {}
/*      */   
/*      */   public void start() throws JSchException {
/*      */     try {
/*  178 */       PipedOutputStream pipedOutputStream = new PipedOutputStream();
/*  179 */       this.io.setOutputStream(pipedOutputStream);
/*  180 */       Channel.MyPipedInputStream myPipedInputStream = new Channel.MyPipedInputStream(this, pipedOutputStream, 32768);
/*  181 */       this.io.setInputStream(myPipedInputStream);
/*      */       
/*  183 */       this.io_in = this.io.in;
/*      */       
/*  185 */       if (this.io_in == null) {
/*  186 */         throw new JSchException("channel is down");
/*      */       }
/*      */       
/*  189 */       RequestSftp requestSftp = new RequestSftp();
/*  190 */       requestSftp.request(getSession(), this);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  199 */       this.buf = new Buffer(this.rmpsize);
/*  200 */       this.packet = new Packet(this.buf);
/*  201 */       boolean bool = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  207 */       sendINIT();
/*      */ 
/*      */       
/*  210 */       Header header = new Header(this);
/*  211 */       header = header(this.buf, header);
/*  212 */       int i = header.length;
/*  213 */       if (i > 262144) {
/*  214 */         throw new SftpException(4, "Received message is too long: " + i);
/*      */       }
/*      */       
/*  217 */       int j = header.type;
/*  218 */       this.server_version = header.rid;
/*      */       
/*  220 */       if (i > 0) {
/*  221 */         this.extensions = new Hashtable();
/*      */         
/*  223 */         fill(this.buf, i);
/*  224 */         byte[] arrayOfByte1 = null;
/*  225 */         byte[] arrayOfByte2 = null;
/*  226 */         while (i > 0) {
/*  227 */           arrayOfByte1 = this.buf.getString();
/*  228 */           i -= 4 + arrayOfByte1.length;
/*  229 */           arrayOfByte2 = this.buf.getString();
/*  230 */           i -= 4 + arrayOfByte2.length;
/*  231 */           this.extensions.put(new String(arrayOfByte1), new String(arrayOfByte2));
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/*  236 */       this.lcwd = (new File(".")).getCanonicalPath();
/*      */     }
/*      */     catch (Exception exception) {
/*      */       
/*  240 */       if (exception instanceof JSchException) throw (JSchException)exception; 
/*  241 */       if (exception instanceof Throwable)
/*  242 */         throw new JSchException(exception.toString(), exception); 
/*  243 */       throw new JSchException(exception.toString());
/*      */     } 
/*      */   }
/*      */   
/*  247 */   public void quit() { disconnect(); } public void exit() {
/*  248 */     disconnect();
/*      */   } public void lcd(String paramString) throws SftpException {
/*  250 */     paramString = localAbsolutePath(paramString);
/*  251 */     if ((new File(paramString)).isDirectory()) {
/*      */       try {
/*  253 */         paramString = (new File(paramString)).getCanonicalPath();
/*      */       }
/*  255 */       catch (Exception exception) {}
/*  256 */       this.lcwd = paramString;
/*      */       return;
/*      */     } 
/*  259 */     throw new SftpException(2, "No such directory");
/*      */   }
/*      */   
/*      */   public void cd(String paramString) throws SftpException {
/*      */     try {
/*  264 */       paramString = remoteAbsolutePath(paramString);
/*      */       
/*  266 */       paramString = isUnique(paramString);
/*      */       
/*  268 */       byte[] arrayOfByte = _realpath(paramString);
/*  269 */       SftpATTRS sftpATTRS = _stat(arrayOfByte);
/*      */       
/*  271 */       if ((sftpATTRS.getFlags() & 0x4) == 0) {
/*  272 */         throw new SftpException(4, "Can't change directory: " + paramString);
/*      */       }
/*      */       
/*  275 */       if (!sftpATTRS.isDir()) {
/*  276 */         throw new SftpException(4, "Can't change directory: " + paramString);
/*      */       }
/*      */ 
/*      */       
/*  280 */       setCwd(Util.byte2str(arrayOfByte, this.fEncoding));
/*      */     } catch (Exception exception) {
/*      */       
/*  283 */       if (exception instanceof SftpException) throw (SftpException)exception; 
/*  284 */       if (exception instanceof Throwable)
/*  285 */         throw new SftpException(4, "", exception); 
/*  286 */       throw new SftpException(4, "");
/*      */     } 
/*      */   }
/*      */   
/*      */   public void put(String paramString1, String paramString2) throws SftpException {
/*  291 */     put(paramString1, paramString2, (SftpProgressMonitor)null, 0);
/*      */   }
/*      */   public void put(String paramString1, String paramString2, int paramInt) throws SftpException {
/*  294 */     put(paramString1, paramString2, (SftpProgressMonitor)null, paramInt);
/*      */   }
/*      */   
/*      */   public void put(String paramString1, String paramString2, SftpProgressMonitor paramSftpProgressMonitor) throws SftpException {
/*  298 */     put(paramString1, paramString2, paramSftpProgressMonitor, 0);
/*      */   }
/*      */   
/*      */   public void put(String paramString1, String paramString2, SftpProgressMonitor paramSftpProgressMonitor, int paramInt) throws SftpException {
/*  302 */     paramString1 = localAbsolutePath(paramString1);
/*  303 */     paramString2 = remoteAbsolutePath(paramString2);
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  308 */       Vector vector = glob_remote(paramString2);
/*  309 */       int i = vector.size();
/*  310 */       if (i != 1) {
/*  311 */         if (i == 0) {
/*  312 */           if (isPattern(paramString2)) {
/*  313 */             throw new SftpException(4, paramString2);
/*      */           }
/*  315 */           paramString2 = Util.unquote(paramString2);
/*      */         } 
/*  317 */         throw new SftpException(4, vector.toString());
/*      */       } 
/*      */       
/*  320 */       paramString2 = vector.elementAt(0);
/*      */ 
/*      */       
/*  323 */       boolean bool = isRemoteDir(paramString2);
/*      */       
/*  325 */       vector = glob_local(paramString1);
/*  326 */       i = vector.size();
/*      */       
/*  328 */       StringBuffer stringBuffer = null;
/*  329 */       if (bool) {
/*  330 */         if (!paramString2.endsWith("/")) {
/*  331 */           paramString2 = paramString2 + "/";
/*      */         }
/*  333 */         stringBuffer = new StringBuffer(paramString2);
/*      */       }
/*  335 */       else if (i > 1) {
/*  336 */         throw new SftpException(4, "Copying multiple files, but the destination is missing or a file.");
/*      */       } 
/*      */ 
/*      */       
/*  340 */       for (byte b = 0; b < i; b++) {
/*  341 */         String str1 = vector.elementAt(b);
/*  342 */         String str2 = null;
/*  343 */         if (bool) {
/*  344 */           int j = str1.lastIndexOf(file_separatorc);
/*  345 */           if (fs_is_bs) {
/*  346 */             int k = str1.lastIndexOf('/');
/*  347 */             if (k != -1 && k > j)
/*  348 */               j = k; 
/*      */           } 
/*  350 */           if (j == -1) { stringBuffer.append(str1); }
/*  351 */           else { stringBuffer.append(str1.substring(j + 1)); }
/*  352 */            str2 = stringBuffer.toString();
/*  353 */           stringBuffer.delete(paramString2.length(), str2.length());
/*      */         } else {
/*      */           
/*  356 */           str2 = paramString2;
/*      */         } 
/*      */ 
/*      */         
/*  360 */         long l = 0L;
/*  361 */         if (paramInt == 1) {
/*      */           try {
/*  363 */             SftpATTRS sftpATTRS = _stat(str2);
/*  364 */             l = sftpATTRS.getSize();
/*      */           }
/*  366 */           catch (Exception exception) {}
/*      */ 
/*      */           
/*  369 */           long l1 = (new File(str1)).length();
/*  370 */           if (l1 < l) {
/*  371 */             throw new SftpException(4, "failed to resume for " + str2);
/*      */           }
/*      */           
/*  374 */           if (l1 == l) {
/*      */             return;
/*      */           }
/*      */         } 
/*      */         
/*  379 */         if (paramSftpProgressMonitor != null) {
/*  380 */           paramSftpProgressMonitor.init(0, str1, str2, (new File(str1)).length());
/*      */           
/*  382 */           if (paramInt == 1) {
/*  383 */             paramSftpProgressMonitor.count(l);
/*      */           }
/*      */         } 
/*  386 */         FileInputStream fileInputStream = null;
/*      */         try {
/*  388 */           fileInputStream = new FileInputStream(str1);
/*  389 */           _put(fileInputStream, str2, paramSftpProgressMonitor, paramInt);
/*      */         } finally {
/*      */           
/*  392 */           if (fileInputStream != null) {
/*  393 */             fileInputStream.close();
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } catch (Exception exception) {
/*      */       
/*  399 */       if (exception instanceof SftpException) throw (SftpException)exception; 
/*  400 */       if (exception instanceof Throwable)
/*  401 */         throw new SftpException(4, exception.toString(), exception); 
/*  402 */       throw new SftpException(4, exception.toString());
/*      */     } 
/*      */   }
/*      */   public void put(InputStream paramInputStream, String paramString) throws SftpException {
/*  406 */     put(paramInputStream, paramString, (SftpProgressMonitor)null, 0);
/*      */   }
/*      */   public void put(InputStream paramInputStream, String paramString, int paramInt) throws SftpException {
/*  409 */     put(paramInputStream, paramString, (SftpProgressMonitor)null, paramInt);
/*      */   }
/*      */   
/*      */   public void put(InputStream paramInputStream, String paramString, SftpProgressMonitor paramSftpProgressMonitor) throws SftpException {
/*  413 */     put(paramInputStream, paramString, paramSftpProgressMonitor, 0);
/*      */   }
/*      */   
/*      */   public void put(InputStream paramInputStream, String paramString, SftpProgressMonitor paramSftpProgressMonitor, int paramInt) throws SftpException {
/*      */     try {
/*  418 */       paramString = remoteAbsolutePath(paramString);
/*      */       
/*  420 */       Vector vector = glob_remote(paramString);
/*  421 */       int i = vector.size();
/*  422 */       if (i != 1) {
/*  423 */         if (i == 0) {
/*  424 */           if (isPattern(paramString)) {
/*  425 */             throw new SftpException(4, paramString);
/*      */           }
/*  427 */           paramString = Util.unquote(paramString);
/*      */         } 
/*  429 */         throw new SftpException(4, vector.toString());
/*      */       } 
/*      */       
/*  432 */       paramString = vector.elementAt(0);
/*      */ 
/*      */       
/*  435 */       if (isRemoteDir(paramString)) {
/*  436 */         throw new SftpException(4, paramString + " is a directory");
/*      */       }
/*      */       
/*  439 */       _put(paramInputStream, paramString, paramSftpProgressMonitor, paramInt);
/*      */     } catch (Exception exception) {
/*      */       
/*  442 */       if (exception instanceof SftpException) throw (SftpException)exception; 
/*  443 */       if (exception instanceof Throwable)
/*  444 */         throw new SftpException(4, exception.toString(), exception); 
/*  445 */       throw new SftpException(4, exception.toString());
/*      */     } 
/*      */   }
/*      */   
/*      */   public void _put(InputStream paramInputStream, String paramString, SftpProgressMonitor paramSftpProgressMonitor, int paramInt) throws SftpException {
/*      */     try {
/*      */       int i1;
/*  452 */       byte[] arrayOfByte1 = Util.str2byte(paramString, this.fEncoding);
/*  453 */       long l1 = 0L;
/*  454 */       if (paramInt == 1 || paramInt == 2) {
/*      */         try {
/*  456 */           SftpATTRS sftpATTRS = _stat(arrayOfByte1);
/*  457 */           l1 = sftpATTRS.getSize();
/*      */         }
/*  459 */         catch (Exception exception) {}
/*      */       }
/*      */ 
/*      */       
/*  463 */       if (paramInt == 1 && l1 > 0L) {
/*  464 */         long l = paramInputStream.skip(l1);
/*  465 */         if (l < l1) {
/*  466 */           throw new SftpException(4, "failed to resume for " + paramString);
/*      */         }
/*      */       } 
/*      */       
/*  470 */       if (paramInt == 0) { sendOPENW(arrayOfByte1); }
/*  471 */       else { sendOPENA(arrayOfByte1); }
/*      */       
/*  473 */       Header header = new Header(this);
/*  474 */       header = header(this.buf, header);
/*  475 */       int i = header.length;
/*  476 */       int j = header.type;
/*      */       
/*  478 */       fill(this.buf, i);
/*      */       
/*  480 */       if (j != 101 && j != 102) {
/*  481 */         throw new SftpException(4, "invalid type=" + j);
/*      */       }
/*  483 */       if (j == 101) {
/*  484 */         int i2 = this.buf.getInt();
/*  485 */         throwStatusError(this.buf, i2);
/*      */       } 
/*  487 */       byte[] arrayOfByte2 = this.buf.getString();
/*  488 */       byte[] arrayOfByte3 = null;
/*      */       
/*  490 */       boolean bool = true;
/*      */       
/*  492 */       if (!bool) {
/*  493 */         arrayOfByte3 = new byte[this.buf.buffer.length - 39 + arrayOfByte2.length + 32 + 20];
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  500 */       long l2 = 0L;
/*  501 */       if (paramInt == 1 || paramInt == 2) {
/*  502 */         l2 += l1;
/*      */       }
/*      */       
/*  505 */       int k = this.seq;
/*  506 */       int m = this.seq;
/*  507 */       byte b = 0;
/*      */       do {
/*  509 */         int i2 = 0;
/*  510 */         int i3 = 0;
/*  511 */         int i4 = 0;
/*  512 */         i1 = 0;
/*      */         
/*  514 */         if (!bool) {
/*  515 */           i4 = arrayOfByte3.length - i3;
/*      */         } else {
/*      */           
/*  518 */           arrayOfByte3 = this.buf.buffer;
/*  519 */           i3 = 39 + arrayOfByte2.length;
/*  520 */           i4 = this.buf.buffer.length - i3 - 32 - 20;
/*      */         } 
/*      */ 
/*      */         
/*      */         do {
/*  525 */           i2 = paramInputStream.read(arrayOfByte3, i3, i4);
/*  526 */           if (i2 <= 0)
/*  527 */             continue;  i3 += i2;
/*  528 */           i4 -= i2;
/*  529 */           i1 += i2;
/*      */         
/*      */         }
/*  532 */         while (i4 > 0 && i2 > 0);
/*  533 */         if (i1 <= 0)
/*      */           break; 
/*  535 */         int i5 = i1;
/*  536 */         while (i5 > 0) {
/*  537 */           i5 -= sendWRITE(arrayOfByte2, l2, arrayOfByte3, 0, i5);
/*  538 */           if (this.seq - 1 == k || this.io_in.available() >= 1024)
/*      */           {
/*  540 */             while (this.io_in.available() > 0 && 
/*  541 */               checkStatus(this.ackid, header)) {
/*  542 */               m = this.ackid[0];
/*  543 */               if (k > m || m > this.seq - 1) {
/*  544 */                 if (m == this.seq) {
/*  545 */                   System.err.println("ack error: startid=" + k + " seq=" + this.seq + " _ackid=" + m);
/*      */                 }
/*      */                 else {
/*      */                   
/*  549 */                   throw new SftpException(4, "ack error: startid=" + k + " seq=" + this.seq + " _ackid=" + m);
/*      */                 } 
/*      */               }
/*  552 */               b++;
/*      */             } 
/*      */           }
/*      */         } 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  560 */         l2 += i1;
/*  561 */       } while (paramSftpProgressMonitor == null || paramSftpProgressMonitor.count(i1));
/*      */ 
/*      */ 
/*      */       
/*  565 */       int n = this.seq - k;
/*  566 */       while (n > b && 
/*  567 */         checkStatus((int[])null, header))
/*      */       {
/*      */         
/*  570 */         b++;
/*      */       }
/*  572 */       if (paramSftpProgressMonitor != null) paramSftpProgressMonitor.end(); 
/*  573 */       _sendCLOSE(arrayOfByte2, header);
/*      */     } catch (Exception exception) {
/*      */       
/*  576 */       if (exception instanceof SftpException) throw (SftpException)exception; 
/*  577 */       if (exception instanceof Throwable)
/*  578 */         throw new SftpException(4, exception.toString(), exception); 
/*  579 */       throw new SftpException(4, exception.toString());
/*      */     } 
/*      */   }
/*      */   
/*      */   public OutputStream put(String paramString) throws SftpException {
/*  584 */     return put(paramString, (SftpProgressMonitor)null, 0);
/*      */   }
/*      */   public OutputStream put(String paramString, int paramInt) throws SftpException {
/*  587 */     return put(paramString, (SftpProgressMonitor)null, paramInt);
/*      */   }
/*      */   public OutputStream put(String paramString, SftpProgressMonitor paramSftpProgressMonitor, int paramInt) throws SftpException {
/*  590 */     return put(paramString, paramSftpProgressMonitor, paramInt, 0L);
/*      */   }
/*      */   public OutputStream put(String paramString, SftpProgressMonitor paramSftpProgressMonitor, int paramInt, long paramLong) throws SftpException {
/*  593 */     paramString = remoteAbsolutePath(paramString);
/*      */     
/*      */     try {
/*  596 */       paramString = isUnique(paramString);
/*      */       
/*  598 */       if (isRemoteDir(paramString)) {
/*  599 */         throw new SftpException(4, paramString + " is a directory");
/*      */       }
/*      */       
/*  602 */       byte[] arrayOfByte1 = Util.str2byte(paramString, this.fEncoding);
/*      */       
/*  604 */       long l = 0L;
/*  605 */       if (paramInt == 1 || paramInt == 2) {
/*      */         try {
/*  607 */           SftpATTRS sftpATTRS = _stat(arrayOfByte1);
/*  608 */           l = sftpATTRS.getSize();
/*      */         }
/*  610 */         catch (Exception exception) {}
/*      */       }
/*      */ 
/*      */ 
/*      */       
/*  615 */       if (paramInt == 0) { sendOPENW(arrayOfByte1); }
/*  616 */       else { sendOPENA(arrayOfByte1); }
/*      */       
/*  618 */       Header header = new Header(this);
/*  619 */       header = header(this.buf, header);
/*  620 */       int i = header.length;
/*  621 */       int j = header.type;
/*      */       
/*  623 */       fill(this.buf, i);
/*      */       
/*  625 */       if (j != 101 && j != 102) {
/*  626 */         throw new SftpException(4, "");
/*      */       }
/*  628 */       if (j == 101) {
/*  629 */         int k = this.buf.getInt();
/*  630 */         throwStatusError(this.buf, k);
/*      */       } 
/*  632 */       byte[] arrayOfByte2 = this.buf.getString();
/*      */       
/*  634 */       if (paramInt == 1 || paramInt == 2) {
/*  635 */         paramLong += l;
/*      */       }
/*      */       
/*  638 */       long[] arrayOfLong = new long[1];
/*  639 */       arrayOfLong[0] = paramLong;
/*  640 */       return new OutputStream(this, arrayOfByte2, arrayOfLong, paramSftpProgressMonitor) { private boolean init; private boolean isClosed; private int[] ackid; private int startid; private int _ackid;
/*      */           private int ackcount;
/*      */           private int writecount;
/*      */           private ChannelSftp.Header header;
/*      */           byte[] _data;
/*      */           private final byte[] val$handle;
/*      */           private final long[] val$_offset;
/*      */           private final SftpProgressMonitor val$monitor;
/*      */           private final ChannelSftp this$0;
/*      */           
/*      */           public void write(byte[] param1ArrayOfbyte) throws IOException {
/*  651 */             write(param1ArrayOfbyte, 0, param1ArrayOfbyte.length);
/*      */           }
/*      */           
/*      */           public void write(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) throws IOException {
/*  655 */             if (this.init) {
/*  656 */               this.startid = this.this$0.seq;
/*  657 */               this._ackid = this.this$0.seq;
/*  658 */               this.init = false;
/*      */             } 
/*      */             
/*  661 */             if (this.isClosed) {
/*  662 */               throw new IOException("stream already closed");
/*      */             }
/*      */ 
/*      */             
/*  666 */             try { int i = param1Int2;
/*  667 */               while (i > 0) {
/*  668 */                 int j = this.this$0.sendWRITE(this.val$handle, this.val$_offset[0], param1ArrayOfbyte, param1Int1, i);
/*  669 */                 this.writecount++;
/*  670 */                 this.val$_offset[0] = this.val$_offset[0] + j;
/*  671 */                 param1Int1 += j;
/*  672 */                 i -= j;
/*  673 */                 if (this.this$0.seq - 1 == this.startid || this.this$0.io_in.available() >= 1024)
/*      */                 {
/*  675 */                   while (this.this$0.io_in.available() > 0 && 
/*  676 */                     this.this$0.checkStatus(this.ackid, this.header)) {
/*  677 */                     this._ackid = this.ackid[0];
/*  678 */                     if (this.startid > this._ackid || this._ackid > this.this$0.seq - 1) {
/*  679 */                       throw new SftpException(4, "");
/*      */                     }
/*  681 */                     this.ackcount++;
/*      */                   } 
/*      */                 }
/*      */               } 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  689 */               if (this.val$monitor != null && !this.val$monitor.count(param1Int2)) {
/*  690 */                 close();
/*  691 */                 throw new IOException("canceled");
/*      */               }  }
/*      */             catch (IOException iOException)
/*  694 */             { throw iOException; }
/*  695 */             catch (Exception exception) { throw new IOException(exception.toString()); }
/*      */           
/*      */           }
/*      */           
/*      */           public void write(int param1Int) throws IOException {
/*  700 */             this._data[0] = (byte)param1Int;
/*  701 */             write(this._data, 0, 1);
/*      */           }
/*      */ 
/*      */           
/*      */           public void flush() throws IOException {
/*  706 */             if (this.isClosed) {
/*  707 */               throw new IOException("stream already closed");
/*      */             }
/*      */             
/*  710 */             if (!this.init) {
/*      */               try {
/*  712 */                 while (this.writecount > this.ackcount && 
/*  713 */                   this.this$0.checkStatus((int[])null, this.header))
/*      */                 {
/*      */                   
/*  716 */                   this.ackcount++;
/*      */                 }
/*      */               } catch (SftpException sftpException) {
/*      */                 
/*  720 */                 throw new IOException(sftpException.toString());
/*      */               } 
/*      */             }
/*      */           }
/*      */           
/*      */           public void close() throws IOException {
/*  726 */             if (this.isClosed) {
/*      */               return;
/*      */             }
/*  729 */             flush();
/*  730 */             if (this.val$monitor != null) this.val$monitor.end();  
/*  731 */             try { this.this$0._sendCLOSE(this.val$handle, this.header); }
/*  732 */             catch (IOException iOException) { throw iOException; }
/*      */             catch (Exception exception)
/*  734 */             { throw new IOException(exception.toString()); }
/*      */             
/*  736 */             this.isClosed = true;
/*      */           } }
/*      */         ;
/*      */     }
/*      */     catch (Exception exception) {
/*      */       
/*  742 */       if (exception instanceof SftpException) throw (SftpException)exception; 
/*  743 */       if (exception instanceof Throwable)
/*  744 */         throw new SftpException(4, "", exception); 
/*  745 */       throw new SftpException(4, "");
/*      */     } 
/*      */   }
/*      */   
/*      */   public void get(String paramString1, String paramString2) throws SftpException {
/*  750 */     get(paramString1, paramString2, (SftpProgressMonitor)null, 0);
/*      */   }
/*      */   
/*      */   public void get(String paramString1, String paramString2, SftpProgressMonitor paramSftpProgressMonitor) throws SftpException {
/*  754 */     get(paramString1, paramString2, paramSftpProgressMonitor, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void get(String paramString1, String paramString2, SftpProgressMonitor paramSftpProgressMonitor, int paramInt) throws SftpException {
/*  760 */     paramString1 = remoteAbsolutePath(paramString1);
/*  761 */     paramString2 = localAbsolutePath(paramString2);
/*      */     
/*      */     try {
/*  764 */       Vector vector = glob_remote(paramString1);
/*  765 */       int i = vector.size();
/*  766 */       if (i == 0) {
/*  767 */         throw new SftpException(2, "No such file");
/*      */       }
/*      */       
/*  770 */       File file = new File(paramString2);
/*  771 */       boolean bool = file.isDirectory();
/*  772 */       StringBuffer stringBuffer = null;
/*  773 */       if (bool) {
/*  774 */         if (!paramString2.endsWith(file_separator)) {
/*  775 */           paramString2 = paramString2 + file_separator;
/*      */         }
/*  777 */         stringBuffer = new StringBuffer(paramString2);
/*      */       }
/*  779 */       else if (i > 1) {
/*  780 */         throw new SftpException(4, "Copying multiple files, but destination is missing or a file.");
/*      */       } 
/*      */ 
/*      */       
/*  784 */       for (byte b = 0; b < i; b++) {
/*  785 */         String str1 = vector.elementAt(b);
/*  786 */         SftpATTRS sftpATTRS = _stat(str1);
/*  787 */         if (sftpATTRS.isDir()) {
/*  788 */           throw new SftpException(4, "not supported to get directory " + str1);
/*      */         }
/*      */ 
/*      */         
/*  792 */         String str2 = null;
/*  793 */         if (bool) {
/*  794 */           int j = str1.lastIndexOf('/');
/*  795 */           if (j == -1) { stringBuffer.append(str1); }
/*  796 */           else { stringBuffer.append(str1.substring(j + 1)); }
/*  797 */            str2 = stringBuffer.toString();
/*  798 */           stringBuffer.delete(paramString2.length(), str2.length());
/*      */         } else {
/*      */           
/*  801 */           str2 = paramString2;
/*      */         } 
/*      */         
/*  804 */         if (paramInt == 1) {
/*  805 */           long l1 = sftpATTRS.getSize();
/*  806 */           long l2 = (new File(str2)).length();
/*  807 */           if (l2 > l1) {
/*  808 */             throw new SftpException(4, "failed to resume for " + str2);
/*      */           }
/*      */           
/*  811 */           if (l2 == l1) {
/*      */             return;
/*      */           }
/*      */         } 
/*      */         
/*  816 */         if (paramSftpProgressMonitor != null) {
/*  817 */           paramSftpProgressMonitor.init(1, str1, str2, sftpATTRS.getSize());
/*  818 */           if (paramInt == 1) {
/*  819 */             paramSftpProgressMonitor.count((new File(str2)).length());
/*      */           }
/*      */         } 
/*      */         
/*  823 */         FileOutputStream fileOutputStream = null;
/*      */         try {
/*  825 */           if (paramInt == 0) {
/*  826 */             fileOutputStream = new FileOutputStream(str2);
/*      */           } else {
/*      */             
/*  829 */             fileOutputStream = new FileOutputStream(str2, true);
/*      */           } 
/*      */           
/*  832 */           _get(str1, fileOutputStream, paramSftpProgressMonitor, paramInt, (new File(str2)).length());
/*      */         } finally {
/*      */           
/*  835 */           if (fileOutputStream != null) {
/*  836 */             fileOutputStream.close();
/*      */           }
/*      */         } 
/*      */       } 
/*      */     } catch (Exception exception) {
/*      */       
/*  842 */       if (exception instanceof SftpException) throw (SftpException)exception; 
/*  843 */       if (exception instanceof Throwable)
/*  844 */         throw new SftpException(4, "", exception); 
/*  845 */       throw new SftpException(4, "");
/*      */     } 
/*      */   }
/*      */   public void get(String paramString, OutputStream paramOutputStream) throws SftpException {
/*  849 */     get(paramString, paramOutputStream, (SftpProgressMonitor)null, 0, 0L);
/*      */   }
/*      */   
/*      */   public void get(String paramString, OutputStream paramOutputStream, SftpProgressMonitor paramSftpProgressMonitor) throws SftpException {
/*  853 */     get(paramString, paramOutputStream, paramSftpProgressMonitor, 0, 0L);
/*      */   }
/*      */ 
/*      */   
/*      */   public void get(String paramString, OutputStream paramOutputStream, SftpProgressMonitor paramSftpProgressMonitor, int paramInt, long paramLong) throws SftpException {
/*      */     try {
/*  859 */       paramString = remoteAbsolutePath(paramString);
/*      */       
/*  861 */       paramString = isUnique(paramString);
/*      */       
/*  863 */       if (paramSftpProgressMonitor != null) {
/*  864 */         SftpATTRS sftpATTRS = _stat(paramString);
/*  865 */         paramSftpProgressMonitor.init(1, paramString, "??", sftpATTRS.getSize());
/*  866 */         if (paramInt == 1) {
/*  867 */           paramSftpProgressMonitor.count(paramLong);
/*      */         }
/*      */       } 
/*  870 */       _get(paramString, paramOutputStream, paramSftpProgressMonitor, paramInt, paramLong);
/*      */     } catch (Exception exception) {
/*      */       
/*  873 */       if (exception instanceof SftpException) throw (SftpException)exception; 
/*  874 */       if (exception instanceof Throwable)
/*  875 */         throw new SftpException(4, "", exception); 
/*  876 */       throw new SftpException(4, "");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void _get(String paramString, OutputStream paramOutputStream, SftpProgressMonitor paramSftpProgressMonitor, int paramInt, long paramLong) throws SftpException {
/*  884 */     byte[] arrayOfByte = Util.str2byte(paramString, this.fEncoding);
/*      */     try {
/*  886 */       sendOPENR(arrayOfByte);
/*      */       
/*  888 */       Header header = new Header(this);
/*  889 */       header = header(this.buf, header);
/*  890 */       int i = header.length;
/*  891 */       int j = header.type;
/*      */       
/*  893 */       fill(this.buf, i);
/*      */       
/*  895 */       if (j != 101 && j != 102) {
/*  896 */         throw new SftpException(4, "");
/*      */       }
/*      */       
/*  899 */       if (j == 101) {
/*  900 */         int m = this.buf.getInt();
/*  901 */         throwStatusError(this.buf, m);
/*      */       } 
/*      */       
/*  904 */       byte[] arrayOfByte1 = this.buf.getString();
/*      */       
/*  906 */       long l = 0L;
/*  907 */       if (paramInt == 1) {
/*  908 */         l += paramLong;
/*      */       }
/*      */       
/*  911 */       int k = 0;
/*      */ 
/*      */       
/*      */       label64: while (true) {
/*  915 */         k = this.buf.buffer.length - 13;
/*  916 */         if (this.server_version == 0) k = 1024; 
/*  917 */         sendREAD(arrayOfByte1, l, k);
/*      */         
/*  919 */         header = header(this.buf, header);
/*  920 */         i = header.length;
/*  921 */         j = header.type;
/*      */         
/*  923 */         if (j == 101) {
/*  924 */           fill(this.buf, i);
/*  925 */           int i1 = this.buf.getInt();
/*  926 */           if (i1 == 1) {
/*      */             break;
/*      */           }
/*  929 */           throwStatusError(this.buf, i1);
/*      */         } 
/*      */         
/*  932 */         if (j != 103) {
/*      */           break;
/*      */         }
/*      */         
/*  936 */         this.buf.rewind();
/*  937 */         fill(this.buf.buffer, 0, 4); i -= 4;
/*  938 */         int m = this.buf.getInt();
/*  939 */         int n = m;
/*      */         
/*  941 */         while (n > 0) {
/*  942 */           int i1 = n;
/*  943 */           if (i1 > this.buf.buffer.length) {
/*  944 */             i1 = this.buf.buffer.length;
/*      */           }
/*  946 */           m = this.io_in.read(this.buf.buffer, 0, i1);
/*  947 */           if (m < 0) {
/*      */             break label64;
/*      */           }
/*  950 */           int i2 = m;
/*  951 */           paramOutputStream.write(this.buf.buffer, 0, i2);
/*      */           
/*  953 */           l += i2;
/*  954 */           n -= i2;
/*      */           
/*  956 */           if (paramSftpProgressMonitor != null && 
/*  957 */             !paramSftpProgressMonitor.count(i2)) {
/*  958 */             while (n > 0) {
/*  959 */               m = this.io_in.read(this.buf.buffer, 0, (this.buf.buffer.length < n) ? this.buf.buffer.length : n);
/*      */ 
/*      */               
/*  962 */               if (m <= 0)
/*  963 */                 break;  n -= m;
/*      */             } 
/*      */ 
/*      */             
/*      */             break label64;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/*  972 */       paramOutputStream.flush();
/*      */       
/*  974 */       if (paramSftpProgressMonitor != null) paramSftpProgressMonitor.end(); 
/*  975 */       _sendCLOSE(arrayOfByte1, header);
/*      */     } catch (Exception exception) {
/*      */       
/*  978 */       if (exception instanceof SftpException) throw (SftpException)exception; 
/*  979 */       if (exception instanceof Throwable)
/*  980 */         throw new SftpException(4, "", exception); 
/*  981 */       throw new SftpException(4, "");
/*      */     } 
/*      */   }
/*      */   
/*      */   public InputStream get(String paramString) throws SftpException {
/*  986 */     return get(paramString, (SftpProgressMonitor)null, 0L);
/*      */   }
/*      */   public InputStream get(String paramString, SftpProgressMonitor paramSftpProgressMonitor) throws SftpException {
/*  989 */     return get(paramString, paramSftpProgressMonitor, 0L);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream get(String paramString, int paramInt) throws SftpException {
/*  996 */     return get(paramString, (SftpProgressMonitor)null, 0L);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public InputStream get(String paramString, SftpProgressMonitor paramSftpProgressMonitor, int paramInt) throws SftpException {
/* 1002 */     return get(paramString, paramSftpProgressMonitor, 0L);
/*      */   }
/*      */   public InputStream get(String paramString, SftpProgressMonitor paramSftpProgressMonitor, long paramLong) throws SftpException {
/* 1005 */     paramString = remoteAbsolutePath(paramString);
/*      */     try {
/* 1007 */       paramString = isUnique(paramString);
/*      */       
/* 1009 */       byte[] arrayOfByte1 = Util.str2byte(paramString, this.fEncoding);
/*      */       
/* 1011 */       SftpATTRS sftpATTRS = _stat(arrayOfByte1);
/* 1012 */       if (paramSftpProgressMonitor != null) {
/* 1013 */         paramSftpProgressMonitor.init(1, paramString, "??", sftpATTRS.getSize());
/*      */       }
/*      */       
/* 1016 */       sendOPENR(arrayOfByte1);
/*      */       
/* 1018 */       Header header = new Header(this);
/* 1019 */       header = header(this.buf, header);
/* 1020 */       int i = header.length;
/* 1021 */       int j = header.type;
/*      */       
/* 1023 */       fill(this.buf, i);
/*      */       
/* 1025 */       if (j != 101 && j != 102) {
/* 1026 */         throw new SftpException(4, "");
/*      */       }
/* 1028 */       if (j == 101) {
/* 1029 */         int k = this.buf.getInt();
/* 1030 */         throwStatusError(this.buf, k);
/*      */       } 
/*      */       
/* 1033 */       byte[] arrayOfByte2 = this.buf.getString();
/*      */       
/* 1035 */       return new InputStream(this, paramLong, paramSftpProgressMonitor, arrayOfByte2) { long offset; boolean closed; int rest_length; byte[] _data;
/*      */           byte[] rest_byte;
/*      */           ChannelSftp.Header header;
/*      */           private final long val$skip;
/*      */           private final SftpProgressMonitor val$monitor;
/*      */           private final byte[] val$handle;
/*      */           private final ChannelSftp this$0;
/*      */           
/*      */           public int read() throws IOException {
/* 1044 */             if (this.closed) return -1; 
/* 1045 */             int i = read(this._data, 0, 1);
/* 1046 */             if (i == -1) return -1;
/*      */             
/* 1048 */             return this._data[0] & 0xFF;
/*      */           }
/*      */           
/*      */           public int read(byte[] param1ArrayOfbyte) throws IOException {
/* 1052 */             if (this.closed) return -1; 
/* 1053 */             return read(param1ArrayOfbyte, 0, param1ArrayOfbyte.length);
/*      */           }
/*      */           public int read(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) throws IOException {
/* 1056 */             if (this.closed) return -1; 
/* 1057 */             if (param1ArrayOfbyte == null) throw new NullPointerException(); 
/* 1058 */             if (param1Int1 < 0 || param1Int2 < 0 || param1Int1 + param1Int2 > param1ArrayOfbyte.length) {
/* 1059 */               throw new IndexOutOfBoundsException();
/*      */             }
/* 1061 */             if (param1Int2 == 0) return 0;
/*      */             
/* 1063 */             if (this.rest_length > 0) {
/* 1064 */               int n = this.rest_length;
/* 1065 */               if (n > param1Int2) n = param1Int2; 
/* 1066 */               System.arraycopy(this.rest_byte, 0, param1ArrayOfbyte, param1Int1, n);
/* 1067 */               if (n != this.rest_length) {
/* 1068 */                 System.arraycopy(this.rest_byte, n, this.rest_byte, 0, this.rest_length - n);
/*      */               }
/*      */ 
/*      */               
/* 1072 */               if (this.val$monitor != null && 
/* 1073 */                 !this.val$monitor.count(n)) {
/* 1074 */                 close();
/* 1075 */                 return -1;
/*      */               } 
/*      */ 
/*      */               
/* 1079 */               this.rest_length -= n;
/* 1080 */               return n;
/*      */             } 
/*      */             
/* 1083 */             if (this.this$0.buf.buffer.length - 13 < param1Int2) {
/* 1084 */               param1Int2 = this.this$0.buf.buffer.length - 13;
/*      */             }
/* 1086 */             if (this.this$0.server_version == 0 && param1Int2 > 1024) {
/* 1087 */               param1Int2 = 1024;
/*      */             }
/*      */             
/* 1090 */             try { this.this$0.sendREAD(this.val$handle, this.offset, param1Int2); }
/* 1091 */             catch (Exception exception) { throw new IOException("error"); }
/*      */             
/* 1093 */             this.header = this.this$0.header(this.this$0.buf, this.header);
/* 1094 */             this.rest_length = this.header.length;
/* 1095 */             int i = this.header.type;
/* 1096 */             int j = this.header.rid;
/*      */             
/* 1098 */             if (i != 101 && i != 103) {
/* 1099 */               throw new IOException("error");
/*      */             }
/* 1101 */             if (i == 101) {
/* 1102 */               this.this$0.fill(this.this$0.buf, this.rest_length);
/* 1103 */               int n = this.this$0.buf.getInt();
/* 1104 */               this.rest_length = 0;
/* 1105 */               if (n == 1) {
/* 1106 */                 close();
/* 1107 */                 return -1;
/*      */               } 
/*      */               
/* 1110 */               throw new IOException("error");
/*      */             } 
/* 1112 */             this.this$0.buf.rewind();
/* 1113 */             this.this$0.fill(this.this$0.buf.buffer, 0, 4);
/* 1114 */             int k = this.this$0.buf.getInt(); this.rest_length -= 4;
/*      */             
/* 1116 */             this.offset += this.rest_length;
/* 1117 */             int m = k;
/* 1118 */             if (m > 0) {
/* 1119 */               int n = this.rest_length;
/* 1120 */               if (n > param1Int2) {
/* 1121 */                 n = param1Int2;
/*      */               }
/* 1123 */               k = this.this$0.io_in.read(param1ArrayOfbyte, param1Int1, n);
/* 1124 */               if (k < 0) {
/* 1125 */                 return -1;
/*      */               }
/* 1127 */               this.rest_length -= k;
/*      */               
/* 1129 */               if (this.rest_length > 0) {
/* 1130 */                 if (this.rest_byte.length < this.rest_length) {
/* 1131 */                   this.rest_byte = new byte[this.rest_length];
/*      */                 }
/* 1133 */                 int i1 = 0;
/* 1134 */                 int i2 = this.rest_length;
/*      */                 
/* 1136 */                 while (i2 > 0) {
/* 1137 */                   int i3 = this.this$0.io_in.read(this.rest_byte, i1, i2);
/* 1138 */                   if (i3 <= 0)
/* 1139 */                     break;  i1 += i3;
/* 1140 */                   i2 -= i3;
/*      */                 } 
/*      */               } 
/*      */               
/* 1144 */               if (this.val$monitor != null && 
/* 1145 */                 !this.val$monitor.count(k)) {
/* 1146 */                 close();
/* 1147 */                 return -1;
/*      */               } 
/*      */ 
/*      */               
/* 1151 */               return k;
/*      */             } 
/* 1153 */             return 0;
/*      */           }
/*      */           public void close() throws IOException {
/* 1156 */             if (this.closed)
/* 1157 */               return;  this.closed = true;
/* 1158 */             if (this.val$monitor != null) this.val$monitor.end();  
/* 1159 */             try { this.this$0._sendCLOSE(this.val$handle, this.header); }
/* 1160 */             catch (Exception exception) { throw new IOException("error"); }
/*      */           
/*      */           } }
/*      */         ;
/*      */     } catch (Exception exception) {
/*      */       
/* 1166 */       if (exception instanceof SftpException) throw (SftpException)exception; 
/* 1167 */       if (exception instanceof Throwable)
/* 1168 */         throw new SftpException(4, "", exception); 
/* 1169 */       throw new SftpException(4, "");
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public Vector ls(String paramString) throws SftpException {
/*      */     try {
/* 1176 */       paramString = remoteAbsolutePath(paramString);
/* 1177 */       byte[] arrayOfByte1 = null;
/* 1178 */       Vector vector = new Vector();
/*      */       
/* 1180 */       int i = paramString.lastIndexOf('/');
/* 1181 */       String str1 = paramString.substring(0, (i == 0) ? 1 : i);
/* 1182 */       String str2 = paramString.substring(i + 1);
/* 1183 */       str1 = Util.unquote(str1);
/*      */ 
/*      */ 
/*      */       
/* 1187 */       byte[][] arrayOfByte = new byte[1][];
/* 1188 */       boolean bool = isPattern(str2, arrayOfByte);
/*      */       
/* 1190 */       if (bool) {
/* 1191 */         arrayOfByte1 = arrayOfByte[0];
/*      */       } else {
/*      */         
/* 1194 */         String str = Util.unquote(paramString);
/*      */         
/* 1196 */         SftpATTRS sftpATTRS = _stat(str);
/* 1197 */         if (sftpATTRS.isDir()) {
/* 1198 */           arrayOfByte1 = null;
/* 1199 */           str1 = str;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*      */         }
/* 1211 */         else if (this.fEncoding_is_utf8) {
/* 1212 */           arrayOfByte1 = arrayOfByte[0];
/* 1213 */           arrayOfByte1 = Util.unquote(arrayOfByte1);
/*      */         } else {
/*      */           
/* 1216 */           str2 = Util.unquote(str2);
/* 1217 */           arrayOfByte1 = Util.str2byte(str2, this.fEncoding);
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 1223 */       sendOPENDIR(Util.str2byte(str1, this.fEncoding));
/*      */       
/* 1225 */       Header header = new Header(this);
/* 1226 */       header = header(this.buf, header);
/* 1227 */       int j = header.length;
/* 1228 */       int k = header.type;
/*      */       
/* 1230 */       fill(this.buf, j);
/*      */       
/* 1232 */       if (k != 101 && k != 102) {
/* 1233 */         throw new SftpException(4, "");
/*      */       }
/* 1235 */       if (k == 101) {
/* 1236 */         int m = this.buf.getInt();
/* 1237 */         throwStatusError(this.buf, m);
/*      */       } 
/*      */       
/* 1240 */       byte[] arrayOfByte2 = this.buf.getString();
/*      */       
/*      */       while (true) {
/* 1243 */         sendREADDIR(arrayOfByte2);
/*      */         
/* 1245 */         header = header(this.buf, header);
/* 1246 */         j = header.length;
/* 1247 */         k = header.type;
/* 1248 */         if (k != 101 && k != 104) {
/* 1249 */           throw new SftpException(4, "");
/*      */         }
/* 1251 */         if (k == 101) {
/* 1252 */           fill(this.buf, j);
/* 1253 */           int n = this.buf.getInt();
/* 1254 */           if (n == 1)
/*      */             break; 
/* 1256 */           throwStatusError(this.buf, n);
/*      */         } 
/*      */         
/* 1259 */         this.buf.rewind();
/* 1260 */         fill(this.buf.buffer, 0, 4); j -= 4;
/* 1261 */         int m = this.buf.getInt();
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1266 */         this.buf.reset();
/* 1267 */         while (m > 0) {
/* 1268 */           if (j > 0) {
/* 1269 */             this.buf.shift();
/* 1270 */             int n = (this.buf.buffer.length > this.buf.index + j) ? j : (this.buf.buffer.length - this.buf.index);
/*      */ 
/*      */             
/* 1273 */             int i1 = fill(this.buf.buffer, this.buf.index, n);
/* 1274 */             this.buf.index += i1;
/* 1275 */             j -= i1;
/*      */           } 
/* 1277 */           byte[] arrayOfByte3 = this.buf.getString();
/* 1278 */           byte[] arrayOfByte4 = null;
/* 1279 */           if (this.server_version <= 3) {
/* 1280 */             arrayOfByte4 = this.buf.getString();
/*      */           }
/* 1282 */           SftpATTRS sftpATTRS = SftpATTRS.getATTR(this.buf);
/*      */           
/* 1284 */           boolean bool1 = false;
/* 1285 */           String str = null;
/* 1286 */           if (arrayOfByte1 == null) {
/* 1287 */             bool1 = true;
/*      */           }
/* 1289 */           else if (!bool) {
/* 1290 */             bool1 = Util.array_equals(arrayOfByte1, arrayOfByte3);
/*      */           } else {
/*      */             
/* 1293 */             byte[] arrayOfByte5 = arrayOfByte3;
/* 1294 */             if (!this.fEncoding_is_utf8) {
/* 1295 */               str = Util.byte2str(arrayOfByte5, this.fEncoding);
/* 1296 */               arrayOfByte5 = Util.str2byte(str, "UTF-8");
/*      */             } 
/* 1298 */             bool1 = Util.glob(arrayOfByte1, arrayOfByte5);
/*      */           } 
/*      */           
/* 1301 */           if (bool1) {
/* 1302 */             if (str == null) {
/* 1303 */               str = Util.byte2str(arrayOfByte3, this.fEncoding);
/*      */             }
/* 1305 */             String str3 = null;
/* 1306 */             if (arrayOfByte4 == null) {
/*      */ 
/*      */               
/* 1309 */               str3 = sftpATTRS.toString() + " " + str;
/*      */             } else {
/*      */               
/* 1312 */               str3 = Util.byte2str(arrayOfByte4, this.fEncoding);
/*      */             } 
/* 1314 */             vector.addElement(new LsEntry(this, str, str3, sftpATTRS));
/*      */           } 
/*      */           
/* 1317 */           m--;
/*      */         } 
/*      */       } 
/* 1320 */       _sendCLOSE(arrayOfByte2, header);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1339 */       return vector;
/*      */     } catch (Exception exception) {
/*      */       
/* 1342 */       if (exception instanceof SftpException) throw (SftpException)exception; 
/* 1343 */       if (exception instanceof Throwable)
/* 1344 */         throw new SftpException(4, "", exception); 
/* 1345 */       throw new SftpException(4, "");
/*      */     } 
/*      */   }
/*      */   
/*      */   public String readlink(String paramString) throws SftpException {
/*      */     try {
/* 1351 */       if (this.server_version < 3) {
/* 1352 */         throw new SftpException(8, "The remote sshd is too old to support symlink operation.");
/*      */       }
/*      */ 
/*      */       
/* 1356 */       paramString = remoteAbsolutePath(paramString);
/*      */       
/* 1358 */       paramString = isUnique(paramString);
/*      */       
/* 1360 */       sendREADLINK(Util.str2byte(paramString, this.fEncoding));
/*      */       
/* 1362 */       Header header = new Header(this);
/* 1363 */       header = header(this.buf, header);
/* 1364 */       int i = header.length;
/* 1365 */       int j = header.type;
/*      */       
/* 1367 */       fill(this.buf, i);
/*      */       
/* 1369 */       if (j != 101 && j != 104) {
/* 1370 */         throw new SftpException(4, "");
/*      */       }
/* 1372 */       if (j == 104) {
/* 1373 */         int m = this.buf.getInt();
/* 1374 */         byte[] arrayOfByte = null;
/* 1375 */         for (byte b = 0; b < m; b++) {
/* 1376 */           arrayOfByte = this.buf.getString();
/* 1377 */           if (this.server_version <= 3) {
/* 1378 */             byte[] arrayOfByte1 = this.buf.getString();
/*      */           }
/* 1380 */           SftpATTRS.getATTR(this.buf);
/*      */         } 
/* 1382 */         return Util.byte2str(arrayOfByte, this.fEncoding);
/*      */       } 
/*      */       
/* 1385 */       int k = this.buf.getInt();
/* 1386 */       throwStatusError(this.buf, k);
/*      */     } catch (Exception exception) {
/*      */       
/* 1389 */       if (exception instanceof SftpException) throw (SftpException)exception; 
/* 1390 */       if (exception instanceof Throwable)
/* 1391 */         throw new SftpException(4, "", exception); 
/* 1392 */       throw new SftpException(4, "");
/*      */     } 
/* 1394 */     return null;
/*      */   }
/*      */   public void symlink(String paramString1, String paramString2) throws SftpException {
/* 1397 */     if (this.server_version < 3) {
/* 1398 */       throw new SftpException(8, "The remote sshd is too old to support symlink operation.");
/*      */     }
/*      */ 
/*      */     
/*      */     try {
/* 1403 */       paramString1 = remoteAbsolutePath(paramString1);
/* 1404 */       paramString2 = remoteAbsolutePath(paramString2);
/*      */       
/* 1406 */       paramString1 = isUnique(paramString1);
/*      */       
/* 1408 */       if (isPattern(paramString2)) {
/* 1409 */         throw new SftpException(4, paramString2);
/*      */       }
/* 1411 */       paramString2 = Util.unquote(paramString2);
/*      */       
/* 1413 */       sendSYMLINK(Util.str2byte(paramString1, this.fEncoding), Util.str2byte(paramString2, this.fEncoding));
/*      */ 
/*      */       
/* 1416 */       Header header = new Header(this);
/* 1417 */       header = header(this.buf, header);
/* 1418 */       int i = header.length;
/* 1419 */       int j = header.type;
/*      */       
/* 1421 */       fill(this.buf, i);
/*      */       
/* 1423 */       if (j != 101) {
/* 1424 */         throw new SftpException(4, "");
/*      */       }
/*      */       
/* 1427 */       int k = this.buf.getInt();
/* 1428 */       if (k == 0)
/* 1429 */         return;  throwStatusError(this.buf, k);
/*      */     } catch (Exception exception) {
/*      */       
/* 1432 */       if (exception instanceof SftpException) throw (SftpException)exception; 
/* 1433 */       if (exception instanceof Throwable)
/* 1434 */         throw new SftpException(4, "", exception); 
/* 1435 */       throw new SftpException(4, "");
/*      */     } 
/*      */   }
/*      */   
/*      */   public void rename(String paramString1, String paramString2) throws SftpException {
/* 1440 */     if (this.server_version < 2) {
/* 1441 */       throw new SftpException(8, "The remote sshd is too old to support rename operation.");
/*      */     }
/*      */ 
/*      */     
/*      */     try {
/* 1446 */       paramString1 = remoteAbsolutePath(paramString1);
/* 1447 */       paramString2 = remoteAbsolutePath(paramString2);
/*      */       
/* 1449 */       paramString1 = isUnique(paramString1);
/*      */       
/* 1451 */       Vector vector = glob_remote(paramString2);
/* 1452 */       int i = vector.size();
/* 1453 */       if (i >= 2) {
/* 1454 */         throw new SftpException(4, vector.toString());
/*      */       }
/* 1456 */       if (i == 1) {
/* 1457 */         paramString2 = vector.elementAt(0);
/*      */       } else {
/*      */         
/* 1460 */         if (isPattern(paramString2))
/* 1461 */           throw new SftpException(4, paramString2); 
/* 1462 */         paramString2 = Util.unquote(paramString2);
/*      */       } 
/*      */       
/* 1465 */       sendRENAME(Util.str2byte(paramString1, this.fEncoding), Util.str2byte(paramString2, this.fEncoding));
/*      */ 
/*      */       
/* 1468 */       Header header = new Header(this);
/* 1469 */       header = header(this.buf, header);
/* 1470 */       int j = header.length;
/* 1471 */       int k = header.type;
/*      */       
/* 1473 */       fill(this.buf, j);
/*      */       
/* 1475 */       if (k != 101) {
/* 1476 */         throw new SftpException(4, "");
/*      */       }
/*      */       
/* 1479 */       int m = this.buf.getInt();
/* 1480 */       if (m == 0)
/* 1481 */         return;  throwStatusError(this.buf, m);
/*      */     } catch (Exception exception) {
/*      */       
/* 1484 */       if (exception instanceof SftpException) throw (SftpException)exception; 
/* 1485 */       if (exception instanceof Throwable)
/* 1486 */         throw new SftpException(4, "", exception); 
/* 1487 */       throw new SftpException(4, "");
/*      */     } 
/*      */   }
/*      */   public void rm(String paramString) throws SftpException {
/*      */     try {
/* 1492 */       paramString = remoteAbsolutePath(paramString);
/*      */       
/* 1494 */       Vector vector = glob_remote(paramString);
/* 1495 */       int i = vector.size();
/*      */       
/* 1497 */       Header header = new Header(this);
/*      */       
/* 1499 */       for (byte b = 0; b < i; b++) {
/* 1500 */         paramString = vector.elementAt(b);
/* 1501 */         sendREMOVE(Util.str2byte(paramString, this.fEncoding));
/*      */         
/* 1503 */         header = header(this.buf, header);
/* 1504 */         int j = header.length;
/* 1505 */         int k = header.type;
/*      */         
/* 1507 */         fill(this.buf, j);
/*      */         
/* 1509 */         if (k != 101) {
/* 1510 */           throw new SftpException(4, "");
/*      */         }
/* 1512 */         int m = this.buf.getInt();
/* 1513 */         if (m != 0) {
/* 1514 */           throwStatusError(this.buf, m);
/*      */         }
/*      */       } 
/*      */     } catch (Exception exception) {
/*      */       
/* 1519 */       if (exception instanceof SftpException) throw (SftpException)exception; 
/* 1520 */       if (exception instanceof Throwable)
/* 1521 */         throw new SftpException(4, "", exception); 
/* 1522 */       throw new SftpException(4, "");
/*      */     } 
/*      */   }
/*      */   
/*      */   private boolean isRemoteDir(String paramString) {
/*      */     try {
/* 1528 */       sendSTAT(Util.str2byte(paramString, this.fEncoding));
/*      */       
/* 1530 */       Header header = new Header(this);
/* 1531 */       header = header(this.buf, header);
/* 1532 */       int i = header.length;
/* 1533 */       int j = header.type;
/*      */       
/* 1535 */       fill(this.buf, i);
/*      */       
/* 1537 */       if (j != 105) {
/* 1538 */         return false;
/*      */       }
/* 1540 */       SftpATTRS sftpATTRS = SftpATTRS.getATTR(this.buf);
/* 1541 */       return sftpATTRS.isDir();
/*      */     }
/* 1543 */     catch (Exception exception) {
/* 1544 */       return false;
/*      */     } 
/*      */   }
/*      */   public void chgrp(int paramInt, String paramString) throws SftpException {
/*      */     try {
/* 1549 */       paramString = remoteAbsolutePath(paramString);
/*      */       
/* 1551 */       Vector vector = glob_remote(paramString);
/* 1552 */       int i = vector.size();
/* 1553 */       for (byte b = 0; b < i; b++) {
/* 1554 */         paramString = vector.elementAt(b);
/*      */         
/* 1556 */         SftpATTRS sftpATTRS = _stat(paramString);
/*      */         
/* 1558 */         sftpATTRS.setFLAGS(0);
/* 1559 */         sftpATTRS.setUIDGID(sftpATTRS.uid, paramInt);
/* 1560 */         _setStat(paramString, sftpATTRS);
/*      */       } 
/*      */     } catch (Exception exception) {
/*      */       
/* 1564 */       if (exception instanceof SftpException) throw (SftpException)exception; 
/* 1565 */       if (exception instanceof Throwable)
/* 1566 */         throw new SftpException(4, "", exception); 
/* 1567 */       throw new SftpException(4, "");
/*      */     } 
/*      */   }
/*      */   
/*      */   public void chown(int paramInt, String paramString) throws SftpException {
/*      */     try {
/* 1573 */       paramString = remoteAbsolutePath(paramString);
/*      */       
/* 1575 */       Vector vector = glob_remote(paramString);
/* 1576 */       int i = vector.size();
/* 1577 */       for (byte b = 0; b < i; b++) {
/* 1578 */         paramString = vector.elementAt(b);
/*      */         
/* 1580 */         SftpATTRS sftpATTRS = _stat(paramString);
/*      */         
/* 1582 */         sftpATTRS.setFLAGS(0);
/* 1583 */         sftpATTRS.setUIDGID(paramInt, sftpATTRS.gid);
/* 1584 */         _setStat(paramString, sftpATTRS);
/*      */       } 
/*      */     } catch (Exception exception) {
/*      */       
/* 1588 */       if (exception instanceof SftpException) throw (SftpException)exception; 
/* 1589 */       if (exception instanceof Throwable)
/* 1590 */         throw new SftpException(4, "", exception); 
/* 1591 */       throw new SftpException(4, "");
/*      */     } 
/*      */   }
/*      */   
/*      */   public void chmod(int paramInt, String paramString) throws SftpException {
/*      */     try {
/* 1597 */       paramString = remoteAbsolutePath(paramString);
/*      */       
/* 1599 */       Vector vector = glob_remote(paramString);
/* 1600 */       int i = vector.size();
/* 1601 */       for (byte b = 0; b < i; b++) {
/* 1602 */         paramString = vector.elementAt(b);
/*      */         
/* 1604 */         SftpATTRS sftpATTRS = _stat(paramString);
/*      */         
/* 1606 */         sftpATTRS.setFLAGS(0);
/* 1607 */         sftpATTRS.setPERMISSIONS(paramInt);
/* 1608 */         _setStat(paramString, sftpATTRS);
/*      */       } 
/*      */     } catch (Exception exception) {
/*      */       
/* 1612 */       if (exception instanceof SftpException) throw (SftpException)exception; 
/* 1613 */       if (exception instanceof Throwable)
/* 1614 */         throw new SftpException(4, "", exception); 
/* 1615 */       throw new SftpException(4, "");
/*      */     } 
/*      */   }
/*      */   
/*      */   public void setMtime(String paramString, int paramInt) throws SftpException {
/*      */     try {
/* 1621 */       paramString = remoteAbsolutePath(paramString);
/*      */       
/* 1623 */       Vector vector = glob_remote(paramString);
/* 1624 */       int i = vector.size();
/* 1625 */       for (byte b = 0; b < i; b++) {
/* 1626 */         paramString = vector.elementAt(b);
/*      */         
/* 1628 */         SftpATTRS sftpATTRS = _stat(paramString);
/*      */         
/* 1630 */         sftpATTRS.setFLAGS(0);
/* 1631 */         sftpATTRS.setACMODTIME(sftpATTRS.getATime(), paramInt);
/* 1632 */         _setStat(paramString, sftpATTRS);
/*      */       } 
/*      */     } catch (Exception exception) {
/*      */       
/* 1636 */       if (exception instanceof SftpException) throw (SftpException)exception; 
/* 1637 */       if (exception instanceof Throwable)
/* 1638 */         throw new SftpException(4, "", exception); 
/* 1639 */       throw new SftpException(4, "");
/*      */     } 
/*      */   }
/*      */   
/*      */   public void rmdir(String paramString) throws SftpException {
/*      */     try {
/* 1645 */       paramString = remoteAbsolutePath(paramString);
/*      */       
/* 1647 */       Vector vector = glob_remote(paramString);
/* 1648 */       int i = vector.size();
/*      */       
/* 1650 */       Header header = new Header(this);
/*      */       
/* 1652 */       for (byte b = 0; b < i; b++) {
/* 1653 */         paramString = vector.elementAt(b);
/* 1654 */         sendRMDIR(Util.str2byte(paramString, this.fEncoding));
/*      */         
/* 1656 */         header = header(this.buf, header);
/* 1657 */         int j = header.length;
/* 1658 */         int k = header.type;
/*      */         
/* 1660 */         fill(this.buf, j);
/*      */         
/* 1662 */         if (k != 101) {
/* 1663 */           throw new SftpException(4, "");
/*      */         }
/*      */         
/* 1666 */         int m = this.buf.getInt();
/* 1667 */         if (m != 0) {
/* 1668 */           throwStatusError(this.buf, m);
/*      */         }
/*      */       } 
/*      */     } catch (Exception exception) {
/*      */       
/* 1673 */       if (exception instanceof SftpException) throw (SftpException)exception; 
/* 1674 */       if (exception instanceof Throwable)
/* 1675 */         throw new SftpException(4, "", exception); 
/* 1676 */       throw new SftpException(4, "");
/*      */     } 
/*      */   }
/*      */   
/*      */   public void mkdir(String paramString) throws SftpException {
/*      */     try {
/* 1682 */       paramString = remoteAbsolutePath(paramString);
/*      */       
/* 1684 */       sendMKDIR(Util.str2byte(paramString, this.fEncoding), (SftpATTRS)null);
/*      */       
/* 1686 */       Header header = new Header(this);
/* 1687 */       header = header(this.buf, header);
/* 1688 */       int i = header.length;
/* 1689 */       int j = header.type;
/*      */       
/* 1691 */       fill(this.buf, i);
/*      */       
/* 1693 */       if (j != 101) {
/* 1694 */         throw new SftpException(4, "");
/*      */       }
/*      */       
/* 1697 */       int k = this.buf.getInt();
/* 1698 */       if (k == 0)
/* 1699 */         return;  throwStatusError(this.buf, k);
/*      */     } catch (Exception exception) {
/*      */       
/* 1702 */       if (exception instanceof SftpException) throw (SftpException)exception; 
/* 1703 */       if (exception instanceof Throwable)
/* 1704 */         throw new SftpException(4, "", exception); 
/* 1705 */       throw new SftpException(4, "");
/*      */     } 
/*      */   }
/*      */   
/*      */   public SftpATTRS stat(String paramString) throws SftpException {
/*      */     try {
/* 1711 */       paramString = remoteAbsolutePath(paramString);
/*      */       
/* 1713 */       paramString = isUnique(paramString);
/*      */       
/* 1715 */       return _stat(paramString);
/*      */     } catch (Exception exception) {
/*      */       
/* 1718 */       if (exception instanceof SftpException) throw (SftpException)exception; 
/* 1719 */       if (exception instanceof Throwable)
/* 1720 */         throw new SftpException(4, "", exception); 
/* 1721 */       throw new SftpException(4, "");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private SftpATTRS _stat(byte[] paramArrayOfbyte) throws SftpException {
/*      */     try {
/* 1729 */       sendSTAT(paramArrayOfbyte);
/*      */       
/* 1731 */       Header header = new Header(this);
/* 1732 */       header = header(this.buf, header);
/* 1733 */       int i = header.length;
/* 1734 */       int j = header.type;
/*      */       
/* 1736 */       fill(this.buf, i);
/*      */       
/* 1738 */       if (j != 105) {
/* 1739 */         if (j == 101) {
/* 1740 */           int k = this.buf.getInt();
/* 1741 */           throwStatusError(this.buf, k);
/*      */         } 
/* 1743 */         throw new SftpException(4, "");
/*      */       } 
/* 1745 */       return SftpATTRS.getATTR(this.buf);
/*      */     }
/*      */     catch (Exception exception) {
/*      */       
/* 1749 */       if (exception instanceof SftpException) throw (SftpException)exception; 
/* 1750 */       if (exception instanceof Throwable)
/* 1751 */         throw new SftpException(4, "", exception); 
/* 1752 */       throw new SftpException(4, "");
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private SftpATTRS _stat(String paramString) throws SftpException {
/* 1758 */     return _stat(Util.str2byte(paramString, this.fEncoding));
/*      */   }
/*      */   
/*      */   public SftpATTRS lstat(String paramString) throws SftpException {
/*      */     try {
/* 1763 */       paramString = remoteAbsolutePath(paramString);
/*      */       
/* 1765 */       paramString = isUnique(paramString);
/*      */       
/* 1767 */       return _lstat(paramString);
/*      */     } catch (Exception exception) {
/*      */       
/* 1770 */       if (exception instanceof SftpException) throw (SftpException)exception; 
/* 1771 */       if (exception instanceof Throwable)
/* 1772 */         throw new SftpException(4, "", exception); 
/* 1773 */       throw new SftpException(4, "");
/*      */     } 
/*      */   }
/*      */   
/*      */   private SftpATTRS _lstat(String paramString) throws SftpException {
/*      */     try {
/* 1779 */       sendLSTAT(Util.str2byte(paramString, this.fEncoding));
/*      */       
/* 1781 */       Header header = new Header(this);
/* 1782 */       header = header(this.buf, header);
/* 1783 */       int i = header.length;
/* 1784 */       int j = header.type;
/*      */       
/* 1786 */       fill(this.buf, i);
/*      */       
/* 1788 */       if (j != 105) {
/* 1789 */         if (j == 101) {
/* 1790 */           int k = this.buf.getInt();
/* 1791 */           throwStatusError(this.buf, k);
/*      */         } 
/* 1793 */         throw new SftpException(4, "");
/*      */       } 
/* 1795 */       return SftpATTRS.getATTR(this.buf);
/*      */     }
/*      */     catch (Exception exception) {
/*      */       
/* 1799 */       if (exception instanceof SftpException) throw (SftpException)exception; 
/* 1800 */       if (exception instanceof Throwable)
/* 1801 */         throw new SftpException(4, "", exception); 
/* 1802 */       throw new SftpException(4, "");
/*      */     } 
/*      */   }
/*      */   
/*      */   private byte[] _realpath(String paramString) throws SftpException, IOException, Exception {
/* 1807 */     sendREALPATH(Util.str2byte(paramString, this.fEncoding));
/*      */     
/* 1809 */     Header header = new Header(this);
/* 1810 */     header = header(this.buf, header);
/* 1811 */     int i = header.length;
/* 1812 */     int j = header.type;
/*      */     
/* 1814 */     fill(this.buf, i);
/*      */     
/* 1816 */     if (j != 101 && j != 104) {
/* 1817 */       throw new SftpException(4, "");
/*      */     }
/*      */     
/* 1820 */     if (j == 101) {
/* 1821 */       int m = this.buf.getInt();
/* 1822 */       throwStatusError(this.buf, m);
/*      */     } 
/* 1824 */     int k = this.buf.getInt();
/*      */     
/* 1826 */     byte[] arrayOfByte = null;
/* 1827 */     while (k-- > 0) {
/* 1828 */       arrayOfByte = this.buf.getString();
/* 1829 */       if (this.server_version <= 3) {
/* 1830 */         byte[] arrayOfByte1 = this.buf.getString();
/*      */       }
/* 1832 */       SftpATTRS sftpATTRS = SftpATTRS.getATTR(this.buf);
/*      */     } 
/* 1834 */     return arrayOfByte;
/*      */   }
/*      */   
/*      */   public void setStat(String paramString, SftpATTRS paramSftpATTRS) throws SftpException {
/*      */     try {
/* 1839 */       paramString = remoteAbsolutePath(paramString);
/*      */       
/* 1841 */       Vector vector = glob_remote(paramString);
/* 1842 */       int i = vector.size();
/* 1843 */       for (byte b = 0; b < i; b++) {
/* 1844 */         paramString = vector.elementAt(b);
/* 1845 */         _setStat(paramString, paramSftpATTRS);
/*      */       } 
/*      */     } catch (Exception exception) {
/*      */       
/* 1849 */       if (exception instanceof SftpException) throw (SftpException)exception; 
/* 1850 */       if (exception instanceof Throwable)
/* 1851 */         throw new SftpException(4, "", exception); 
/* 1852 */       throw new SftpException(4, "");
/*      */     } 
/*      */   }
/*      */   private void _setStat(String paramString, SftpATTRS paramSftpATTRS) throws SftpException {
/*      */     try {
/* 1857 */       sendSETSTAT(Util.str2byte(paramString, this.fEncoding), paramSftpATTRS);
/*      */       
/* 1859 */       Header header = new Header(this);
/* 1860 */       header = header(this.buf, header);
/* 1861 */       int i = header.length;
/* 1862 */       int j = header.type;
/*      */       
/* 1864 */       fill(this.buf, i);
/*      */       
/* 1866 */       if (j != 101) {
/* 1867 */         throw new SftpException(4, "");
/*      */       }
/* 1869 */       int k = this.buf.getInt();
/* 1870 */       if (k != 0) {
/* 1871 */         throwStatusError(this.buf, k);
/*      */       }
/*      */     } catch (Exception exception) {
/*      */       
/* 1875 */       if (exception instanceof SftpException) throw (SftpException)exception; 
/* 1876 */       if (exception instanceof Throwable)
/* 1877 */         throw new SftpException(4, "", exception); 
/* 1878 */       throw new SftpException(4, "");
/*      */     } 
/*      */   }
/*      */   
/* 1882 */   public String pwd() throws SftpException { return getCwd(); }
/* 1883 */   public String lpwd() { return this.lcwd; } public String version() {
/* 1884 */     return this.version;
/*      */   } public String getHome() throws SftpException {
/* 1886 */     if (this.home == null) {
/*      */       try {
/* 1888 */         byte[] arrayOfByte = _realpath("");
/* 1889 */         this.home = Util.byte2str(arrayOfByte, this.fEncoding);
/*      */       } catch (Exception exception) {
/*      */         
/* 1892 */         if (exception instanceof SftpException) throw (SftpException)exception; 
/* 1893 */         if (exception instanceof Throwable)
/* 1894 */           throw new SftpException(4, "", exception); 
/* 1895 */         throw new SftpException(4, "");
/*      */       } 
/*      */     }
/* 1898 */     return this.home;
/*      */   }
/*      */   
/*      */   private String getCwd() throws SftpException {
/* 1902 */     if (this.cwd == null)
/* 1903 */       this.cwd = getHome(); 
/* 1904 */     return this.cwd;
/*      */   }
/*      */   
/*      */   private void setCwd(String paramString) {
/* 1908 */     this.cwd = paramString;
/*      */   }
/*      */   
/*      */   private void read(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException, SftpException {
/* 1912 */     int i = 0;
/* 1913 */     while (paramInt2 > 0) {
/* 1914 */       i = this.io_in.read(paramArrayOfbyte, paramInt1, paramInt2);
/* 1915 */       if (i <= 0) {
/* 1916 */         throw new SftpException(4, "");
/*      */       }
/* 1918 */       paramInt1 += i;
/* 1919 */       paramInt2 -= i;
/*      */     } 
/*      */   }
/*      */   
/*      */   private boolean checkStatus(int[] paramArrayOfint, Header paramHeader) throws IOException, SftpException {
/* 1924 */     paramHeader = header(this.buf, paramHeader);
/* 1925 */     int i = paramHeader.length;
/* 1926 */     int j = paramHeader.type;
/* 1927 */     if (paramArrayOfint != null) {
/* 1928 */       paramArrayOfint[0] = paramHeader.rid;
/*      */     }
/* 1930 */     fill(this.buf, i);
/*      */     
/* 1932 */     if (j != 101) {
/* 1933 */       throw new SftpException(4, "");
/*      */     }
/* 1935 */     int k = this.buf.getInt();
/* 1936 */     if (k != 0) {
/* 1937 */       throwStatusError(this.buf, k);
/*      */     }
/* 1939 */     return true;
/*      */   }
/*      */   private boolean _sendCLOSE(byte[] paramArrayOfbyte, Header paramHeader) throws Exception {
/* 1942 */     sendCLOSE(paramArrayOfbyte);
/* 1943 */     return checkStatus((int[])null, paramHeader);
/*      */   }
/*      */   
/*      */   private void sendINIT() throws Exception {
/* 1947 */     this.packet.reset();
/* 1948 */     putHEAD((byte)1, 5);
/* 1949 */     this.buf.putInt(3);
/* 1950 */     getSession().write(this.packet, this, 9);
/*      */   }
/*      */   
/*      */   private void sendREALPATH(byte[] paramArrayOfbyte) throws Exception {
/* 1954 */     sendPacketPath((byte)16, paramArrayOfbyte);
/*      */   }
/*      */   private void sendSTAT(byte[] paramArrayOfbyte) throws Exception {
/* 1957 */     sendPacketPath((byte)17, paramArrayOfbyte);
/*      */   }
/*      */   private void sendLSTAT(byte[] paramArrayOfbyte) throws Exception {
/* 1960 */     sendPacketPath((byte)7, paramArrayOfbyte);
/*      */   }
/*      */   private void sendFSTAT(byte[] paramArrayOfbyte) throws Exception {
/* 1963 */     sendPacketPath((byte)8, paramArrayOfbyte);
/*      */   }
/*      */   private void sendSETSTAT(byte[] paramArrayOfbyte, SftpATTRS paramSftpATTRS) throws Exception {
/* 1966 */     this.packet.reset();
/* 1967 */     putHEAD((byte)9, 9 + paramArrayOfbyte.length + paramSftpATTRS.length());
/* 1968 */     this.buf.putInt(this.seq++);
/* 1969 */     this.buf.putString(paramArrayOfbyte);
/* 1970 */     paramSftpATTRS.dump(this.buf);
/* 1971 */     getSession().write(this.packet, this, 9 + paramArrayOfbyte.length + paramSftpATTRS.length() + 4);
/*      */   }
/*      */   private void sendREMOVE(byte[] paramArrayOfbyte) throws Exception {
/* 1974 */     sendPacketPath((byte)13, paramArrayOfbyte);
/*      */   }
/*      */   private void sendMKDIR(byte[] paramArrayOfbyte, SftpATTRS paramSftpATTRS) throws Exception {
/* 1977 */     this.packet.reset();
/* 1978 */     putHEAD((byte)14, 9 + paramArrayOfbyte.length + ((paramSftpATTRS != null) ? paramSftpATTRS.length() : 4));
/* 1979 */     this.buf.putInt(this.seq++);
/* 1980 */     this.buf.putString(paramArrayOfbyte);
/* 1981 */     if (paramSftpATTRS != null) { paramSftpATTRS.dump(this.buf); }
/* 1982 */     else { this.buf.putInt(0); }
/* 1983 */      getSession().write(this.packet, this, 9 + paramArrayOfbyte.length + ((paramSftpATTRS != null) ? paramSftpATTRS.length() : 4) + 4);
/*      */   }
/*      */   private void sendRMDIR(byte[] paramArrayOfbyte) throws Exception {
/* 1986 */     sendPacketPath((byte)15, paramArrayOfbyte);
/*      */   }
/*      */   private void sendSYMLINK(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) throws Exception {
/* 1989 */     sendPacketPath((byte)20, paramArrayOfbyte1, paramArrayOfbyte2);
/*      */   }
/*      */   private void sendREADLINK(byte[] paramArrayOfbyte) throws Exception {
/* 1992 */     sendPacketPath((byte)19, paramArrayOfbyte);
/*      */   }
/*      */   private void sendOPENDIR(byte[] paramArrayOfbyte) throws Exception {
/* 1995 */     sendPacketPath((byte)11, paramArrayOfbyte);
/*      */   }
/*      */   private void sendREADDIR(byte[] paramArrayOfbyte) throws Exception {
/* 1998 */     sendPacketPath((byte)12, paramArrayOfbyte);
/*      */   }
/*      */   private void sendRENAME(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) throws Exception {
/* 2001 */     sendPacketPath((byte)18, paramArrayOfbyte1, paramArrayOfbyte2);
/*      */   }
/*      */   private void sendCLOSE(byte[] paramArrayOfbyte) throws Exception {
/* 2004 */     sendPacketPath((byte)4, paramArrayOfbyte);
/*      */   }
/*      */   private void sendOPENR(byte[] paramArrayOfbyte) throws Exception {
/* 2007 */     sendOPEN(paramArrayOfbyte, 1);
/*      */   }
/*      */   private void sendOPENW(byte[] paramArrayOfbyte) throws Exception {
/* 2010 */     sendOPEN(paramArrayOfbyte, 26);
/*      */   }
/*      */   private void sendOPENA(byte[] paramArrayOfbyte) throws Exception {
/* 2013 */     sendOPEN(paramArrayOfbyte, 10);
/*      */   }
/*      */   private void sendOPEN(byte[] paramArrayOfbyte, int paramInt) throws Exception {
/* 2016 */     this.packet.reset();
/* 2017 */     putHEAD((byte)3, 17 + paramArrayOfbyte.length);
/* 2018 */     this.buf.putInt(this.seq++);
/* 2019 */     this.buf.putString(paramArrayOfbyte);
/* 2020 */     this.buf.putInt(paramInt);
/* 2021 */     this.buf.putInt(0);
/* 2022 */     getSession().write(this.packet, this, 17 + paramArrayOfbyte.length + 4);
/*      */   }
/*      */   private void sendPacketPath(byte paramByte, byte[] paramArrayOfbyte) throws Exception {
/* 2025 */     this.packet.reset();
/* 2026 */     putHEAD(paramByte, 9 + paramArrayOfbyte.length);
/* 2027 */     this.buf.putInt(this.seq++);
/* 2028 */     this.buf.putString(paramArrayOfbyte);
/* 2029 */     getSession().write(this.packet, this, 9 + paramArrayOfbyte.length + 4);
/*      */   }
/*      */   private void sendPacketPath(byte paramByte, byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) throws Exception {
/* 2032 */     this.packet.reset();
/* 2033 */     putHEAD(paramByte, 13 + paramArrayOfbyte1.length + paramArrayOfbyte2.length);
/* 2034 */     this.buf.putInt(this.seq++);
/* 2035 */     this.buf.putString(paramArrayOfbyte1);
/* 2036 */     this.buf.putString(paramArrayOfbyte2);
/* 2037 */     getSession().write(this.packet, this, 13 + paramArrayOfbyte1.length + paramArrayOfbyte2.length + 4);
/*      */   }
/*      */ 
/*      */   
/*      */   private int sendWRITE(byte[] paramArrayOfbyte1, long paramLong, byte[] paramArrayOfbyte2, int paramInt1, int paramInt2) throws Exception {
/* 2042 */     int i = paramInt2;
/* 2043 */     this.packet.reset();
/* 2044 */     if (this.buf.buffer.length < this.buf.index + 13 + 21 + paramArrayOfbyte1.length + paramInt2 + 32 + 20)
/*      */     {
/*      */       
/* 2047 */       i = this.buf.buffer.length - this.buf.index + 13 + 21 + paramArrayOfbyte1.length + 32 + 20;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2053 */     putHEAD((byte)6, 21 + paramArrayOfbyte1.length + i);
/* 2054 */     this.buf.putInt(this.seq++);
/* 2055 */     this.buf.putString(paramArrayOfbyte1);
/* 2056 */     this.buf.putLong(paramLong);
/* 2057 */     if (this.buf.buffer != paramArrayOfbyte2) {
/* 2058 */       this.buf.putString(paramArrayOfbyte2, paramInt1, i);
/*      */     } else {
/*      */       
/* 2061 */       this.buf.putInt(i);
/* 2062 */       this.buf.skip(i);
/*      */     } 
/* 2064 */     getSession().write(this.packet, this, 21 + paramArrayOfbyte1.length + i + 4);
/* 2065 */     return i;
/*      */   }
/*      */   
/*      */   private void sendREAD(byte[] paramArrayOfbyte, long paramLong, int paramInt) throws Exception {
/* 2069 */     this.packet.reset();
/* 2070 */     putHEAD((byte)5, 21 + paramArrayOfbyte.length);
/* 2071 */     this.buf.putInt(this.seq++);
/* 2072 */     this.buf.putString(paramArrayOfbyte);
/* 2073 */     this.buf.putLong(paramLong);
/* 2074 */     this.buf.putInt(paramInt);
/* 2075 */     getSession().write(this.packet, this, 21 + paramArrayOfbyte.length + 4);
/*      */   }
/*      */   
/*      */   private void putHEAD(byte paramByte, int paramInt) throws Exception {
/* 2079 */     this.buf.putByte((byte)94);
/* 2080 */     this.buf.putInt(this.recipient);
/* 2081 */     this.buf.putInt(paramInt + 4);
/* 2082 */     this.buf.putInt(paramInt);
/* 2083 */     this.buf.putByte(paramByte);
/*      */   }
/*      */ 
/*      */   
/*      */   private Vector glob_remote(String paramString) throws Exception {
/* 2088 */     Vector vector = new Vector();
/* 2089 */     int i = 0;
/*      */     
/* 2091 */     int j = paramString.lastIndexOf('/');
/* 2092 */     if (j < 0) {
/* 2093 */       vector.addElement(Util.unquote(paramString));
/* 2094 */       return vector;
/*      */     } 
/*      */     
/* 2097 */     String str1 = paramString.substring(0, (j == 0) ? 1 : j);
/* 2098 */     String str2 = paramString.substring(j + 1);
/*      */     
/* 2100 */     str1 = Util.unquote(str1);
/*      */     
/* 2102 */     byte[] arrayOfByte1 = null;
/* 2103 */     byte[][] arrayOfByte = new byte[1][];
/* 2104 */     boolean bool = isPattern(str2, arrayOfByte);
/*      */     
/* 2106 */     if (!bool) {
/* 2107 */       if (str1.length() != 1)
/* 2108 */         str1 = str1 + "/"; 
/* 2109 */       vector.addElement(str1 + Util.unquote(str2));
/* 2110 */       return vector;
/*      */     } 
/*      */     
/* 2113 */     arrayOfByte1 = arrayOfByte[0];
/*      */     
/* 2115 */     sendOPENDIR(Util.str2byte(str1, this.fEncoding));
/*      */     
/* 2117 */     Header header = new Header(this);
/* 2118 */     header = header(this.buf, header);
/* 2119 */     int k = header.length;
/* 2120 */     int m = header.type;
/*      */     
/* 2122 */     fill(this.buf, k);
/*      */     
/* 2124 */     if (m != 101 && m != 102) {
/* 2125 */       throw new SftpException(4, "");
/*      */     }
/* 2127 */     if (m == 101) {
/* 2128 */       i = this.buf.getInt();
/* 2129 */       throwStatusError(this.buf, i);
/*      */     } 
/*      */     
/* 2132 */     byte[] arrayOfByte2 = this.buf.getString();
/* 2133 */     String str3 = null;
/*      */     
/*      */     while (true) {
/* 2136 */       sendREADDIR(arrayOfByte2);
/* 2137 */       header = header(this.buf, header);
/* 2138 */       k = header.length;
/* 2139 */       m = header.type;
/*      */       
/* 2141 */       if (m != 101 && m != 104) {
/* 2142 */         throw new SftpException(4, "");
/*      */       }
/* 2144 */       if (m == 101) {
/* 2145 */         fill(this.buf, k);
/*      */         
/*      */         break;
/*      */       } 
/* 2149 */       this.buf.rewind();
/* 2150 */       fill(this.buf.buffer, 0, 4); k -= 4;
/* 2151 */       int n = this.buf.getInt();
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2156 */       this.buf.reset();
/* 2157 */       while (n > 0) {
/* 2158 */         if (k > 0) {
/* 2159 */           this.buf.shift();
/* 2160 */           int i1 = (this.buf.buffer.length > this.buf.index + k) ? k : (this.buf.buffer.length - this.buf.index);
/* 2161 */           i = this.io_in.read(this.buf.buffer, this.buf.index, i1);
/* 2162 */           if (i <= 0)
/* 2163 */             break;  this.buf.index += i;
/* 2164 */           k -= i;
/*      */         } 
/*      */         
/* 2167 */         byte[] arrayOfByte3 = this.buf.getString();
/*      */         
/* 2169 */         if (this.server_version <= 3) {
/* 2170 */           byte[] arrayOfByte5 = this.buf.getString();
/*      */         }
/* 2172 */         SftpATTRS sftpATTRS = SftpATTRS.getATTR(this.buf);
/*      */         
/* 2174 */         byte[] arrayOfByte4 = arrayOfByte3;
/* 2175 */         String str = null;
/* 2176 */         boolean bool1 = false;
/*      */         
/* 2178 */         if (!this.fEncoding_is_utf8) {
/* 2179 */           str = Util.byte2str(arrayOfByte3, this.fEncoding);
/* 2180 */           arrayOfByte4 = Util.str2byte(str, "UTF-8");
/*      */         } 
/* 2182 */         bool1 = Util.glob(arrayOfByte1, arrayOfByte4);
/*      */         
/* 2184 */         if (bool1) {
/* 2185 */           if (str == null) {
/* 2186 */             str = Util.byte2str(arrayOfByte3, this.fEncoding);
/*      */           }
/* 2188 */           if (str3 == null) {
/* 2189 */             str3 = str1;
/* 2190 */             if (!str3.endsWith("/")) {
/* 2191 */               str3 = str3 + "/";
/*      */             }
/*      */           } 
/* 2194 */           vector.addElement(str3 + str);
/*      */         } 
/* 2196 */         n--;
/*      */       } 
/*      */     } 
/* 2199 */     if (_sendCLOSE(arrayOfByte2, header))
/* 2200 */       return vector; 
/* 2201 */     return null;
/*      */   }
/*      */   
/*      */   private boolean isPattern(byte[] paramArrayOfbyte) {
/* 2205 */     int i = paramArrayOfbyte.length - 1;
/*      */ 
/*      */ 
/*      */     
/* 2209 */     i--;
/* 2210 */     while (i >= 0 && ((paramArrayOfbyte[i] != 42 && paramArrayOfbyte[i] != 63) || (i > 0 && paramArrayOfbyte[i - 1] == 92 && (i <= 0 || paramArrayOfbyte[i - 1] != 92))))
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 2218 */       i--;
/*      */     }
/*      */     
/* 2221 */     return (i >= 0);
/*      */   }
/*      */   
/*      */   private Vector glob_local(String paramString) throws Exception {
/*      */     byte[] arrayOfByte2;
/* 2226 */     Vector vector = new Vector();
/* 2227 */     byte[] arrayOfByte1 = Util.str2byte(paramString, "UTF-8");
/* 2228 */     int i = arrayOfByte1.length - 1;
/* 2229 */     while (i >= 0) {
/* 2230 */       if (arrayOfByte1[i] != 42 && arrayOfByte1[i] != 63) {
/* 2231 */         i--;
/*      */         continue;
/*      */       } 
/* 2234 */       if (!fs_is_bs && i > 0 && arrayOfByte1[i - 1] == 92) {
/*      */         
/* 2236 */         i--;
/* 2237 */         if (i > 0 && arrayOfByte1[i - 1] == 92) {
/* 2238 */           i--;
/* 2239 */           i--;
/*      */           
/*      */           continue;
/*      */         } 
/*      */       } 
/*      */       break;
/*      */     } 
/* 2246 */     if (i < 0) { vector.addElement(fs_is_bs ? paramString : Util.unquote(paramString)); return vector; }
/*      */     
/* 2248 */     while (i >= 0 && 
/* 2249 */       arrayOfByte1[i] != file_separatorc && (!fs_is_bs || arrayOfByte1[i] != 47))
/*      */     {
/*      */ 
/*      */       
/* 2253 */       i--;
/*      */     }
/*      */     
/* 2256 */     if (i < 0) { vector.addElement(fs_is_bs ? paramString : Util.unquote(paramString)); return vector; }
/*      */ 
/*      */     
/* 2259 */     if (i == 0) { arrayOfByte2 = new byte[] { (byte)file_separatorc }; }
/*      */     else
/* 2261 */     { arrayOfByte2 = new byte[i];
/* 2262 */       System.arraycopy(arrayOfByte1, 0, arrayOfByte2, 0, i); }
/*      */ 
/*      */     
/* 2265 */     byte[] arrayOfByte3 = new byte[arrayOfByte1.length - i - 1];
/* 2266 */     System.arraycopy(arrayOfByte1, i + 1, arrayOfByte3, 0, arrayOfByte3.length);
/*      */ 
/*      */     
/*      */     try {
/* 2270 */       String[] arrayOfString = (new File(Util.byte2str(arrayOfByte2, "UTF-8"))).list();
/* 2271 */       String str = Util.byte2str(arrayOfByte2) + file_separator;
/* 2272 */       for (byte b = 0; b < arrayOfString.length; b++)
/*      */       {
/* 2274 */         if (Util.glob(arrayOfByte3, Util.str2byte(arrayOfString[b], "UTF-8"))) {
/* 2275 */           vector.addElement(str + arrayOfString[b]);
/*      */         }
/*      */       }
/*      */     
/* 2279 */     } catch (Exception exception) {}
/*      */     
/* 2281 */     return vector;
/*      */   }
/*      */   
/*      */   private void throwStatusError(Buffer paramBuffer, int paramInt) throws SftpException {
/* 2285 */     if (this.server_version >= 3 && paramBuffer.getLength() >= 4) {
/*      */       
/* 2287 */       byte[] arrayOfByte = paramBuffer.getString();
/*      */       
/* 2289 */       throw new SftpException(paramInt, Util.byte2str(arrayOfByte, "UTF-8"));
/*      */     } 
/*      */     
/* 2292 */     throw new SftpException(paramInt, "Failure");
/*      */   }
/*      */ 
/*      */   
/*      */   private static boolean isLocalAbsolutePath(String paramString) {
/* 2297 */     return (new File(paramString)).isAbsolute();
/*      */   }
/*      */   
/*      */   public void disconnect() {
/* 2301 */     super.disconnect();
/*      */   }
/*      */   
/*      */   private boolean isPattern(String paramString, byte[][] paramArrayOfbyte) {
/* 2305 */     byte[] arrayOfByte = Util.str2byte(paramString, "UTF-8");
/* 2306 */     if (paramArrayOfbyte != null)
/* 2307 */       paramArrayOfbyte[0] = arrayOfByte; 
/* 2308 */     return isPattern(arrayOfByte);
/*      */   }
/*      */   
/*      */   private boolean isPattern(String paramString) {
/* 2312 */     return isPattern(paramString, (byte[][])null);
/*      */   }
/*      */   
/*      */   private void fill(Buffer paramBuffer, int paramInt) throws IOException {
/* 2316 */     paramBuffer.reset();
/* 2317 */     fill(paramBuffer.buffer, 0, paramInt);
/* 2318 */     paramBuffer.skip(paramInt);
/*      */   }
/*      */   
/*      */   private int fill(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException {
/* 2322 */     int i = 0;
/* 2323 */     int j = paramInt1;
/* 2324 */     while (paramInt2 > 0) {
/* 2325 */       i = this.io_in.read(paramArrayOfbyte, paramInt1, paramInt2);
/* 2326 */       if (i <= 0) {
/* 2327 */         throw new IOException("inputstream is closed");
/*      */       }
/*      */       
/* 2330 */       paramInt1 += i;
/* 2331 */       paramInt2 -= i;
/*      */     } 
/* 2333 */     return paramInt1 - j;
/*      */   }
/*      */   private void skip(long paramLong) throws IOException {
/* 2336 */     while (paramLong > 0L) {
/* 2337 */       long l = this.io_in.skip(paramLong);
/* 2338 */       if (l <= 0L)
/*      */         break; 
/* 2340 */       paramLong -= l;
/*      */     } 
/*      */   } class Header { int length; int type;
/*      */     Header(ChannelSftp this$0) {
/* 2344 */       this.this$0 = this$0;
/*      */     }
/*      */     int rid;
/*      */     private final ChannelSftp this$0; }
/*      */   
/*      */   private Header header(Buffer paramBuffer, Header paramHeader) throws IOException {
/* 2350 */     paramBuffer.rewind();
/* 2351 */     int i = fill(paramBuffer.buffer, 0, 9);
/* 2352 */     paramHeader.length = paramBuffer.getInt() - 5;
/* 2353 */     paramHeader.type = paramBuffer.getByte() & 0xFF;
/* 2354 */     paramHeader.rid = paramBuffer.getInt();
/* 2355 */     return paramHeader;
/*      */   }
/*      */   
/*      */   private String remoteAbsolutePath(String paramString) throws SftpException {
/* 2359 */     if (paramString.charAt(0) == '/') return paramString; 
/* 2360 */     String str = getCwd();
/* 2361 */     if (str.endsWith("/")) return str + paramString; 
/* 2362 */     return str + "/" + paramString;
/*      */   }
/*      */   
/*      */   private String localAbsolutePath(String paramString) {
/* 2366 */     if (isLocalAbsolutePath(paramString)) return paramString; 
/* 2367 */     if (this.lcwd.endsWith(file_separator)) return this.lcwd + paramString; 
/* 2368 */     return this.lcwd + file_separator + paramString;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String isUnique(String paramString) throws SftpException, Exception {
/* 2378 */     Vector vector = glob_remote(paramString);
/* 2379 */     if (vector.size() != 1) {
/* 2380 */       throw new SftpException(4, paramString + " is not unique: " + vector.toString());
/*      */     }
/* 2382 */     return vector.elementAt(0);
/*      */   }
/*      */   
/*      */   public int getServerVersion() throws SftpException {
/* 2386 */     if (!isConnected()) {
/* 2387 */       throw new SftpException(4, "The channel is not connected.");
/*      */     }
/* 2389 */     return this.server_version;
/*      */   }
/*      */   
/*      */   public void setFilenameEncoding(String paramString) throws SftpException {
/* 2393 */     int i = getServerVersion();
/* 2394 */     if (i > 3 && !paramString.equals("UTF-8"))
/*      */     {
/* 2396 */       throw new SftpException(4, "The encoding can not be changed for this sftp server.");
/*      */     }
/*      */     
/* 2399 */     if (paramString.equals("UTF-8")) {
/* 2400 */       paramString = "UTF-8";
/*      */     }
/* 2402 */     this.fEncoding = paramString;
/* 2403 */     this.fEncoding_is_utf8 = this.fEncoding.equals("UTF-8");
/*      */   }
/*      */   
/*      */   public String getExtension(String paramString) {
/* 2407 */     if (this.extensions == null)
/* 2408 */       return null; 
/* 2409 */     return (String)this.extensions.get(paramString);
/*      */   }
/*      */   
/*      */   public String realpath(String paramString) throws SftpException {
/*      */     try {
/* 2414 */       byte[] arrayOfByte = _realpath(remoteAbsolutePath(paramString));
/* 2415 */       return Util.byte2str(arrayOfByte, this.fEncoding);
/*      */     } catch (Exception exception) {
/*      */       
/* 2418 */       if (exception instanceof SftpException) throw (SftpException)exception; 
/* 2419 */       if (exception instanceof Throwable)
/* 2420 */         throw new SftpException(4, "", exception); 
/* 2421 */       throw new SftpException(4, "");
/*      */     } 
/*      */   }
/*      */   public class LsEntry implements Comparable { private String filename; private String longname;
/*      */     private SftpATTRS attrs;
/*      */     private final ChannelSftp this$0;
/*      */     
/*      */     LsEntry(ChannelSftp this$0, String param1String1, String param1String2, SftpATTRS param1SftpATTRS) {
/* 2429 */       this.this$0 = this$0;
/* 2430 */       setFilename(param1String1);
/* 2431 */       setLongname(param1String2);
/* 2432 */       setAttrs(param1SftpATTRS);
/*      */     }
/* 2434 */     public String getFilename() { return this.filename; }
/* 2435 */     void setFilename(String param1String) { this.filename = param1String; }
/* 2436 */     public String getLongname() { return this.longname; }
/* 2437 */     void setLongname(String param1String) { this.longname = param1String; }
/* 2438 */     public SftpATTRS getAttrs() { return this.attrs; }
/* 2439 */     void setAttrs(SftpATTRS param1SftpATTRS) { this.attrs = param1SftpATTRS; } public String toString() {
/* 2440 */       return this.longname;
/*      */     } public int compareTo(Object param1Object) throws ClassCastException {
/* 2442 */       if (param1Object instanceof LsEntry) {
/* 2443 */         return this.filename.compareTo(((LsEntry)param1Object).getFilename());
/*      */       }
/* 2445 */       throw new ClassCastException("a decendent of LsEntry must be given.");
/*      */     } }
/*      */ 
/*      */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/ChannelSftp.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */