/*     */ package com.jcraft.jsch;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PipedInputStream;
/*     */ import java.io.PipedOutputStream;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class Channel
/*     */   implements Runnable
/*     */ {
/*     */   static final int SSH_MSG_CHANNEL_OPEN_CONFIRMATION = 91;
/*     */   static final int SSH_MSG_CHANNEL_OPEN_FAILURE = 92;
/*     */   static final int SSH_MSG_CHANNEL_WINDOW_ADJUST = 93;
/*     */   static final int SSH_OPEN_ADMINISTRATIVELY_PROHIBITED = 1;
/*     */   static final int SSH_OPEN_CONNECT_FAILED = 2;
/*     */   static final int SSH_OPEN_UNKNOWN_CHANNEL_TYPE = 3;
/*     */   static final int SSH_OPEN_RESOURCE_SHORTAGE = 4;
/*  50 */   static int index = 0;
/*  51 */   private static Vector pool = new Vector(); int id;
/*     */   static Channel getChannel(String paramString) {
/*  53 */     if (paramString.equals("session")) {
/*  54 */       return new ChannelSession();
/*     */     }
/*  56 */     if (paramString.equals("shell")) {
/*  57 */       return new ChannelShell();
/*     */     }
/*  59 */     if (paramString.equals("exec")) {
/*  60 */       return new ChannelExec();
/*     */     }
/*  62 */     if (paramString.equals("x11")) {
/*  63 */       return new ChannelX11();
/*     */     }
/*  65 */     if (paramString.equals("auth-agent@openssh.com")) {
/*  66 */       return new ChannelAgentForwarding();
/*     */     }
/*  68 */     if (paramString.equals("direct-tcpip")) {
/*  69 */       return new ChannelDirectTCPIP();
/*     */     }
/*  71 */     if (paramString.equals("forwarded-tcpip")) {
/*  72 */       return new ChannelForwardedTCPIP();
/*     */     }
/*  74 */     if (paramString.equals("sftp")) {
/*  75 */       return new ChannelSftp();
/*     */     }
/*  77 */     if (paramString.equals("subsystem")) {
/*  78 */       return new ChannelSubsystem();
/*     */     }
/*  80 */     return null;
/*     */   }
/*     */   static Channel getChannel(int paramInt, Session paramSession) {
/*  83 */     synchronized (pool) {
/*  84 */       for (byte b = 0; b < pool.size(); b++) {
/*  85 */         Channel channel = pool.elementAt(b);
/*  86 */         if (channel.id == paramInt && channel.session == paramSession) return channel; 
/*     */       } 
/*     */     } 
/*  89 */     return null;
/*     */   }
/*     */   static void del(Channel paramChannel) {
/*  92 */     synchronized (pool) {
/*  93 */       pool.removeElement(paramChannel);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*  98 */   int recipient = -1;
/*  99 */   byte[] type = "foo".getBytes();
/* 100 */   int lwsize_max = 1048576;
/*     */   
/* 102 */   int lwsize = this.lwsize_max;
/* 103 */   int lmpsize = 16384;
/*     */ 
/*     */   
/* 106 */   int rwsize = 0;
/* 107 */   int rmpsize = 0;
/*     */   
/* 109 */   IO io = null;
/* 110 */   Thread thread = null;
/*     */   
/*     */   boolean eof_local = false;
/*     */   
/*     */   boolean eof_remote = false;
/*     */   
/*     */   boolean close = false;
/*     */   boolean connected = false;
/* 118 */   int exitstatus = -1;
/*     */   
/* 120 */   int reply = 0;
/* 121 */   int connectTimeout = 0;
/*     */   
/*     */   private Session session;
/*     */   
/* 125 */   int notifyme = 0;
/*     */   
/*     */   Channel() {
/* 128 */     synchronized (pool) {
/* 129 */       this.id = index++;
/* 130 */       pool.addElement(this);
/*     */     } 
/*     */   }
/*     */   void setRecipient(int paramInt) {
/* 134 */     this.recipient = paramInt;
/*     */   }
/*     */   int getRecipient() {
/* 137 */     return this.recipient;
/*     */   }
/*     */ 
/*     */   
/*     */   void init() throws JSchException {}
/*     */   
/*     */   public void connect() throws JSchException {
/* 144 */     connect(0);
/*     */   }
/*     */   
/*     */   public void connect(int paramInt) throws JSchException {
/* 148 */     Session session = getSession();
/* 149 */     if (!session.isConnected()) {
/* 150 */       throw new JSchException("session is down");
/*     */     }
/* 152 */     this.connectTimeout = paramInt;
/*     */     try {
/* 154 */       Buffer buffer = new Buffer(100);
/* 155 */       Packet packet = new Packet(buffer);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 162 */       packet.reset();
/* 163 */       buffer.putByte((byte)90);
/* 164 */       buffer.putString(this.type);
/* 165 */       buffer.putInt(this.id);
/* 166 */       buffer.putInt(this.lwsize);
/* 167 */       buffer.putInt(this.lmpsize);
/* 168 */       session.write(packet);
/* 169 */       char c = 'Ϩ';
/* 170 */       long l1 = System.currentTimeMillis();
/* 171 */       long l2 = paramInt;
/*     */ 
/*     */       
/* 174 */       while (getRecipient() == -1 && session.isConnected() && c > '\000') {
/* 175 */         if (l2 > 0L && 
/* 176 */           System.currentTimeMillis() - l1 > l2) {
/* 177 */           c = Character.MIN_VALUE;
/*     */           continue;
/*     */         } 
/*     */         
/* 181 */         try { Thread.sleep(50L); } catch (Exception exception) {}
/* 182 */         c--;
/*     */       } 
/* 184 */       if (!session.isConnected()) {
/* 185 */         throw new JSchException("session is down");
/*     */       }
/* 187 */       if (c == '\000') {
/* 188 */         throw new JSchException("channel is not opened.");
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 196 */       if (isClosed()) {
/* 197 */         throw new JSchException("channel is not opened.");
/*     */       }
/* 199 */       this.connected = true;
/* 200 */       start();
/*     */     } catch (Exception exception) {
/*     */       
/* 203 */       this.connected = false;
/* 204 */       if (exception instanceof JSchException)
/* 205 */         throw (JSchException)exception; 
/* 206 */       throw new JSchException(exception.toString(), exception);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setXForwarding(boolean paramBoolean) {}
/*     */   
/*     */   public void start() throws JSchException {}
/*     */   
/*     */   public boolean isEOF() {
/* 215 */     return this.eof_remote;
/*     */   }
/*     */   void getData(Buffer paramBuffer) {
/* 218 */     setRecipient(paramBuffer.getInt());
/* 219 */     setRemoteWindowSize(paramBuffer.getInt());
/* 220 */     setRemotePacketSize(paramBuffer.getInt());
/*     */   }
/*     */   
/*     */   public void setInputStream(InputStream paramInputStream) {
/* 224 */     this.io.setInputStream(paramInputStream, false);
/*     */   }
/*     */   public void setInputStream(InputStream paramInputStream, boolean paramBoolean) {
/* 227 */     this.io.setInputStream(paramInputStream, paramBoolean);
/*     */   }
/*     */   public void setOutputStream(OutputStream paramOutputStream) {
/* 230 */     this.io.setOutputStream(paramOutputStream, false);
/*     */   }
/*     */   public void setOutputStream(OutputStream paramOutputStream, boolean paramBoolean) {
/* 233 */     this.io.setOutputStream(paramOutputStream, paramBoolean);
/*     */   }
/*     */   public void setExtOutputStream(OutputStream paramOutputStream) {
/* 236 */     this.io.setExtOutputStream(paramOutputStream, false);
/*     */   }
/*     */   public void setExtOutputStream(OutputStream paramOutputStream, boolean paramBoolean) {
/* 239 */     this.io.setExtOutputStream(paramOutputStream, paramBoolean);
/*     */   }
/*     */   public InputStream getInputStream() throws IOException {
/* 242 */     MyPipedInputStream myPipedInputStream = new MyPipedInputStream(this, 32768);
/*     */ 
/*     */ 
/*     */     
/* 246 */     this.io.setOutputStream(new PassiveOutputStream(this, myPipedInputStream), false);
/* 247 */     return myPipedInputStream;
/*     */   }
/*     */   public InputStream getExtInputStream() throws IOException {
/* 250 */     MyPipedInputStream myPipedInputStream = new MyPipedInputStream(this, 32768);
/*     */ 
/*     */ 
/*     */     
/* 254 */     this.io.setExtOutputStream(new PassiveOutputStream(this, myPipedInputStream), false);
/* 255 */     return myPipedInputStream;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public OutputStream getOutputStream() throws IOException {
/* 266 */     Channel channel = this;
/* 267 */     return new OutputStream(this, channel) {
/*     */         private int dataLen;
/*     */         private Buffer buffer;
/*     */         private Packet packet;
/*     */         
/*     */         private synchronized void init() throws IOException {
/* 273 */           this.buffer = new Buffer(this.this$0.rmpsize);
/* 274 */           this.packet = new Packet(this.buffer);
/*     */           
/* 276 */           byte[] arrayOfByte = this.buffer.buffer;
/* 277 */           if (arrayOfByte.length - 14 - 32 - 20 <= 0) {
/* 278 */             this.buffer = null;
/* 279 */             this.packet = null;
/* 280 */             throw new IOException("failed to initialize the channel.");
/*     */           } 
/*     */         }
/*     */         private boolean closed; byte[] b; private final Channel val$channel; private final Channel this$0;
/*     */         
/*     */         public void write(int param1Int) throws IOException {
/* 286 */           this.b[0] = (byte)param1Int;
/* 287 */           write(this.b, 0, 1);
/*     */         }
/*     */         public void write(byte[] param1ArrayOfbyte, int param1Int1, int param1Int2) throws IOException {
/* 290 */           if (this.packet == null) {
/* 291 */             init();
/*     */           }
/*     */           
/* 294 */           if (this.closed) {
/* 295 */             throw new IOException("Already closed");
/*     */           }
/*     */           
/* 298 */           byte[] arrayOfByte = this.buffer.buffer;
/* 299 */           int i = arrayOfByte.length;
/* 300 */           while (param1Int2 > 0) {
/* 301 */             int j = param1Int2;
/* 302 */             if (param1Int2 > i - 14 + this.dataLen - 32 - 20) {
/* 303 */               j = i - 14 + this.dataLen - 32 - 20;
/*     */             }
/*     */             
/* 306 */             if (j <= 0) {
/* 307 */               flush();
/*     */               
/*     */               continue;
/*     */             } 
/* 311 */             System.arraycopy(param1ArrayOfbyte, param1Int1, arrayOfByte, 14 + this.dataLen, j);
/* 312 */             this.dataLen += j;
/* 313 */             param1Int1 += j;
/* 314 */             param1Int2 -= j;
/*     */           } 
/*     */         }
/*     */         
/*     */         public void flush() throws IOException {
/* 319 */           if (this.closed) {
/* 320 */             throw new IOException("Already closed");
/*     */           }
/* 322 */           if (this.dataLen == 0)
/*     */             return; 
/* 324 */           this.packet.reset();
/* 325 */           this.buffer.putByte((byte)94);
/* 326 */           this.buffer.putInt(this.this$0.recipient);
/* 327 */           this.buffer.putInt(this.dataLen);
/* 328 */           this.buffer.skip(this.dataLen);
/*     */           try {
/* 330 */             int i = this.dataLen;
/* 331 */             this.dataLen = 0;
/* 332 */             this.this$0.getSession().write(this.packet, this.val$channel, i);
/*     */           } catch (Exception exception) {
/*     */             
/* 335 */             close();
/* 336 */             throw new IOException(exception.toString());
/*     */           } 
/*     */         }
/*     */         
/*     */         public void close() throws IOException {
/* 341 */           if (this.packet == null)
/*     */             try {
/* 343 */               init();
/*     */ 
/*     */             
/*     */             }
/* 347 */             catch (IOException iOException) {
/*     */               return;
/*     */             }  
/* 350 */           if (this.closed) {
/*     */             return;
/*     */           }
/* 353 */           if (this.dataLen > 0) {
/* 354 */             flush();
/*     */           }
/* 356 */           this.val$channel.eof();
/* 357 */           this.closed = true;
/*     */         }
/*     */       };
/*     */   }
/*     */   
/*     */   class MyPipedInputStream extends PipedInputStream { private final Channel this$0;
/*     */     
/* 364 */     MyPipedInputStream(Channel this$0) throws IOException { this.this$0 = this$0; } MyPipedInputStream(Channel this$0, int param1Int) throws IOException {
/* 365 */       this.this$0 = this$0;
/*     */       
/* 367 */       this.buffer = new byte[param1Int];
/*     */     } MyPipedInputStream(Channel this$0, PipedOutputStream param1PipedOutputStream) throws IOException {
/* 369 */       super(param1PipedOutputStream); this.this$0 = this$0;
/*     */     } MyPipedInputStream(Channel this$0, PipedOutputStream param1PipedOutputStream, int param1Int) throws IOException {
/* 371 */       super(param1PipedOutputStream); this.this$0 = this$0;
/* 372 */       this.buffer = new byte[param1Int];
/*     */     } }
/*     */   
/* 375 */   void setLocalWindowSizeMax(int paramInt) { this.lwsize_max = paramInt; }
/* 376 */   void setLocalWindowSize(int paramInt) { this.lwsize = paramInt; }
/* 377 */   void setLocalPacketSize(int paramInt) { this.lmpsize = paramInt; } synchronized void setRemoteWindowSize(int paramInt) {
/* 378 */     this.rwsize = paramInt;
/*     */   } synchronized void addRemoteWindowSize(int paramInt) {
/* 380 */     this.rwsize += paramInt;
/* 381 */     if (this.notifyme > 0)
/* 382 */       notifyAll(); 
/*     */   } void setRemotePacketSize(int paramInt) {
/* 384 */     this.rmpsize = paramInt;
/*     */   }
/*     */   
/*     */   public void run() {}
/*     */   
/*     */   void write(byte[] paramArrayOfbyte) throws IOException {
/* 390 */     write(paramArrayOfbyte, 0, paramArrayOfbyte.length);
/*     */   }
/*     */   void write(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException {
/*     */     try {
/* 394 */       this.io.put(paramArrayOfbyte, paramInt1, paramInt2);
/* 395 */     } catch (NullPointerException nullPointerException) {}
/*     */   }
/*     */   void write_ext(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException {
/*     */     try {
/* 399 */       this.io.put_ext(paramArrayOfbyte, paramInt1, paramInt2);
/* 400 */     } catch (NullPointerException nullPointerException) {}
/*     */   }
/*     */   
/*     */   void eof_remote() {
/* 404 */     this.eof_remote = true;
/*     */     try {
/* 406 */       this.io.out_close();
/*     */     }
/* 408 */     catch (NullPointerException nullPointerException) {}
/*     */   }
/*     */ 
/*     */   
/*     */   void eof() {
/* 413 */     if (this.close)
/* 414 */       return;  if (this.eof_local)
/* 415 */       return;  this.eof_local = true;
/*     */     
/*     */     try {
/* 418 */       Buffer buffer = new Buffer(100);
/* 419 */       Packet packet = new Packet(buffer);
/* 420 */       packet.reset();
/* 421 */       buffer.putByte((byte)96);
/* 422 */       buffer.putInt(getRecipient());
/* 423 */       getSession().write(packet);
/*     */     }
/* 425 */     catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void close() {
/* 472 */     if (this.close)
/* 473 */       return;  this.close = true;
/*     */     
/* 475 */     this.eof_local = this.eof_remote = true;
/*     */     
/*     */     try {
/* 478 */       Buffer buffer = new Buffer(100);
/* 479 */       Packet packet = new Packet(buffer);
/* 480 */       packet.reset();
/* 481 */       buffer.putByte((byte)97);
/* 482 */       buffer.putInt(getRecipient());
/* 483 */       getSession().write(packet);
/*     */     }
/* 485 */     catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isClosed() {
/* 490 */     return this.close;
/*     */   }
/*     */   static void disconnect(Session paramSession) {
/* 493 */     Channel[] arrayOfChannel = null;
/* 494 */     byte b1 = 0;
/* 495 */     synchronized (pool) {
/* 496 */       arrayOfChannel = new Channel[pool.size()];
/* 497 */       for (byte b = 0; b < pool.size(); b++) {
/*     */         try {
/* 499 */           Channel channel = pool.elementAt(b);
/* 500 */           if (channel.session == paramSession) {
/* 501 */             arrayOfChannel[b1++] = channel;
/*     */           }
/*     */         }
/* 504 */         catch (Exception exception) {}
/*     */       } 
/*     */     } 
/*     */     
/* 508 */     for (byte b2 = 0; b2 < b1; b2++) {
/* 509 */       arrayOfChannel[b2].disconnect();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void disconnect() {
/* 517 */     synchronized (this) {
/* 518 */       if (!this.connected) {
/*     */         return;
/*     */       }
/* 521 */       this.connected = false;
/*     */     } 
/*     */     
/*     */     try {
/* 525 */       close();
/*     */       
/* 527 */       this.eof_remote = this.eof_local = true;
/*     */       
/* 529 */       this.thread = null;
/*     */       
/*     */       try {
/* 532 */         if (this.io != null) {
/* 533 */           this.io.close();
/*     */         }
/*     */       }
/* 536 */       catch (Exception exception) {}
/*     */     
/*     */     }
/*     */     finally {
/*     */ 
/*     */       
/* 542 */       del(this);
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean isConnected() {
/* 547 */     Session session = this.session;
/* 548 */     if (session != null) {
/* 549 */       return (session.isConnected() && this.connected);
/*     */     }
/* 551 */     return false;
/*     */   }
/*     */   
/*     */   public void sendSignal(String paramString) throws Exception {
/* 555 */     RequestSignal requestSignal = new RequestSignal();
/* 556 */     requestSignal.setSignal(paramString);
/* 557 */     requestSignal.request(getSession(), this);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   class PassiveInputStream
/*     */     extends MyPipedInputStream
/*     */   {
/*     */     PipedOutputStream out;
/*     */ 
/*     */ 
/*     */     
/*     */     private final Channel this$0;
/*     */ 
/*     */ 
/*     */     
/*     */     PassiveInputStream(Channel this$0, PipedOutputStream param1PipedOutputStream, int param1Int) throws IOException {
/* 575 */       super(this$0, param1PipedOutputStream, param1Int); this.this$0 = this$0;
/* 576 */       this.out = param1PipedOutputStream;
/*     */     }
/*     */     PassiveInputStream(Channel this$0, PipedOutputStream param1PipedOutputStream) throws IOException {
/* 579 */       super(this$0, param1PipedOutputStream); this.this$0 = this$0;
/* 580 */       this.out = param1PipedOutputStream;
/*     */     }
/*     */     public void close() throws IOException {
/* 583 */       if (this.out != null) {
/* 584 */         this.out.close();
/*     */       }
/* 586 */       this.out = null;
/*     */     } }
/*     */   class PassiveOutputStream extends PipedOutputStream { private final Channel this$0;
/*     */     
/*     */     PassiveOutputStream(Channel this$0, PipedInputStream param1PipedInputStream) throws IOException {
/* 591 */       super(param1PipedInputStream);
/*     */       this.this$0 = this$0;
/*     */     } }
/*     */   
/* 595 */   void setExitStatus(int paramInt) { this.exitstatus = paramInt; } public int getExitStatus() {
/* 596 */     return this.exitstatus;
/*     */   }
/*     */   void setSession(Session paramSession) {
/* 599 */     this.session = paramSession;
/*     */   }
/*     */   
/*     */   public Session getSession() throws JSchException {
/* 603 */     Session session = this.session;
/* 604 */     if (session == null) {
/* 605 */       throw new JSchException("session is not available");
/*     */     }
/* 607 */     return session;
/*     */   } public int getId() {
/* 609 */     return this.id;
/*     */   }
/*     */   protected void sendOpenConfirmation() throws Exception {
/* 612 */     Buffer buffer = new Buffer(100);
/* 613 */     Packet packet = new Packet(buffer);
/* 614 */     packet.reset();
/* 615 */     buffer.putByte((byte)91);
/* 616 */     buffer.putInt(getRecipient());
/* 617 */     buffer.putInt(this.id);
/* 618 */     buffer.putInt(this.lwsize);
/* 619 */     buffer.putInt(this.lmpsize);
/* 620 */     getSession().write(packet);
/*     */   }
/*     */   
/*     */   protected void sendOpenFailure(int paramInt) {
/*     */     try {
/* 625 */       Buffer buffer = new Buffer(100);
/* 626 */       Packet packet = new Packet(buffer);
/* 627 */       packet.reset();
/* 628 */       buffer.putByte((byte)92);
/* 629 */       buffer.putInt(getRecipient());
/* 630 */       buffer.putInt(paramInt);
/* 631 */       buffer.putString("open failed".getBytes());
/* 632 */       buffer.putString("".getBytes());
/* 633 */       getSession().write(packet);
/*     */     }
/* 635 */     catch (Exception exception) {}
/*     */   }
/*     */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/Channel.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */