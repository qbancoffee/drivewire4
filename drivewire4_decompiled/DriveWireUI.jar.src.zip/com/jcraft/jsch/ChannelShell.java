/*    */ package com.jcraft.jsch;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ChannelShell
/*    */   extends ChannelSession
/*    */ {
/*    */   public void start() throws JSchException {
/* 42 */     Session session = getSession();
/*    */     try {
/* 44 */       sendRequests();
/*    */       
/* 46 */       RequestShell requestShell = new RequestShell();
/* 47 */       requestShell.request(session, this);
/*    */     } catch (Exception exception) {
/*    */       
/* 50 */       if (exception instanceof JSchException) throw (JSchException)exception; 
/* 51 */       if (exception instanceof Throwable)
/* 52 */         throw new JSchException("ChannelShell", exception); 
/* 53 */       throw new JSchException("ChannelShell");
/*    */     } 
/*    */     
/* 56 */     if (this.io.in != null) {
/* 57 */       this.thread = new Thread(this);
/* 58 */       this.thread.setName("Shell for " + session.host);
/* 59 */       if (session.daemon_thread) {
/* 60 */         this.thread.setDaemon(session.daemon_thread);
/*    */       }
/* 62 */       this.thread.start();
/*    */     } 
/*    */   }
/*    */   
/*    */   void init() throws JSchException {
/* 67 */     this.io.setInputStream((getSession()).in);
/* 68 */     this.io.setOutputStream((getSession()).out);
/*    */   }
/*    */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/ChannelShell.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */