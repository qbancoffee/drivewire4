/*    */ package com.jcraft.jsch;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SftpException
/*    */   extends Exception
/*    */ {
/*    */   public int id;
/* 35 */   private Throwable cause = null;
/*    */   public SftpException(int paramInt, String paramString) {
/* 37 */     super(paramString);
/* 38 */     this.id = paramInt;
/*    */   }
/*    */   public SftpException(int paramInt, String paramString, Throwable paramThrowable) {
/* 41 */     super(paramString);
/* 42 */     this.id = paramInt;
/* 43 */     this.cause = paramThrowable;
/*    */   }
/*    */   public String toString() {
/* 46 */     return this.id + ": " + getMessage();
/*    */   }
/*    */   public Throwable getCause() {
/* 49 */     return this.cause;
/*    */   }
/*    */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/SftpException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */