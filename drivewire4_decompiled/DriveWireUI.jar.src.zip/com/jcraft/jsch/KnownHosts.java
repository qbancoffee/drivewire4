/*     */ package com.jcraft.jsch;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class KnownHosts
/*     */   implements HostKeyRepository
/*     */ {
/*     */   private static final String _known_hosts = "known_hosts";
/*  44 */   private JSch jsch = null;
/*  45 */   private String known_hosts = null;
/*  46 */   private Vector pool = null;
/*     */   
/*  48 */   private MAC hmacsha1 = null;
/*     */ 
/*     */   
/*     */   KnownHosts(JSch paramJSch) {
/*  52 */     this.jsch = paramJSch;
/*  53 */     this.pool = new Vector();
/*     */   }
/*     */   
/*     */   void setKnownHosts(String paramString) throws JSchException {
/*     */     try {
/*  58 */       this.known_hosts = paramString;
/*  59 */       FileInputStream fileInputStream = new FileInputStream(paramString);
/*  60 */       setKnownHosts(fileInputStream);
/*     */     }
/*  62 */     catch (FileNotFoundException fileNotFoundException) {}
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void setKnownHosts(InputStream paramInputStream) throws JSchException {
/*     */     // Byte code:
/*     */     //   0: aload_0
/*     */     //   1: getfield pool : Ljava/util/Vector;
/*     */     //   4: invokevirtual removeAllElements : ()V
/*     */     //   7: new java/lang/StringBuffer
/*     */     //   10: dup
/*     */     //   11: invokespecial <init> : ()V
/*     */     //   14: astore_2
/*     */     //   15: iconst_0
/*     */     //   16: istore #5
/*     */     //   18: aload_1
/*     */     //   19: astore #6
/*     */     //   21: aconst_null
/*     */     //   22: astore #8
/*     */     //   24: sipush #1024
/*     */     //   27: newarray byte
/*     */     //   29: astore #10
/*     */     //   31: iconst_0
/*     */     //   32: istore #11
/*     */     //   34: goto -> 37
/*     */     //   37: iconst_0
/*     */     //   38: istore #11
/*     */     //   40: goto -> 43
/*     */     //   43: aload #6
/*     */     //   45: invokevirtual read : ()I
/*     */     //   48: istore #4
/*     */     //   50: iload #4
/*     */     //   52: iconst_m1
/*     */     //   53: if_icmpne -> 64
/*     */     //   56: iload #11
/*     */     //   58: ifne -> 142
/*     */     //   61: goto -> 556
/*     */     //   64: iload #4
/*     */     //   66: bipush #13
/*     */     //   68: if_icmpne -> 74
/*     */     //   71: goto -> 43
/*     */     //   74: iload #4
/*     */     //   76: bipush #10
/*     */     //   78: if_icmpne -> 84
/*     */     //   81: goto -> 142
/*     */     //   84: aload #10
/*     */     //   86: arraylength
/*     */     //   87: iload #11
/*     */     //   89: if_icmpgt -> 128
/*     */     //   92: iload #11
/*     */     //   94: sipush #10240
/*     */     //   97: if_icmple -> 103
/*     */     //   100: goto -> 142
/*     */     //   103: aload #10
/*     */     //   105: arraylength
/*     */     //   106: iconst_2
/*     */     //   107: imul
/*     */     //   108: newarray byte
/*     */     //   110: astore #12
/*     */     //   112: aload #10
/*     */     //   114: iconst_0
/*     */     //   115: aload #12
/*     */     //   117: iconst_0
/*     */     //   118: aload #10
/*     */     //   120: arraylength
/*     */     //   121: invokestatic arraycopy : (Ljava/lang/Object;ILjava/lang/Object;II)V
/*     */     //   124: aload #12
/*     */     //   126: astore #10
/*     */     //   128: aload #10
/*     */     //   130: iload #11
/*     */     //   132: iinc #11, 1
/*     */     //   135: iload #4
/*     */     //   137: i2b
/*     */     //   138: bastore
/*     */     //   139: goto -> 43
/*     */     //   142: iconst_0
/*     */     //   143: istore #4
/*     */     //   145: goto -> 197
/*     */     //   148: aload #10
/*     */     //   150: iload #4
/*     */     //   152: baload
/*     */     //   153: istore_3
/*     */     //   154: iload_3
/*     */     //   155: bipush #32
/*     */     //   157: if_icmpeq -> 166
/*     */     //   160: iload_3
/*     */     //   161: bipush #9
/*     */     //   163: if_icmpne -> 172
/*     */     //   166: iinc #4, 1
/*     */     //   169: goto -> 197
/*     */     //   172: iload_3
/*     */     //   173: bipush #35
/*     */     //   175: if_icmpne -> 204
/*     */     //   178: aload_0
/*     */     //   179: new java/lang/String
/*     */     //   182: dup
/*     */     //   183: aload #10
/*     */     //   185: iconst_0
/*     */     //   186: iload #11
/*     */     //   188: invokespecial <init> : ([BII)V
/*     */     //   191: invokespecial addInvalidLine : (Ljava/lang/String;)V
/*     */     //   194: goto -> 37
/*     */     //   197: iload #4
/*     */     //   199: iload #11
/*     */     //   201: if_icmplt -> 148
/*     */     //   204: iload #4
/*     */     //   206: iload #11
/*     */     //   208: if_icmplt -> 230
/*     */     //   211: aload_0
/*     */     //   212: new java/lang/String
/*     */     //   215: dup
/*     */     //   216: aload #10
/*     */     //   218: iconst_0
/*     */     //   219: iload #11
/*     */     //   221: invokespecial <init> : ([BII)V
/*     */     //   224: invokespecial addInvalidLine : (Ljava/lang/String;)V
/*     */     //   227: goto -> 37
/*     */     //   230: aload_2
/*     */     //   231: iconst_0
/*     */     //   232: invokevirtual setLength : (I)V
/*     */     //   235: goto -> 269
/*     */     //   238: aload #10
/*     */     //   240: iload #4
/*     */     //   242: iinc #4, 1
/*     */     //   245: baload
/*     */     //   246: istore_3
/*     */     //   247: iload_3
/*     */     //   248: bipush #32
/*     */     //   250: if_icmpeq -> 276
/*     */     //   253: iload_3
/*     */     //   254: bipush #9
/*     */     //   256: if_icmpne -> 262
/*     */     //   259: goto -> 276
/*     */     //   262: aload_2
/*     */     //   263: iload_3
/*     */     //   264: i2c
/*     */     //   265: invokevirtual append : (C)Ljava/lang/StringBuffer;
/*     */     //   268: pop
/*     */     //   269: iload #4
/*     */     //   271: iload #11
/*     */     //   273: if_icmplt -> 238
/*     */     //   276: aload_2
/*     */     //   277: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   280: astore #7
/*     */     //   282: iload #4
/*     */     //   284: iload #11
/*     */     //   286: if_icmpge -> 297
/*     */     //   289: aload #7
/*     */     //   291: invokevirtual length : ()I
/*     */     //   294: ifne -> 316
/*     */     //   297: aload_0
/*     */     //   298: new java/lang/String
/*     */     //   301: dup
/*     */     //   302: aload #10
/*     */     //   304: iconst_0
/*     */     //   305: iload #11
/*     */     //   307: invokespecial <init> : ([BII)V
/*     */     //   310: invokespecial addInvalidLine : (Ljava/lang/String;)V
/*     */     //   313: goto -> 37
/*     */     //   316: aload_2
/*     */     //   317: iconst_0
/*     */     //   318: invokevirtual setLength : (I)V
/*     */     //   321: iconst_m1
/*     */     //   322: istore #9
/*     */     //   324: goto -> 358
/*     */     //   327: aload #10
/*     */     //   329: iload #4
/*     */     //   331: iinc #4, 1
/*     */     //   334: baload
/*     */     //   335: istore_3
/*     */     //   336: iload_3
/*     */     //   337: bipush #32
/*     */     //   339: if_icmpeq -> 365
/*     */     //   342: iload_3
/*     */     //   343: bipush #9
/*     */     //   345: if_icmpne -> 351
/*     */     //   348: goto -> 365
/*     */     //   351: aload_2
/*     */     //   352: iload_3
/*     */     //   353: i2c
/*     */     //   354: invokevirtual append : (C)Ljava/lang/StringBuffer;
/*     */     //   357: pop
/*     */     //   358: iload #4
/*     */     //   360: iload #11
/*     */     //   362: if_icmplt -> 327
/*     */     //   365: aload_2
/*     */     //   366: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   369: ldc 'ssh-dss'
/*     */     //   371: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */     //   374: ifeq -> 383
/*     */     //   377: iconst_1
/*     */     //   378: istore #9
/*     */     //   380: goto -> 405
/*     */     //   383: aload_2
/*     */     //   384: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   387: ldc 'ssh-rsa'
/*     */     //   389: invokevirtual equals : (Ljava/lang/Object;)Z
/*     */     //   392: ifeq -> 401
/*     */     //   395: iconst_2
/*     */     //   396: istore #9
/*     */     //   398: goto -> 405
/*     */     //   401: iload #11
/*     */     //   403: istore #4
/*     */     //   405: iload #4
/*     */     //   407: iload #11
/*     */     //   409: if_icmplt -> 431
/*     */     //   412: aload_0
/*     */     //   413: new java/lang/String
/*     */     //   416: dup
/*     */     //   417: aload #10
/*     */     //   419: iconst_0
/*     */     //   420: iload #11
/*     */     //   422: invokespecial <init> : ([BII)V
/*     */     //   425: invokespecial addInvalidLine : (Ljava/lang/String;)V
/*     */     //   428: goto -> 37
/*     */     //   431: aload_2
/*     */     //   432: iconst_0
/*     */     //   433: invokevirtual setLength : (I)V
/*     */     //   436: goto -> 473
/*     */     //   439: aload #10
/*     */     //   441: iload #4
/*     */     //   443: iinc #4, 1
/*     */     //   446: baload
/*     */     //   447: istore_3
/*     */     //   448: iload_3
/*     */     //   449: bipush #13
/*     */     //   451: if_icmpne -> 457
/*     */     //   454: goto -> 473
/*     */     //   457: iload_3
/*     */     //   458: bipush #10
/*     */     //   460: if_icmpne -> 466
/*     */     //   463: goto -> 480
/*     */     //   466: aload_2
/*     */     //   467: iload_3
/*     */     //   468: i2c
/*     */     //   469: invokevirtual append : (C)Ljava/lang/StringBuffer;
/*     */     //   472: pop
/*     */     //   473: iload #4
/*     */     //   475: iload #11
/*     */     //   477: if_icmplt -> 439
/*     */     //   480: aload_2
/*     */     //   481: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   484: astore #8
/*     */     //   486: aload #8
/*     */     //   488: invokevirtual length : ()I
/*     */     //   491: ifne -> 513
/*     */     //   494: aload_0
/*     */     //   495: new java/lang/String
/*     */     //   498: dup
/*     */     //   499: aload #10
/*     */     //   501: iconst_0
/*     */     //   502: iload #11
/*     */     //   504: invokespecial <init> : ([BII)V
/*     */     //   507: invokespecial addInvalidLine : (Ljava/lang/String;)V
/*     */     //   510: goto -> 37
/*     */     //   513: aconst_null
/*     */     //   514: astore #12
/*     */     //   516: new com/jcraft/jsch/KnownHosts$HashedHostKey
/*     */     //   519: dup
/*     */     //   520: aload_0
/*     */     //   521: aload #7
/*     */     //   523: iload #9
/*     */     //   525: aload #8
/*     */     //   527: invokevirtual getBytes : ()[B
/*     */     //   530: iconst_0
/*     */     //   531: aload #8
/*     */     //   533: invokevirtual length : ()I
/*     */     //   536: invokestatic fromBase64 : ([BII)[B
/*     */     //   539: invokespecial <init> : (Lcom/jcraft/jsch/KnownHosts;Ljava/lang/String;I[B)V
/*     */     //   542: astore #12
/*     */     //   544: aload_0
/*     */     //   545: getfield pool : Ljava/util/Vector;
/*     */     //   548: aload #12
/*     */     //   550: invokevirtual addElement : (Ljava/lang/Object;)V
/*     */     //   553: goto -> 37
/*     */     //   556: aload #6
/*     */     //   558: invokevirtual close : ()V
/*     */     //   561: iload #5
/*     */     //   563: ifeq -> 576
/*     */     //   566: new com/jcraft/jsch/JSchException
/*     */     //   569: dup
/*     */     //   570: ldc 'KnownHosts: invalid format'
/*     */     //   572: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   575: athrow
/*     */     //   576: goto -> 631
/*     */     //   579: astore #6
/*     */     //   581: aload #6
/*     */     //   583: instanceof com/jcraft/jsch/JSchException
/*     */     //   586: ifeq -> 595
/*     */     //   589: aload #6
/*     */     //   591: checkcast com/jcraft/jsch/JSchException
/*     */     //   594: athrow
/*     */     //   595: aload #6
/*     */     //   597: instanceof java/lang/Throwable
/*     */     //   600: ifeq -> 618
/*     */     //   603: new com/jcraft/jsch/JSchException
/*     */     //   606: dup
/*     */     //   607: aload #6
/*     */     //   609: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   612: aload #6
/*     */     //   614: invokespecial <init> : (Ljava/lang/String;Ljava/lang/Throwable;)V
/*     */     //   617: athrow
/*     */     //   618: new com/jcraft/jsch/JSchException
/*     */     //   621: dup
/*     */     //   622: aload #6
/*     */     //   624: invokevirtual toString : ()Ljava/lang/String;
/*     */     //   627: invokespecial <init> : (Ljava/lang/String;)V
/*     */     //   630: athrow
/*     */     //   631: return
/*     */     // Line number table:
/*     */     //   Java source line number -> byte code offset
/*     */     //   #66	-> 0
/*     */     //   #67	-> 7
/*     */     //   #70	-> 15
/*     */     //   #72	-> 18
/*     */     //   #74	-> 21
/*     */     //   #76	-> 24
/*     */     //   #77	-> 31
/*     */     //   #79	-> 34
/*     */     //   #80	-> 37
/*     */     //   #81	-> 40
/*     */     //   #82	-> 43
/*     */     //   #83	-> 50
/*     */     //   #84	-> 56
/*     */     //   #87	-> 64
/*     */     //   #88	-> 74
/*     */     //   #89	-> 84
/*     */     //   #90	-> 92
/*     */     //   #91	-> 103
/*     */     //   #92	-> 112
/*     */     //   #93	-> 124
/*     */     //   #95	-> 128
/*     */     //   #81	-> 139
/*     */     //   #98	-> 142
/*     */     //   #99	-> 145
/*     */     //   #100	-> 148
/*     */     //   #101	-> 154
/*     */     //   #102	-> 172
/*     */     //   #103	-> 178
/*     */     //   #104	-> 194
/*     */     //   #99	-> 197
/*     */     //   #108	-> 204
/*     */     //   #109	-> 211
/*     */     //   #110	-> 227
/*     */     //   #113	-> 230
/*     */     //   #114	-> 235
/*     */     //   #115	-> 238
/*     */     //   #116	-> 247
/*     */     //   #117	-> 262
/*     */     //   #114	-> 269
/*     */     //   #119	-> 276
/*     */     //   #120	-> 282
/*     */     //   #121	-> 297
/*     */     //   #122	-> 313
/*     */     //   #125	-> 316
/*     */     //   #126	-> 321
/*     */     //   #127	-> 324
/*     */     //   #128	-> 327
/*     */     //   #129	-> 336
/*     */     //   #130	-> 351
/*     */     //   #127	-> 358
/*     */     //   #132	-> 365
/*     */     //   #133	-> 383
/*     */     //   #134	-> 401
/*     */     //   #135	-> 405
/*     */     //   #136	-> 412
/*     */     //   #137	-> 428
/*     */     //   #140	-> 431
/*     */     //   #141	-> 436
/*     */     //   #142	-> 439
/*     */     //   #143	-> 448
/*     */     //   #144	-> 457
/*     */     //   #145	-> 466
/*     */     //   #141	-> 473
/*     */     //   #147	-> 480
/*     */     //   #148	-> 486
/*     */     //   #149	-> 494
/*     */     //   #150	-> 510
/*     */     //   #156	-> 513
/*     */     //   #157	-> 516
/*     */     //   #160	-> 544
/*     */     //   #79	-> 553
/*     */     //   #162	-> 556
/*     */     //   #163	-> 561
/*     */     //   #164	-> 566
/*     */     //   #166	-> 576
/*     */     //   #168	-> 579
/*     */     //   #169	-> 589
/*     */     //   #170	-> 595
/*     */     //   #171	-> 603
/*     */     //   #172	-> 618
/*     */     //   #174	-> 631
/*     */     // Exception table:
/*     */     //   from	to	target	type
/*     */     //   18	576	579	java/lang/Exception
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void addInvalidLine(String paramString) throws JSchException {
/* 176 */     HostKey hostKey = new HostKey(paramString, 3, null);
/* 177 */     this.pool.addElement(hostKey);
/*     */   }
/* 179 */   String getKnownHostsFile() { return this.known_hosts; } public String getKnownHostsRepositoryID() {
/* 180 */     return this.known_hosts;
/*     */   }
/*     */   public int check(String paramString, byte[] paramArrayOfbyte) {
/* 183 */     byte b = 1;
/* 184 */     if (paramString == null) {
/* 185 */       return b;
/*     */     }
/*     */     
/* 188 */     int i = getType(paramArrayOfbyte);
/*     */ 
/*     */     
/* 191 */     synchronized (this.pool) {
/* 192 */       for (byte b1 = 0; b1 < this.pool.size(); b1++) {
/* 193 */         HostKey hostKey = this.pool.elementAt(b1);
/* 194 */         if (hostKey.isMatched(paramString) && hostKey.type == i) {
/* 195 */           if (Util.array_equals(hostKey.key, paramArrayOfbyte))
/*     */           {
/* 197 */             return 0;
/*     */           }
/*     */           
/* 200 */           b = 2;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 206 */     return b;
/*     */   }
/*     */   public void add(HostKey paramHostKey, UserInfo paramUserInfo) {
/* 209 */     int i = paramHostKey.type;
/* 210 */     String str1 = paramHostKey.getHost();
/* 211 */     byte[] arrayOfByte = paramHostKey.key;
/*     */     
/* 213 */     HostKey hostKey = null;
/* 214 */     synchronized (this.pool) {
/* 215 */       for (byte b = 0; b < this.pool.size(); b++) {
/* 216 */         hostKey = this.pool.elementAt(b);
/* 217 */         if (!hostKey.isMatched(str1) || hostKey.type == i);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 233 */     hostKey = paramHostKey;
/*     */     
/* 235 */     this.pool.addElement(hostKey);
/*     */     
/* 237 */     String str2 = getKnownHostsRepositoryID();
/* 238 */     if (str2 != null) {
/* 239 */       boolean bool = true;
/* 240 */       File file = new File(str2);
/* 241 */       if (!file.exists()) {
/* 242 */         bool = false;
/* 243 */         if (paramUserInfo != null) {
/* 244 */           bool = paramUserInfo.promptYesNo(str2 + " does not exist.\n" + "Are you sure you want to create it?");
/*     */ 
/*     */           
/* 247 */           file = file.getParentFile();
/* 248 */           if (bool && file != null && !file.exists()) {
/* 249 */             bool = paramUserInfo.promptYesNo("The parent directory " + file + " does not exist.\n" + "Are you sure you want to create it?");
/*     */ 
/*     */             
/* 252 */             if (bool) {
/* 253 */               if (!file.mkdirs()) {
/* 254 */                 paramUserInfo.showMessage(file + " has not been created.");
/* 255 */                 bool = false;
/*     */               } else {
/*     */                 
/* 258 */                 paramUserInfo.showMessage(file + " has been succesfully created.\nPlease check its access permission.");
/*     */               } 
/*     */             }
/*     */           } 
/* 262 */           if (file == null) bool = false; 
/*     */         } 
/*     */       } 
/* 265 */       if (bool)
/*     */         try {
/* 267 */           sync(str2);
/*     */         } catch (Exception exception) {
/* 269 */           System.err.println("sync known_hosts: " + exception);
/*     */         }  
/*     */     } 
/*     */   }
/*     */   
/*     */   public HostKey[] getHostKey() {
/* 275 */     return getHostKey(null, null);
/*     */   }
/*     */   public HostKey[] getHostKey(String paramString1, String paramString2) {
/* 278 */     synchronized (this.pool) {
/* 279 */       byte b1 = 0;
/* 280 */       for (byte b2 = 0; b2 < this.pool.size(); b2++) {
/* 281 */         HostKey hostKey = this.pool.elementAt(b2);
/* 282 */         if (hostKey.type != 3 && (
/* 283 */           paramString1 == null || (hostKey.isMatched(paramString1) && (paramString2 == null || hostKey.getType().equals(paramString2)))))
/*     */         {
/*     */           
/* 286 */           b1++;
/*     */         }
/*     */       } 
/* 289 */       if (b1 == 0) return null; 
/* 290 */       HostKey[] arrayOfHostKey = new HostKey[b1];
/* 291 */       byte b3 = 0;
/* 292 */       for (byte b4 = 0; b4 < this.pool.size(); b4++) {
/* 293 */         HostKey hostKey = this.pool.elementAt(b4);
/* 294 */         if (hostKey.type != 3 && (
/* 295 */           paramString1 == null || (hostKey.isMatched(paramString1) && (paramString2 == null || hostKey.getType().equals(paramString2)))))
/*     */         {
/*     */           
/* 298 */           arrayOfHostKey[b3++] = hostKey;
/*     */         }
/*     */       } 
/* 301 */       return arrayOfHostKey;
/*     */     } 
/*     */   }
/*     */   public void remove(String paramString1, String paramString2) {
/* 305 */     remove(paramString1, paramString2, null);
/*     */   }
/*     */   public void remove(String paramString1, String paramString2, byte[] paramArrayOfbyte) {
/* 308 */     boolean bool = false;
/* 309 */     synchronized (this.pool) {
/* 310 */       for (byte b = 0; b < this.pool.size(); b++) {
/* 311 */         HostKey hostKey = this.pool.elementAt(b);
/* 312 */         if (paramString1 == null || (hostKey.isMatched(paramString1) && (paramString2 == null || (hostKey.getType().equals(paramString2) && (paramArrayOfbyte == null || Util.array_equals(paramArrayOfbyte, hostKey.key)))))) {
/*     */ 
/*     */ 
/*     */           
/* 316 */           String str = hostKey.getHost();
/* 317 */           if (str.equals(paramString1) || (hostKey instanceof HashedHostKey && ((HashedHostKey)hostKey).isHashed())) {
/*     */ 
/*     */             
/* 320 */             this.pool.removeElement(hostKey);
/*     */           } else {
/*     */             
/* 323 */             hostKey.host = deleteSubString(str, paramString1);
/*     */           } 
/* 325 */           bool = true;
/*     */         } 
/*     */       } 
/*     */     } 
/* 329 */     if (bool) {
/* 330 */       try { sync(); } catch (Exception exception) {}
/*     */     }
/*     */   }
/*     */   
/*     */   protected void sync() throws IOException {
/* 335 */     if (this.known_hosts != null)
/* 336 */       sync(this.known_hosts); 
/*     */   }
/*     */   protected synchronized void sync(String paramString) throws IOException {
/* 339 */     if (paramString == null)
/* 340 */       return;  FileOutputStream fileOutputStream = new FileOutputStream(paramString);
/* 341 */     dump(fileOutputStream);
/* 342 */     fileOutputStream.close();
/*     */   }
/*     */   
/* 345 */   private static final byte[] space = new byte[] { 32 };
/* 346 */   private static final byte[] cr = "\n".getBytes();
/*     */   
/*     */   void dump(OutputStream paramOutputStream) throws IOException {
/*     */     try {
/* 350 */       synchronized (this.pool) {
/* 351 */         for (byte b = 0; b < this.pool.size(); b++) {
/* 352 */           HostKey hostKey = this.pool.elementAt(b);
/*     */           
/* 354 */           String str1 = hostKey.getHost();
/* 355 */           String str2 = hostKey.getType();
/* 356 */           if (str2.equals("UNKNOWN")) {
/* 357 */             paramOutputStream.write(str1.getBytes());
/* 358 */             paramOutputStream.write(cr);
/*     */           } else {
/*     */             
/* 361 */             paramOutputStream.write(str1.getBytes());
/* 362 */             paramOutputStream.write(space);
/* 363 */             paramOutputStream.write(str2.getBytes());
/* 364 */             paramOutputStream.write(space);
/* 365 */             paramOutputStream.write(hostKey.getKey().getBytes());
/* 366 */             paramOutputStream.write(cr);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } catch (Exception exception) {
/* 371 */       System.err.println(exception);
/*     */     } 
/*     */   }
/*     */   private int getType(byte[] paramArrayOfbyte) {
/* 375 */     if (paramArrayOfbyte[8] == 100) return 1; 
/* 376 */     if (paramArrayOfbyte[8] == 114) return 2; 
/* 377 */     return 3;
/*     */   }
/*     */   private String deleteSubString(String paramString1, String paramString2) {
/* 380 */     int i = 0;
/* 381 */     int j = paramString2.length();
/* 382 */     int k = paramString1.length();
/*     */     
/* 384 */     while (i < k) {
/* 385 */       int m = paramString1.indexOf(',', i);
/* 386 */       if (m == -1)
/* 387 */         break;  if (!paramString2.equals(paramString1.substring(i, m))) {
/* 388 */         i = m + 1;
/*     */         continue;
/*     */       } 
/* 391 */       return paramString1.substring(0, i) + paramString1.substring(m + 1);
/*     */     } 
/* 393 */     if (paramString1.endsWith(paramString2) && k - i == j) {
/* 394 */       return paramString1.substring(0, (j == k) ? 0 : (k - j - 1));
/*     */     }
/* 396 */     return paramString1;
/*     */   }
/*     */   
/*     */   private synchronized MAC getHMACSHA1() {
/* 400 */     if (this.hmacsha1 == null) {
/*     */       try {
/* 402 */         this; Class clazz = Class.forName(JSch.getConfig("hmac-sha1"));
/* 403 */         this.hmacsha1 = (MAC)clazz.newInstance();
/*     */       } catch (Exception exception) {
/*     */         
/* 406 */         System.err.println("hmacsha1: " + exception);
/*     */       } 
/*     */     }
/* 409 */     return this.hmacsha1;
/*     */   }
/*     */   
/*     */   HostKey createHashedHostKey(String paramString, byte[] paramArrayOfbyte) throws JSchException {
/* 413 */     HashedHostKey hashedHostKey = new HashedHostKey(paramString, paramArrayOfbyte);
/* 414 */     hashedHostKey.hash();
/* 415 */     return hashedHostKey;
/*     */   }
/*     */   
/*     */   class HashedHostKey extends HostKey {
/*     */     private static final String HASH_MAGIC = "|1|";
/*     */     private static final String HASH_DELIM = "|";
/*     */     private boolean hashed;
/*     */     byte[] salt;
/*     */     byte[] hash;
/*     */     private final KnownHosts this$0;
/*     */     
/*     */     HashedHostKey(String param1String, byte[] param1ArrayOfbyte) throws JSchException {
/* 427 */       this(param1String, 0, param1ArrayOfbyte);
/*     */     }
/*     */     HashedHostKey(String param1String, int param1Int, byte[] param1ArrayOfbyte) throws JSchException {
/* 430 */       super(param1String, param1Int, param1ArrayOfbyte); KnownHosts.this = KnownHosts.this; this.hashed = false; this.salt = null; this.hash = null;
/* 431 */       if (this.host.startsWith("|1|") && this.host.substring("|1|".length()).indexOf("|") > 0) {
/*     */         
/* 433 */         String str1 = this.host.substring("|1|".length());
/* 434 */         String str2 = str1.substring(0, str1.indexOf("|"));
/* 435 */         String str3 = str1.substring(str1.indexOf("|") + 1);
/* 436 */         this.salt = Util.fromBase64(str2.getBytes(), 0, str2.length());
/* 437 */         this.hash = Util.fromBase64(str3.getBytes(), 0, str3.length());
/* 438 */         if (this.salt.length != 20 || this.hash.length != 20) {
/*     */           
/* 440 */           this.salt = null;
/* 441 */           this.hash = null;
/*     */           return;
/*     */         } 
/* 444 */         this.hashed = true;
/*     */       } 
/*     */     }
/*     */     
/*     */     boolean isMatched(String param1String) {
/* 449 */       if (!this.hashed) {
/* 450 */         return super.isMatched(param1String);
/*     */       }
/* 452 */       MAC mAC = KnownHosts.this.getHMACSHA1();
/*     */       try {
/* 454 */         synchronized (mAC) {
/* 455 */           mAC.init(this.salt);
/* 456 */           byte[] arrayOfByte1 = param1String.getBytes();
/* 457 */           mAC.update(arrayOfByte1, 0, arrayOfByte1.length);
/* 458 */           byte[] arrayOfByte2 = new byte[mAC.getBlockSize()];
/* 459 */           mAC.doFinal(arrayOfByte2, 0);
/* 460 */           return Util.array_equals(this.hash, arrayOfByte2);
/*     */         } 
/*     */       } catch (Exception exception) {
/*     */         
/* 464 */         System.out.println(exception);
/*     */         
/* 466 */         return false;
/*     */       } 
/*     */     }
/*     */     boolean isHashed() {
/* 470 */       return this.hashed;
/*     */     }
/*     */     
/*     */     void hash() {
/* 474 */       if (this.hashed)
/*     */         return; 
/* 476 */       MAC mAC = KnownHosts.this.getHMACSHA1();
/* 477 */       if (this.salt == null) {
/* 478 */         Random random = Session.random;
/* 479 */         synchronized (random) {
/* 480 */           this.salt = new byte[mAC.getBlockSize()];
/* 481 */           random.fill(this.salt, 0, this.salt.length);
/*     */         } 
/*     */       } 
/*     */       try {
/* 485 */         synchronized (mAC) {
/* 486 */           mAC.init(this.salt);
/* 487 */           byte[] arrayOfByte = this.host.getBytes();
/* 488 */           mAC.update(arrayOfByte, 0, arrayOfByte.length);
/* 489 */           this.hash = new byte[mAC.getBlockSize()];
/* 490 */           mAC.doFinal(this.hash, 0);
/*     */         }
/*     */       
/* 493 */       } catch (Exception exception) {}
/*     */       
/* 495 */       this.host = "|1|" + new String(Util.toBase64(this.salt, 0, this.salt.length)) + "|" + new String(Util.toBase64(this.hash, 0, this.hash.length));
/*     */       
/* 497 */       this.hashed = true;
/*     */     }
/*     */   }
/*     */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/KnownHosts.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */