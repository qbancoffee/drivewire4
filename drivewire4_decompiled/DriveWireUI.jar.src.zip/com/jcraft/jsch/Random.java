package com.jcraft.jsch;

public interface Random {
  void fill(byte[] paramArrayOfbyte, int paramInt1, int paramInt2);
}


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/Random.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */