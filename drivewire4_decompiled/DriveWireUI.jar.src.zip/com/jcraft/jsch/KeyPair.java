/*     */ package com.jcraft.jsch;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class KeyPair
/*     */ {
/*     */   public static final int ERROR = 0;
/*     */   public static final int DSA = 1;
/*     */   public static final int RSA = 2;
/*     */   public static final int UNKNOWN = 3;
/*     */   static final int VENDOR_OPENSSH = 0;
/*     */   static final int VENDOR_FSECURE = 1;
/*  44 */   int vendor = 0;
/*     */   
/*  46 */   private static final byte[] cr = "\n".getBytes();
/*     */   
/*     */   public static KeyPair genKeyPair(JSch paramJSch, int paramInt) throws JSchException {
/*  49 */     return genKeyPair(paramJSch, paramInt, 1024);
/*     */   } public static KeyPair genKeyPair(JSch paramJSch, int paramInt1, int paramInt2) throws JSchException {
/*     */     KeyPairRSA keyPairRSA;
/*  52 */     KeyPairDSA keyPairDSA = null;
/*  53 */     if (paramInt1 == 1) { keyPairDSA = new KeyPairDSA(paramJSch); }
/*  54 */     else if (paramInt1 == 2) { keyPairRSA = new KeyPairRSA(paramJSch); }
/*  55 */      if (keyPairRSA != null) {
/*  56 */       keyPairRSA.generate(paramInt2);
/*     */     }
/*  58 */     return keyPairRSA;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  67 */   JSch jsch = null;
/*     */ 
/*     */   
/*     */   private Cipher cipher;
/*     */   
/*     */   private HASH hash;
/*     */   
/*     */   private Random random;
/*     */   
/*     */   private byte[] passphrase;
/*     */   
/*  78 */   static byte[][] header = new byte[][] { "Proc-Type: 4,ENCRYPTED".getBytes(), "DEK-Info: DES-EDE3-CBC,".getBytes() };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void writePrivateKey(OutputStream paramOutputStream) {
/*  84 */     byte[] arrayOfByte1 = getPrivateKey();
/*  85 */     byte[][] arrayOfByte = new byte[1][];
/*  86 */     byte[] arrayOfByte2 = encrypt(arrayOfByte1, arrayOfByte);
/*  87 */     if (arrayOfByte2 != arrayOfByte1)
/*  88 */       Util.bzero(arrayOfByte1); 
/*  89 */     byte[] arrayOfByte3 = arrayOfByte[0];
/*  90 */     byte[] arrayOfByte4 = Util.toBase64(arrayOfByte2, 0, arrayOfByte2.length);
/*     */     
/*     */     try {
/*  93 */       paramOutputStream.write(getBegin()); paramOutputStream.write(cr);
/*  94 */       if (this.passphrase != null) {
/*  95 */         paramOutputStream.write(header[0]); paramOutputStream.write(cr);
/*  96 */         paramOutputStream.write(header[1]);
/*  97 */         for (byte b1 = 0; b1 < arrayOfByte3.length; b1++) {
/*  98 */           paramOutputStream.write(b2a((byte)(arrayOfByte3[b1] >>> 4 & 0xF)));
/*  99 */           paramOutputStream.write(b2a((byte)(arrayOfByte3[b1] & 0xF)));
/*     */         } 
/* 101 */         paramOutputStream.write(cr);
/* 102 */         paramOutputStream.write(cr);
/*     */       } 
/* 104 */       byte b = 0;
/* 105 */       while (b < arrayOfByte4.length) {
/* 106 */         if (b + 64 < arrayOfByte4.length) {
/* 107 */           paramOutputStream.write(arrayOfByte4, b, 64);
/* 108 */           paramOutputStream.write(cr);
/* 109 */           b += 64;
/*     */           continue;
/*     */         } 
/* 112 */         paramOutputStream.write(arrayOfByte4, b, arrayOfByte4.length - b);
/* 113 */         paramOutputStream.write(cr);
/*     */         break;
/*     */       } 
/* 116 */       paramOutputStream.write(getEnd()); paramOutputStream.write(cr);
/*     */     
/*     */     }
/* 119 */     catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */   
/* 123 */   private static byte[] space = " ".getBytes(); private boolean encrypted; private byte[] data;
/*     */   private byte[] iv;
/*     */   private byte[] publickeyblob;
/*     */   
/*     */   public byte[] getPublicKeyBlob() {
/* 128 */     return this.publickeyblob;
/*     */   }
/*     */   public void writePublicKey(OutputStream paramOutputStream, String paramString) {
/* 131 */     byte[] arrayOfByte1 = getPublicKeyBlob();
/* 132 */     byte[] arrayOfByte2 = Util.toBase64(arrayOfByte1, 0, arrayOfByte1.length);
/*     */     try {
/* 134 */       paramOutputStream.write(getKeyTypeName()); paramOutputStream.write(space);
/* 135 */       paramOutputStream.write(arrayOfByte2, 0, arrayOfByte2.length); paramOutputStream.write(space);
/* 136 */       paramOutputStream.write(paramString.getBytes());
/* 137 */       paramOutputStream.write(cr);
/*     */     }
/* 139 */     catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */   
/*     */   public void writePublicKey(String paramString1, String paramString2) throws FileNotFoundException, IOException {
/* 144 */     FileOutputStream fileOutputStream = new FileOutputStream(paramString1);
/* 145 */     writePublicKey(fileOutputStream, paramString2);
/* 146 */     fileOutputStream.close();
/*     */   }
/*     */   
/*     */   public void writeSECSHPublicKey(OutputStream paramOutputStream, String paramString) {
/* 150 */     byte[] arrayOfByte1 = getPublicKeyBlob();
/* 151 */     byte[] arrayOfByte2 = Util.toBase64(arrayOfByte1, 0, arrayOfByte1.length);
/*     */     try {
/* 153 */       paramOutputStream.write("---- BEGIN SSH2 PUBLIC KEY ----".getBytes()); paramOutputStream.write(cr);
/* 154 */       paramOutputStream.write(("Comment: \"" + paramString + "\"").getBytes()); paramOutputStream.write(cr);
/* 155 */       int i = 0;
/* 156 */       while (i < arrayOfByte2.length) {
/* 157 */         int j = 70;
/* 158 */         if (arrayOfByte2.length - i < j) j = arrayOfByte2.length - i; 
/* 159 */         paramOutputStream.write(arrayOfByte2, i, j); paramOutputStream.write(cr);
/* 160 */         i += j;
/*     */       } 
/* 162 */       paramOutputStream.write("---- END SSH2 PUBLIC KEY ----".getBytes()); paramOutputStream.write(cr);
/*     */     }
/* 164 */     catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */   
/*     */   public void writeSECSHPublicKey(String paramString1, String paramString2) throws FileNotFoundException, IOException {
/* 169 */     FileOutputStream fileOutputStream = new FileOutputStream(paramString1);
/* 170 */     writeSECSHPublicKey(fileOutputStream, paramString2);
/* 171 */     fileOutputStream.close();
/*     */   }
/*     */ 
/*     */   
/*     */   public void writePrivateKey(String paramString) throws FileNotFoundException, IOException {
/* 176 */     FileOutputStream fileOutputStream = new FileOutputStream(paramString);
/* 177 */     writePrivateKey(fileOutputStream);
/* 178 */     fileOutputStream.close();
/*     */   }
/*     */   
/*     */   public String getFingerPrint() {
/* 182 */     if (this.hash == null) this.hash = genHash(); 
/* 183 */     byte[] arrayOfByte = getPublicKeyBlob();
/* 184 */     if (arrayOfByte == null) return null; 
/* 185 */     return getKeySize() + " " + Util.getFingerPrint(this.hash, arrayOfByte);
/*     */   }
/*     */   
/*     */   private byte[] encrypt(byte[] paramArrayOfbyte, byte[][] paramArrayOfbyte1) {
/* 189 */     if (this.passphrase == null) return paramArrayOfbyte;
/*     */     
/* 191 */     if (this.cipher == null) this.cipher = genCipher(); 
/* 192 */     byte[] arrayOfByte1 = paramArrayOfbyte1[0] = new byte[this.cipher.getIVSize()];
/*     */     
/* 194 */     if (this.random == null) this.random = genRandom(); 
/* 195 */     this.random.fill(arrayOfByte1, 0, arrayOfByte1.length);
/*     */     
/* 197 */     byte[] arrayOfByte2 = genKey(this.passphrase, arrayOfByte1);
/* 198 */     byte[] arrayOfByte3 = paramArrayOfbyte;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 203 */     int i = this.cipher.getIVSize();
/* 204 */     byte[] arrayOfByte4 = new byte[(arrayOfByte3.length / i + 1) * i];
/* 205 */     System.arraycopy(arrayOfByte3, 0, arrayOfByte4, 0, arrayOfByte3.length);
/* 206 */     int j = i - arrayOfByte3.length % i;
/* 207 */     for (int k = arrayOfByte4.length - 1; arrayOfByte4.length - j <= k; k--) {
/* 208 */       arrayOfByte4[k] = (byte)j;
/*     */     }
/* 210 */     arrayOfByte3 = arrayOfByte4;
/*     */ 
/*     */     
/*     */     try {
/* 214 */       this.cipher.init(0, arrayOfByte2, arrayOfByte1);
/* 215 */       this.cipher.update(arrayOfByte3, 0, arrayOfByte3.length, arrayOfByte3, 0);
/*     */     }
/* 217 */     catch (Exception exception) {}
/*     */ 
/*     */     
/* 220 */     Util.bzero(arrayOfByte2);
/* 221 */     return arrayOfByte3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] decrypt(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[] paramArrayOfbyte3) {
/*     */     try {
/* 234 */       byte[] arrayOfByte1 = genKey(paramArrayOfbyte2, paramArrayOfbyte3);
/* 235 */       this.cipher.init(1, arrayOfByte1, paramArrayOfbyte3);
/* 236 */       Util.bzero(arrayOfByte1);
/* 237 */       byte[] arrayOfByte2 = new byte[paramArrayOfbyte1.length];
/* 238 */       this.cipher.update(paramArrayOfbyte1, 0, paramArrayOfbyte1.length, arrayOfByte2, 0);
/* 239 */       return arrayOfByte2;
/*     */     }
/* 241 */     catch (Exception exception) {
/*     */ 
/*     */       
/* 244 */       return null;
/*     */     } 
/*     */   }
/*     */   int writeSEQUENCE(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
/* 248 */     paramArrayOfbyte[paramInt1++] = 48;
/* 249 */     paramInt1 = writeLength(paramArrayOfbyte, paramInt1, paramInt2);
/* 250 */     return paramInt1;
/*     */   }
/*     */   int writeINTEGER(byte[] paramArrayOfbyte1, int paramInt, byte[] paramArrayOfbyte2) {
/* 253 */     paramArrayOfbyte1[paramInt++] = 2;
/* 254 */     paramInt = writeLength(paramArrayOfbyte1, paramInt, paramArrayOfbyte2.length);
/* 255 */     System.arraycopy(paramArrayOfbyte2, 0, paramArrayOfbyte1, paramInt, paramArrayOfbyte2.length);
/* 256 */     paramInt += paramArrayOfbyte2.length;
/* 257 */     return paramInt;
/*     */   }
/*     */   
/*     */   int countLength(int paramInt) {
/* 261 */     byte b = 1;
/* 262 */     if (paramInt <= 127) return b; 
/* 263 */     while (paramInt > 0) {
/* 264 */       paramInt >>>= 8;
/* 265 */       b++;
/*     */     } 
/* 267 */     return b;
/*     */   }
/*     */   
/*     */   int writeLength(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
/* 271 */     int i = countLength(paramInt2) - 1;
/* 272 */     if (i == 0) {
/* 273 */       paramArrayOfbyte[paramInt1++] = (byte)paramInt2;
/* 274 */       return paramInt1;
/*     */     } 
/* 276 */     paramArrayOfbyte[paramInt1++] = (byte)(0x80 | i);
/* 277 */     int j = paramInt1 + i;
/* 278 */     while (i > 0) {
/* 279 */       paramArrayOfbyte[paramInt1 + i - 1] = (byte)(paramInt2 & 0xFF);
/* 280 */       paramInt2 >>>= 8;
/* 281 */       i--;
/*     */     } 
/* 283 */     return j;
/*     */   }
/*     */   
/*     */   private Random genRandom() {
/* 287 */     if (this.random == null)
/*     */       try {
/* 289 */         this; Class clazz = Class.forName(JSch.getConfig("random"));
/* 290 */         this.random = (Random)clazz.newInstance();
/*     */       } catch (Exception exception) {
/* 292 */         System.err.println("connect: random " + exception);
/*     */       }  
/* 294 */     return this.random;
/*     */   }
/*     */   
/*     */   private HASH genHash() {
/*     */     try {
/* 299 */       this; Class clazz = Class.forName(JSch.getConfig("md5"));
/* 300 */       this.hash = (HASH)clazz.newInstance();
/* 301 */       this.hash.init();
/*     */     }
/* 303 */     catch (Exception exception) {}
/*     */     
/* 305 */     return this.hash;
/*     */   }
/*     */   
/*     */   private Cipher genCipher() {
/*     */     try {
/* 310 */       this; Class clazz = Class.forName(JSch.getConfig("3des-cbc"));
/* 311 */       this.cipher = (Cipher)clazz.newInstance();
/*     */     }
/* 313 */     catch (Exception exception) {}
/*     */     
/* 315 */     return this.cipher;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   synchronized byte[] genKey(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) {
/* 325 */     if (this.cipher == null) this.cipher = genCipher(); 
/* 326 */     if (this.hash == null) this.hash = genHash();
/*     */     
/* 328 */     byte[] arrayOfByte1 = new byte[this.cipher.getBlockSize()];
/* 329 */     int i = this.hash.getBlockSize();
/* 330 */     byte[] arrayOfByte2 = new byte[arrayOfByte1.length / i * i + ((arrayOfByte1.length % i == 0) ? 0 : i)];
/*     */     
/*     */     try {
/* 333 */       byte[] arrayOfByte = null;
/* 334 */       if (this.vendor == 0) {
/* 335 */         for (int j = 0; j + i <= arrayOfByte2.length; ) {
/* 336 */           if (arrayOfByte != null) this.hash.update(arrayOfByte, 0, arrayOfByte.length); 
/* 337 */           this.hash.update(paramArrayOfbyte1, 0, paramArrayOfbyte1.length);
/* 338 */           this.hash.update(paramArrayOfbyte2, 0, paramArrayOfbyte2.length);
/* 339 */           arrayOfByte = this.hash.digest();
/* 340 */           System.arraycopy(arrayOfByte, 0, arrayOfByte2, j, arrayOfByte.length);
/* 341 */           j += arrayOfByte.length;
/*     */         } 
/* 343 */         System.arraycopy(arrayOfByte2, 0, arrayOfByte1, 0, arrayOfByte1.length);
/*     */       }
/* 345 */       else if (this.vendor == 1) {
/* 346 */         for (int j = 0; j + i <= arrayOfByte2.length; ) {
/* 347 */           if (arrayOfByte != null) this.hash.update(arrayOfByte, 0, arrayOfByte.length); 
/* 348 */           this.hash.update(paramArrayOfbyte1, 0, paramArrayOfbyte1.length);
/* 349 */           arrayOfByte = this.hash.digest();
/* 350 */           System.arraycopy(arrayOfByte, 0, arrayOfByte2, j, arrayOfByte.length);
/* 351 */           j += arrayOfByte.length;
/*     */         } 
/* 353 */         System.arraycopy(arrayOfByte2, 0, arrayOfByte1, 0, arrayOfByte1.length);
/*     */       } 
/*     */     } catch (Exception exception) {
/*     */       
/* 357 */       System.err.println(exception);
/*     */     } 
/* 359 */     return arrayOfByte1;
/*     */   }
/*     */   
/*     */   public void setPassphrase(String paramString) {
/* 363 */     if (paramString == null || paramString.length() == 0) {
/* 364 */       setPassphrase((byte[])null);
/*     */     } else {
/*     */       
/* 367 */       setPassphrase(Util.str2byte(paramString));
/*     */     } 
/*     */   }
/*     */   public void setPassphrase(byte[] paramArrayOfbyte) {
/* 371 */     if (paramArrayOfbyte != null && paramArrayOfbyte.length == 0)
/* 372 */       paramArrayOfbyte = null; 
/* 373 */     this.passphrase = paramArrayOfbyte;
/*     */   }
/*     */   
/* 376 */   public KeyPair(JSch paramJSch) { this.encrypted = false;
/* 377 */     this.data = null;
/* 378 */     this.iv = null;
/* 379 */     this.publickeyblob = null;
/*     */     this.jsch = paramJSch; } public boolean isEncrypted() {
/* 381 */     return this.encrypted;
/*     */   } public boolean decrypt(String paramString) {
/* 383 */     if (paramString == null || paramString.length() == 0) {
/* 384 */       return !this.encrypted;
/*     */     }
/* 386 */     return decrypt(Util.str2byte(paramString));
/*     */   }
/*     */   public boolean decrypt(byte[] paramArrayOfbyte) {
/* 389 */     if (!this.encrypted) {
/* 390 */       return true;
/*     */     }
/* 392 */     if (paramArrayOfbyte == null) {
/* 393 */       return !this.encrypted;
/*     */     }
/* 395 */     byte[] arrayOfByte1 = new byte[paramArrayOfbyte.length];
/* 396 */     System.arraycopy(paramArrayOfbyte, 0, arrayOfByte1, 0, arrayOfByte1.length);
/* 397 */     paramArrayOfbyte = arrayOfByte1;
/* 398 */     byte[] arrayOfByte2 = decrypt(this.data, paramArrayOfbyte, this.iv);
/* 399 */     Util.bzero(paramArrayOfbyte);
/* 400 */     if (parse(arrayOfByte2)) {
/* 401 */       this.encrypted = false;
/*     */     }
/* 403 */     return !this.encrypted;
/*     */   }
/*     */   
/*     */   public static KeyPair load(JSch paramJSch, String paramString) throws JSchException {
/* 407 */     String str = paramString + ".pub";
/* 408 */     if (!(new File(str)).exists()) {
/* 409 */       str = null;
/*     */     }
/* 411 */     return load(paramJSch, paramString, str);
/*     */   }
/*     */   public static KeyPair load(JSch paramJSch, String paramString1, String paramString2) throws JSchException {
/*     */     KeyPairRSA keyPairRSA;
/* 415 */     byte[] arrayOfByte1 = new byte[8];
/* 416 */     boolean bool1 = true;
/* 417 */     byte[] arrayOfByte2 = null;
/*     */     
/* 419 */     byte[] arrayOfByte3 = null;
/*     */     
/* 421 */     byte b = 0;
/* 422 */     boolean bool2 = false;
/*     */     
/*     */     try {
/* 425 */       File file = new File(paramString1);
/* 426 */       FileInputStream fileInputStream = new FileInputStream(paramString1);
/* 427 */       byte[] arrayOfByte = new byte[(int)file.length()];
/* 428 */       int i = 0;
/*     */       while (true) {
/* 430 */         int m = fileInputStream.read(arrayOfByte, i, arrayOfByte.length - i);
/* 431 */         if (m <= 0)
/*     */           break; 
/* 433 */         i += m;
/*     */       } 
/* 435 */       fileInputStream.close();
/*     */       
/* 437 */       int j = 0;
/*     */       
/* 439 */       while (j < i) {
/* 440 */         if (arrayOfByte[j] == 66 && arrayOfByte[j + 1] == 69 && arrayOfByte[j + 2] == 71 && arrayOfByte[j + 3] == 73) {
/* 441 */           j += 6;
/* 442 */           if (arrayOfByte[j] == 68 && arrayOfByte[j + 1] == 83 && arrayOfByte[j + 2] == 65) { b = 1; }
/* 443 */           else if (arrayOfByte[j] == 82 && arrayOfByte[j + 1] == 83 && arrayOfByte[j + 2] == 65) { b = 2; }
/* 444 */           else if (arrayOfByte[j] == 83 && arrayOfByte[j + 1] == 83 && arrayOfByte[j + 2] == 72)
/* 445 */           { b = 3;
/* 446 */             bool2 = true; }
/*     */           
/*     */           else
/*     */           
/* 450 */           { throw new JSchException("invalid privatekey: " + paramString1); }
/*     */           
/* 452 */           j += 3;
/*     */           continue;
/*     */         } 
/* 455 */         if (arrayOfByte[j] == 67 && arrayOfByte[j + 1] == 66 && arrayOfByte[j + 2] == 67 && arrayOfByte[j + 3] == 44) {
/* 456 */           j += 4;
/* 457 */           for (byte b1 = 0; b1 < arrayOfByte1.length; b1++) {
/* 458 */             arrayOfByte1[b1] = (byte)((a2b(arrayOfByte[j++]) << 4 & 0xF0) + (a2b(arrayOfByte[j++]) & 0xF));
/*     */           }
/*     */           continue;
/*     */         } 
/* 462 */         if (arrayOfByte[j] == 13 && j + 1 < arrayOfByte.length && arrayOfByte[j + 1] == 10) {
/*     */           
/* 464 */           j++;
/*     */           continue;
/*     */         } 
/* 467 */         if (arrayOfByte[j] == 10 && j + 1 < arrayOfByte.length) {
/* 468 */           if (arrayOfByte[j + 1] == 10) { j += 2; break; }
/* 469 */            if (arrayOfByte[j + 1] == 13 && j + 2 < arrayOfByte.length && arrayOfByte[j + 2] == 10) {
/*     */             
/* 471 */             j += 3; break;
/*     */           } 
/* 473 */           boolean bool = false;
/* 474 */           for (int m = j + 1; m < arrayOfByte.length && 
/* 475 */             arrayOfByte[m] != 10; m++) {
/*     */             
/* 477 */             if (arrayOfByte[m] == 58) { bool = true; break; }
/*     */           
/* 479 */           }  if (!bool) {
/* 480 */             j++;
/* 481 */             bool1 = false;
/*     */             break;
/*     */           } 
/*     */         } 
/* 485 */         j++;
/*     */       } 
/*     */       
/* 488 */       if (b == 0) {
/* 489 */         throw new JSchException("invalid privatekey: " + paramString1);
/*     */       }
/*     */       
/* 492 */       int k = j;
/* 493 */       while (j < i) {
/* 494 */         if (arrayOfByte[j] == 10) {
/* 495 */           boolean bool = (arrayOfByte[j - 1] == 13) ? true : false;
/* 496 */           System.arraycopy(arrayOfByte, j + 1, arrayOfByte, j - (bool ? 1 : 0), i - j - 1 - (bool ? 1 : 0));
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 501 */           if (bool) i--; 
/* 502 */           i--;
/*     */           continue;
/*     */         } 
/* 505 */         if (arrayOfByte[j] == 45)
/* 506 */           break;  j++;
/*     */       } 
/* 508 */       arrayOfByte2 = Util.fromBase64(arrayOfByte, k, j - k);
/*     */       
/* 510 */       if (arrayOfByte2.length > 4 && arrayOfByte2[0] == 63 && arrayOfByte2[1] == 111 && arrayOfByte2[2] == -7 && arrayOfByte2[3] == -21) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 516 */         Buffer buffer = new Buffer(arrayOfByte2);
/* 517 */         buffer.getInt();
/* 518 */         buffer.getInt();
/* 519 */         byte[] arrayOfByte4 = buffer.getString();
/*     */         
/* 521 */         byte[] arrayOfByte5 = buffer.getString();
/* 522 */         String str = new String(arrayOfByte5);
/*     */         
/* 524 */         if (str.equals("3des-cbc")) {
/* 525 */           buffer.getInt();
/* 526 */           byte[] arrayOfByte6 = new byte[arrayOfByte2.length - buffer.getOffSet()];
/* 527 */           buffer.getByte(arrayOfByte6);
/* 528 */           arrayOfByte2 = arrayOfByte6;
/* 529 */           bool1 = true;
/* 530 */           throw new JSchException("unknown privatekey format: " + paramString1);
/*     */         } 
/* 532 */         if (str.equals("none")) {
/* 533 */           buffer.getInt();
/* 534 */           buffer.getInt();
/*     */           
/* 536 */           bool1 = false;
/*     */           
/* 538 */           byte[] arrayOfByte6 = new byte[arrayOfByte2.length - buffer.getOffSet()];
/* 539 */           buffer.getByte(arrayOfByte6);
/* 540 */           arrayOfByte2 = arrayOfByte6;
/*     */         } 
/*     */       } 
/*     */       
/* 544 */       if (paramString2 != null) {
/*     */         try {
/* 546 */           file = new File(paramString2);
/* 547 */           fileInputStream = new FileInputStream(paramString2);
/* 548 */           arrayOfByte = new byte[(int)file.length()];
/* 549 */           i = 0;
/*     */           while (true) {
/* 551 */             j = fileInputStream.read(arrayOfByte, i, arrayOfByte.length - i);
/* 552 */             if (j <= 0)
/*     */               break; 
/* 554 */             i += j;
/*     */           } 
/* 556 */           fileInputStream.close();
/*     */           
/* 558 */           if (arrayOfByte.length > 4 && arrayOfByte[0] == 45 && arrayOfByte[1] == 45 && arrayOfByte[2] == 45 && arrayOfByte[3] == 45) {
/*     */ 
/*     */             
/* 561 */             boolean bool = true;
/* 562 */             j = 0; 
/* 563 */             do { j++; } while (arrayOfByte.length > j && arrayOfByte[j] != 10);
/* 564 */             if (arrayOfByte.length <= j) bool = false;
/*     */             
/* 566 */             while (bool) {
/* 567 */               if (arrayOfByte[j] == 10) {
/* 568 */                 boolean bool3 = false;
/* 569 */                 for (int m = j + 1; m < arrayOfByte.length && 
/* 570 */                   arrayOfByte[m] != 10; m++) {
/* 571 */                   if (arrayOfByte[m] == 58) { bool3 = true; break; }
/*     */                 
/* 573 */                 }  if (!bool3) {
/* 574 */                   j++;
/*     */                   break;
/*     */                 } 
/*     */               } 
/* 578 */               j++;
/*     */             } 
/* 580 */             if (arrayOfByte.length <= j) bool = false;
/*     */             
/* 582 */             k = j;
/* 583 */             while (bool && j < i) {
/* 584 */               if (arrayOfByte[j] == 10) {
/* 585 */                 System.arraycopy(arrayOfByte, j + 1, arrayOfByte, j, i - j - 1);
/* 586 */                 i--;
/*     */                 continue;
/*     */               } 
/* 589 */               if (arrayOfByte[j] == 45)
/* 590 */                 break;  j++;
/*     */             } 
/* 592 */             if (bool) {
/* 593 */               arrayOfByte3 = Util.fromBase64(arrayOfByte, k, j - k);
/* 594 */               if (b == 3) {
/* 595 */                 if (arrayOfByte3[8] == 100) { b = 1; }
/* 596 */                 else if (arrayOfByte3[8] == 114) { b = 2; }
/*     */ 
/*     */               
/*     */               }
/*     */             } 
/* 601 */           } else if (arrayOfByte[0] == 115 && arrayOfByte[1] == 115 && arrayOfByte[2] == 104 && arrayOfByte[3] == 45) {
/* 602 */             j = 0;
/* 603 */             for (; j < i && arrayOfByte[j] != 32; j++); j++;
/* 604 */             if (j < i) {
/* 605 */               k = j;
/* 606 */               for (; j < i && arrayOfByte[j] != 32; j++);
/* 607 */               arrayOfByte3 = Util.fromBase64(arrayOfByte, k, j - k);
/*     */             }
/*     */           
/*     */           }
/*     */         
/* 612 */         } catch (Exception exception) {}
/*     */       }
/*     */     }
/*     */     catch (Exception exception) {
/*     */       
/* 617 */       if (exception instanceof JSchException) throw (JSchException)exception; 
/* 618 */       if (exception instanceof Throwable)
/* 619 */         throw new JSchException(exception.toString(), exception); 
/* 620 */       throw new JSchException(exception.toString());
/*     */     } 
/*     */     
/* 623 */     KeyPairDSA keyPairDSA = null;
/* 624 */     if (b == 1) { keyPairDSA = new KeyPairDSA(paramJSch); }
/* 625 */     else if (b == 2) { keyPairRSA = new KeyPairRSA(paramJSch); }
/*     */     
/* 627 */     if (keyPairRSA != null) {
/* 628 */       keyPairRSA.encrypted = bool1;
/* 629 */       keyPairRSA.publickeyblob = arrayOfByte3;
/* 630 */       keyPairRSA.vendor = bool2;
/*     */       
/* 632 */       if (bool1) {
/* 633 */         keyPairRSA.iv = arrayOfByte1;
/* 634 */         keyPairRSA.data = arrayOfByte2;
/*     */       } else {
/*     */         
/* 637 */         if (keyPairRSA.parse(arrayOfByte2)) {
/* 638 */           return keyPairRSA;
/*     */         }
/*     */         
/* 641 */         throw new JSchException("invalid privatekey: " + paramString1);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 646 */     return keyPairRSA;
/*     */   }
/*     */   
/*     */   private static byte a2b(byte paramByte) {
/* 650 */     if (48 <= paramByte && paramByte <= 57) return (byte)(paramByte - 48); 
/* 651 */     return (byte)(paramByte - 97 + 10);
/*     */   }
/*     */   private static byte b2a(byte paramByte) {
/* 654 */     if (0 <= paramByte && paramByte <= 9) return (byte)(paramByte + 48); 
/* 655 */     return (byte)(paramByte - 10 + 65);
/*     */   }
/*     */   
/*     */   public void dispose() {
/* 659 */     Util.bzero(this.passphrase);
/*     */   }
/*     */   
/*     */   public void finalize() {
/* 663 */     dispose();
/*     */   }
/*     */   
/*     */   abstract void generate(int paramInt) throws JSchException;
/*     */   
/*     */   abstract byte[] getBegin();
/*     */   
/*     */   abstract byte[] getEnd();
/*     */   
/*     */   abstract int getKeySize();
/*     */   
/*     */   abstract byte[] getPrivateKey();
/*     */   
/*     */   abstract byte[] getKeyTypeName();
/*     */   
/*     */   public abstract int getKeyType();
/*     */   
/*     */   abstract boolean parse(byte[] paramArrayOfbyte);
/*     */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/KeyPair.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */