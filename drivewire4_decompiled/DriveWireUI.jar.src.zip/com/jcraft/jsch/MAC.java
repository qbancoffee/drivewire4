package com.jcraft.jsch;

public interface MAC {
  String getName();
  
  int getBlockSize();
  
  void init(byte[] paramArrayOfbyte) throws Exception;
  
  void update(byte[] paramArrayOfbyte, int paramInt1, int paramInt2);
  
  void update(int paramInt);
  
  void doFinal(byte[] paramArrayOfbyte, int paramInt);
}


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/MAC.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */