/*    */ package com.jcraft.jsch;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class RequestSignal
/*    */   extends Request
/*    */ {
/* 33 */   private String signal = "KILL"; public void setSignal(String paramString) {
/* 34 */     this.signal = paramString;
/*    */   } public void request(Session paramSession, Channel paramChannel) throws Exception {
/* 36 */     super.request(paramSession, paramChannel);
/*    */     
/* 38 */     Buffer buffer = new Buffer();
/* 39 */     Packet packet = new Packet(buffer);
/*    */     
/* 41 */     packet.reset();
/* 42 */     buffer.putByte((byte)98);
/* 43 */     buffer.putInt(paramChannel.getRecipient());
/* 44 */     buffer.putString("signal".getBytes());
/* 45 */     buffer.putByte((byte)(waitForReply() ? 1 : 0));
/* 46 */     buffer.putString(this.signal.getBytes());
/* 47 */     write(packet);
/*    */   }
/*    */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/RequestSignal.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */