/*     */ package com.jcraft.jsch;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class HostKey
/*     */ {
/*  33 */   private static final byte[] sshdss = "ssh-dss".getBytes();
/*  34 */   private static final byte[] sshrsa = "ssh-rsa".getBytes();
/*     */   
/*     */   protected static final int GUESS = 0;
/*     */   
/*     */   public static final int SSHDSS = 1;
/*     */   public static final int SSHRSA = 2;
/*     */   static final int UNKNOWN = 3;
/*     */   protected String host;
/*     */   protected int type;
/*     */   protected byte[] key;
/*     */   
/*     */   public HostKey(String paramString, byte[] paramArrayOfbyte) throws JSchException {
/*  46 */     this(paramString, 0, paramArrayOfbyte);
/*     */   }
/*     */   
/*     */   public HostKey(String paramString, int paramInt, byte[] paramArrayOfbyte) throws JSchException {
/*  50 */     this.host = paramString;
/*  51 */     if (paramInt == 0) {
/*  52 */       if (paramArrayOfbyte[8] == 100) { this.type = 1; }
/*  53 */       else if (paramArrayOfbyte[8] == 114) { this.type = 2; }
/*  54 */       else { throw new JSchException("invalid key type"); }
/*     */     
/*     */     } else {
/*  57 */       this.type = paramInt;
/*     */     } 
/*  59 */     this.key = paramArrayOfbyte;
/*     */   }
/*     */   public String getHost() {
/*  62 */     return this.host;
/*     */   } public String getType() {
/*  64 */     if (this.type == 1) return new String(sshdss); 
/*  65 */     if (this.type == 2) return new String(sshrsa); 
/*  66 */     return "UNKNOWN";
/*     */   }
/*     */   public String getKey() {
/*  69 */     return new String(Util.toBase64(this.key, 0, this.key.length));
/*     */   }
/*     */   public String getFingerPrint(JSch paramJSch) {
/*  72 */     HASH hASH = null;
/*     */     try {
/*  74 */       Class clazz = Class.forName(JSch.getConfig("md5"));
/*  75 */       hASH = (HASH)clazz.newInstance();
/*     */     } catch (Exception exception) {
/*  77 */       System.err.println("getFingerPrint: " + exception);
/*  78 */     }  return Util.getFingerPrint(hASH, this.key);
/*     */   }
/*     */   
/*     */   boolean isMatched(String paramString) {
/*  82 */     return isIncluded(paramString);
/*     */   }
/*     */   
/*     */   private boolean isIncluded(String paramString) {
/*  86 */     int i = 0;
/*  87 */     String str = this.host;
/*  88 */     int j = str.length();
/*  89 */     int k = paramString.length();
/*     */     
/*  91 */     while (i < j) {
/*  92 */       int m = str.indexOf(',', i);
/*  93 */       if (m == -1) {
/*  94 */         if (k != j - i) return false; 
/*  95 */         return str.regionMatches(true, i, paramString, 0, k);
/*     */       } 
/*  97 */       if (k == m - i && 
/*  98 */         str.regionMatches(true, i, paramString, 0, k)) return true;
/*     */       
/* 100 */       i = m + 1;
/*     */     } 
/* 102 */     return false;
/*     */   }
/*     */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/HostKey.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */