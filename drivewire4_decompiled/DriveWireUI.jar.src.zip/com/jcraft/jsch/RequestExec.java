/*    */ package com.jcraft.jsch;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class RequestExec
/*    */   extends Request
/*    */ {
/* 33 */   private byte[] command = new byte[0];
/*    */   RequestExec(byte[] paramArrayOfbyte) {
/* 35 */     this.command = paramArrayOfbyte;
/*    */   }
/*    */   public void request(Session paramSession, Channel paramChannel) throws Exception {
/* 38 */     super.request(paramSession, paramChannel);
/*    */     
/* 40 */     Buffer buffer = new Buffer();
/* 41 */     Packet packet = new Packet(buffer);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 49 */     packet.reset();
/* 50 */     buffer.putByte((byte)98);
/* 51 */     buffer.putInt(paramChannel.getRecipient());
/* 52 */     buffer.putString("exec".getBytes());
/* 53 */     buffer.putByte((byte)(waitForReply() ? 1 : 0));
/* 54 */     buffer.putString(this.command);
/* 55 */     write(packet);
/*    */   }
/*    */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/RequestExec.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */