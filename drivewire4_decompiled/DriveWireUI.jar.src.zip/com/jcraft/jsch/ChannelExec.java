/*    */ package com.jcraft.jsch;
/*    */ 
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.io.OutputStream;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ChannelExec
/*    */   extends ChannelSession
/*    */ {
/* 36 */   byte[] command = new byte[0];
/*    */   
/*    */   public void start() throws JSchException {
/* 39 */     Session session = getSession();
/*    */     try {
/* 41 */       sendRequests();
/* 42 */       RequestExec requestExec = new RequestExec(this.command);
/* 43 */       requestExec.request(session, this);
/*    */     } catch (Exception exception) {
/*    */       
/* 46 */       if (exception instanceof JSchException) throw (JSchException)exception; 
/* 47 */       if (exception instanceof Throwable)
/* 48 */         throw new JSchException("ChannelExec", exception); 
/* 49 */       throw new JSchException("ChannelExec");
/*    */     } 
/*    */     
/* 52 */     if (this.io.in != null) {
/* 53 */       this.thread = new Thread(this);
/* 54 */       this.thread.setName("Exec thread " + session.getHost());
/* 55 */       if (session.daemon_thread) {
/* 56 */         this.thread.setDaemon(session.daemon_thread);
/*    */       }
/* 58 */       this.thread.start();
/*    */     } 
/*    */   }
/*    */   
/*    */   public void setCommand(String paramString) {
/* 63 */     this.command = paramString.getBytes();
/*    */   }
/*    */   public void setCommand(byte[] paramArrayOfbyte) {
/* 66 */     this.command = paramArrayOfbyte;
/*    */   }
/*    */   
/*    */   void init() throws JSchException {
/* 70 */     this.io.setInputStream((getSession()).in);
/* 71 */     this.io.setOutputStream((getSession()).out);
/*    */   }
/*    */   
/*    */   public void setErrStream(OutputStream paramOutputStream) {
/* 75 */     setExtOutputStream(paramOutputStream);
/*    */   }
/*    */   public void setErrStream(OutputStream paramOutputStream, boolean paramBoolean) {
/* 78 */     setExtOutputStream(paramOutputStream, paramBoolean);
/*    */   }
/*    */   public InputStream getErrStream() throws IOException {
/* 81 */     return getExtInputStream();
/*    */   }
/*    */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/ChannelExec.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */