package com.jcraft.jsch;

public interface KeyPairGenDSA {
  void init(int paramInt) throws Exception;
  
  byte[] getX();
  
  byte[] getY();
  
  byte[] getP();
  
  byte[] getQ();
  
  byte[] getG();
}


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/KeyPairGenDSA.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */