/*     */ package com.jcraft.jsch;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class KeyPairRSA
/*     */   extends KeyPair
/*     */ {
/*     */   private byte[] prv_array;
/*     */   private byte[] pub_array;
/*     */   private byte[] n_array;
/*     */   private byte[] p_array;
/*     */   private byte[] q_array;
/*     */   private byte[] ep_array;
/*     */   private byte[] eq_array;
/*     */   private byte[] c_array;
/*  44 */   private int key_size = 1024;
/*     */   
/*     */   public KeyPairRSA(JSch paramJSch) {
/*  47 */     super(paramJSch);
/*     */   }
/*     */   
/*     */   void generate(int paramInt) throws JSchException {
/*  51 */     this.key_size = paramInt;
/*     */     try {
/*  53 */       this; Class clazz = Class.forName(JSch.getConfig("keypairgen.rsa"));
/*  54 */       KeyPairGenRSA keyPairGenRSA = (KeyPairGenRSA)clazz.newInstance();
/*  55 */       keyPairGenRSA.init(paramInt);
/*  56 */       this.pub_array = keyPairGenRSA.getE();
/*  57 */       this.prv_array = keyPairGenRSA.getD();
/*  58 */       this.n_array = keyPairGenRSA.getN();
/*     */       
/*  60 */       this.p_array = keyPairGenRSA.getP();
/*  61 */       this.q_array = keyPairGenRSA.getQ();
/*  62 */       this.ep_array = keyPairGenRSA.getEP();
/*  63 */       this.eq_array = keyPairGenRSA.getEQ();
/*  64 */       this.c_array = keyPairGenRSA.getC();
/*     */       
/*  66 */       keyPairGenRSA = null;
/*     */     }
/*     */     catch (Exception exception) {
/*     */       
/*  70 */       if (exception instanceof Throwable)
/*  71 */         throw new JSchException(exception.toString(), exception); 
/*  72 */       throw new JSchException(exception.toString());
/*     */     } 
/*     */   }
/*     */   
/*  76 */   private static final byte[] begin = "-----BEGIN RSA PRIVATE KEY-----".getBytes();
/*  77 */   private static final byte[] end = "-----END RSA PRIVATE KEY-----".getBytes();
/*     */   
/*  79 */   byte[] getBegin() { return begin; } byte[] getEnd() {
/*  80 */     return end;
/*     */   }
/*     */   byte[] getPrivateKey() {
/*  83 */     int i = 1 + countLength(1) + 1 + 1 + countLength(this.n_array.length) + this.n_array.length + 1 + countLength(this.pub_array.length) + this.pub_array.length + 1 + countLength(this.prv_array.length) + this.prv_array.length + 1 + countLength(this.p_array.length) + this.p_array.length + 1 + countLength(this.q_array.length) + this.q_array.length + 1 + countLength(this.ep_array.length) + this.ep_array.length + 1 + countLength(this.eq_array.length) + this.eq_array.length + 1 + countLength(this.c_array.length) + this.c_array.length;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  94 */     int j = 1 + countLength(i) + i;
/*     */ 
/*     */     
/*  97 */     byte[] arrayOfByte = new byte[j];
/*  98 */     int k = 0;
/*  99 */     k = writeSEQUENCE(arrayOfByte, k, i);
/* 100 */     k = writeINTEGER(arrayOfByte, k, new byte[1]);
/* 101 */     k = writeINTEGER(arrayOfByte, k, this.n_array);
/* 102 */     k = writeINTEGER(arrayOfByte, k, this.pub_array);
/* 103 */     k = writeINTEGER(arrayOfByte, k, this.prv_array);
/* 104 */     k = writeINTEGER(arrayOfByte, k, this.p_array);
/* 105 */     k = writeINTEGER(arrayOfByte, k, this.q_array);
/* 106 */     k = writeINTEGER(arrayOfByte, k, this.ep_array);
/* 107 */     k = writeINTEGER(arrayOfByte, k, this.eq_array);
/* 108 */     k = writeINTEGER(arrayOfByte, k, this.c_array);
/* 109 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean parse(byte[] paramArrayOfbyte) {
/*     */     try {
/* 121 */       int i = 0;
/* 122 */       int j = 0;
/*     */       
/* 124 */       if (this.vendor == 1) {
/* 125 */         if (paramArrayOfbyte[i] != 48) {
/* 126 */           Buffer buffer = new Buffer(paramArrayOfbyte);
/* 127 */           this.pub_array = buffer.getMPIntBits();
/* 128 */           this.prv_array = buffer.getMPIntBits();
/* 129 */           this.n_array = buffer.getMPIntBits();
/* 130 */           byte[] arrayOfByte = buffer.getMPIntBits();
/* 131 */           this.p_array = buffer.getMPIntBits();
/* 132 */           this.q_array = buffer.getMPIntBits();
/* 133 */           return true;
/*     */         } 
/* 135 */         return false;
/*     */       } 
/*     */       
/* 138 */       i++;
/* 139 */       j = paramArrayOfbyte[i++] & 0xFF;
/* 140 */       if ((j & 0x80) != 0) {
/* 141 */         int k = j & 0x7F; j = 0;
/* 142 */         for (; k-- > 0; j = (j << 8) + (paramArrayOfbyte[i++] & 0xFF));
/*     */       } 
/*     */       
/* 145 */       if (paramArrayOfbyte[i] != 2) return false; 
/* 146 */       i++;
/* 147 */       j = paramArrayOfbyte[i++] & 0xFF;
/* 148 */       if ((j & 0x80) != 0) {
/* 149 */         int k = j & 0x7F; j = 0;
/* 150 */         for (; k-- > 0; j = (j << 8) + (paramArrayOfbyte[i++] & 0xFF));
/*     */       } 
/* 152 */       i += j;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 158 */       i++;
/* 159 */       j = paramArrayOfbyte[i++] & 0xFF;
/* 160 */       if ((j & 0x80) != 0) {
/* 161 */         int k = j & 0x7F; j = 0;
/* 162 */         for (; k-- > 0; j = (j << 8) + (paramArrayOfbyte[i++] & 0xFF));
/*     */       } 
/* 164 */       this.n_array = new byte[j];
/* 165 */       System.arraycopy(paramArrayOfbyte, i, this.n_array, 0, j);
/* 166 */       i += j;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 174 */       i++;
/* 175 */       j = paramArrayOfbyte[i++] & 0xFF;
/* 176 */       if ((j & 0x80) != 0) {
/* 177 */         int k = j & 0x7F; j = 0;
/* 178 */         for (; k-- > 0; j = (j << 8) + (paramArrayOfbyte[i++] & 0xFF));
/*     */       } 
/* 180 */       this.pub_array = new byte[j];
/* 181 */       System.arraycopy(paramArrayOfbyte, i, this.pub_array, 0, j);
/* 182 */       i += j;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 190 */       i++;
/* 191 */       j = paramArrayOfbyte[i++] & 0xFF;
/* 192 */       if ((j & 0x80) != 0) {
/* 193 */         int k = j & 0x7F; j = 0;
/* 194 */         for (; k-- > 0; j = (j << 8) + (paramArrayOfbyte[i++] & 0xFF));
/*     */       } 
/* 196 */       this.prv_array = new byte[j];
/* 197 */       System.arraycopy(paramArrayOfbyte, i, this.prv_array, 0, j);
/* 198 */       i += j;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 207 */       i++;
/* 208 */       j = paramArrayOfbyte[i++] & 0xFF;
/* 209 */       if ((j & 0x80) != 0) {
/* 210 */         int k = j & 0x7F; j = 0;
/* 211 */         for (; k-- > 0; j = (j << 8) + (paramArrayOfbyte[i++] & 0xFF));
/*     */       } 
/* 213 */       this.p_array = new byte[j];
/* 214 */       System.arraycopy(paramArrayOfbyte, i, this.p_array, 0, j);
/* 215 */       i += j;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 223 */       i++;
/* 224 */       j = paramArrayOfbyte[i++] & 0xFF;
/* 225 */       if ((j & 0x80) != 0) {
/* 226 */         int k = j & 0x7F; j = 0;
/* 227 */         for (; k-- > 0; j = (j << 8) + (paramArrayOfbyte[i++] & 0xFF));
/*     */       } 
/* 229 */       this.q_array = new byte[j];
/* 230 */       System.arraycopy(paramArrayOfbyte, i, this.q_array, 0, j);
/* 231 */       i += j;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 239 */       i++;
/* 240 */       j = paramArrayOfbyte[i++] & 0xFF;
/* 241 */       if ((j & 0x80) != 0) {
/* 242 */         int k = j & 0x7F; j = 0;
/* 243 */         for (; k-- > 0; j = (j << 8) + (paramArrayOfbyte[i++] & 0xFF));
/*     */       } 
/* 245 */       this.ep_array = new byte[j];
/* 246 */       System.arraycopy(paramArrayOfbyte, i, this.ep_array, 0, j);
/* 247 */       i += j;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 255 */       i++;
/* 256 */       j = paramArrayOfbyte[i++] & 0xFF;
/* 257 */       if ((j & 0x80) != 0) {
/* 258 */         int k = j & 0x7F; j = 0;
/* 259 */         for (; k-- > 0; j = (j << 8) + (paramArrayOfbyte[i++] & 0xFF));
/*     */       } 
/* 261 */       this.eq_array = new byte[j];
/* 262 */       System.arraycopy(paramArrayOfbyte, i, this.eq_array, 0, j);
/* 263 */       i += j;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 271 */       i++;
/* 272 */       j = paramArrayOfbyte[i++] & 0xFF;
/* 273 */       if ((j & 0x80) != 0) {
/* 274 */         int k = j & 0x7F; j = 0;
/* 275 */         for (; k-- > 0; j = (j << 8) + (paramArrayOfbyte[i++] & 0xFF));
/*     */       } 
/* 277 */       this.c_array = new byte[j];
/* 278 */       System.arraycopy(paramArrayOfbyte, i, this.c_array, 0, j);
/* 279 */       i += j;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/*     */     catch (Exception exception) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 290 */       return false;
/*     */     } 
/* 292 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public byte[] getPublicKeyBlob() {
/* 297 */     byte[] arrayOfByte = super.getPublicKeyBlob();
/* 298 */     if (arrayOfByte != null) return arrayOfByte;
/*     */     
/* 300 */     if (this.pub_array == null) return null;
/*     */     
/* 302 */     Buffer buffer = new Buffer(sshrsa.length + 4 + this.pub_array.length + 4 + this.n_array.length + 4);
/*     */ 
/*     */     
/* 305 */     buffer.putString(sshrsa);
/* 306 */     buffer.putString(this.pub_array);
/* 307 */     buffer.putString(this.n_array);
/* 308 */     return buffer.buffer;
/*     */   }
/*     */   
/* 311 */   private static final byte[] sshrsa = "ssh-rsa".getBytes();
/* 312 */   byte[] getKeyTypeName() { return sshrsa; } public int getKeyType() {
/* 313 */     return 2;
/*     */   } public int getKeySize() {
/* 315 */     return this.key_size;
/*     */   } public void dispose() {
/* 317 */     super.dispose();
/* 318 */     Util.bzero(this.prv_array);
/*     */   }
/*     */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/KeyPairRSA.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */