/*     */ package com.jcraft.jsch;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class ChannelAgentForwarding
/*     */   extends Channel
/*     */ {
/*     */   private static final int LOCAL_WINDOW_SIZE_MAX = 131072;
/*     */   private static final int LOCAL_MAXIMUM_PACKET_SIZE = 16384;
/*  40 */   private final int SSH2_AGENTC_REQUEST_IDENTITIES = 11;
/*  41 */   private final int SSH2_AGENT_IDENTITIES_ANSWER = 12;
/*  42 */   private final int SSH2_AGENTC_SIGN_REQUEST = 13;
/*  43 */   private final int SSH2_AGENT_SIGN_RESPONSE = 14;
/*  44 */   private final int SSH2_AGENTC_ADD_IDENTITY = 17;
/*  45 */   private final int SSH2_AGENTC_REMOVE_IDENTITY = 18;
/*  46 */   private final int SSH2_AGENTC_REMOVE_ALL_IDENTITIES = 19;
/*  47 */   private final int SSH2_AGENT_FAILURE = 30;
/*     */   
/*     */   boolean init = true;
/*     */   
/*  51 */   private Buffer rbuf = null;
/*  52 */   private Buffer wbuf = null;
/*  53 */   private Packet packet = null;
/*  54 */   private Buffer mbuf = null;
/*     */ 
/*     */ 
/*     */   
/*     */   ChannelAgentForwarding() {
/*  59 */     setLocalWindowSizeMax(131072);
/*  60 */     setLocalWindowSize(131072);
/*  61 */     setLocalPacketSize(16384);
/*     */     
/*  63 */     this.type = "auth-agent@openssh.com".getBytes();
/*  64 */     this.rbuf = new Buffer();
/*  65 */     this.rbuf.reset();
/*     */ 
/*     */     
/*  68 */     this.mbuf = new Buffer();
/*  69 */     this.connected = true;
/*     */   }
/*     */   
/*     */   public void run() {
/*     */     try {
/*  74 */       sendOpenConfirmation();
/*     */     } catch (Exception exception) {
/*     */       
/*  77 */       this.close = true;
/*  78 */       disconnect();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   void write(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws IOException {
/*  84 */     if (this.packet == null) {
/*  85 */       this.wbuf = new Buffer(this.rmpsize);
/*  86 */       this.packet = new Packet(this.wbuf);
/*     */     } 
/*     */     
/*  89 */     this.rbuf.shift();
/*  90 */     if (this.rbuf.buffer.length < this.rbuf.index + paramInt2) {
/*  91 */       byte[] arrayOfByte = new byte[this.rbuf.s + paramInt2];
/*  92 */       System.arraycopy(this.rbuf.buffer, 0, arrayOfByte, 0, this.rbuf.buffer.length);
/*  93 */       this.rbuf.buffer = arrayOfByte;
/*     */     } 
/*     */     
/*  96 */     this.rbuf.putByte(paramArrayOfbyte, paramInt1, paramInt2);
/*     */     
/*  98 */     int i = this.rbuf.getInt();
/*  99 */     if (i > this.rbuf.getLength()) {
/* 100 */       this.rbuf.s -= 4;
/*     */       
/*     */       return;
/*     */     } 
/* 104 */     int j = this.rbuf.getByte();
/*     */     
/* 106 */     Session session = null;
/*     */     try {
/* 108 */       session = getSession();
/*     */     } catch (JSchException jSchException) {
/*     */       
/* 111 */       throw new IOException(jSchException.toString());
/*     */     } 
/*     */     
/* 114 */     Vector vector = session.jsch.identities;
/* 115 */     UserInfo userInfo = session.getUserInfo();
/*     */     
/* 117 */     if (j == 11) {
/* 118 */       this.mbuf.reset();
/* 119 */       this.mbuf.putByte((byte)12);
/* 120 */       synchronized (vector) {
/* 121 */         byte b1 = 0;
/* 122 */         for (byte b2 = 0; b2 < vector.size(); b2++) {
/* 123 */           Identity identity = vector.elementAt(b2);
/* 124 */           if (identity.getPublicKeyBlob() != null)
/* 125 */             b1++; 
/*     */         } 
/* 127 */         this.mbuf.putInt(b1);
/* 128 */         for (byte b3 = 0; b3 < vector.size(); b3++) {
/* 129 */           Identity identity = vector.elementAt(b3);
/* 130 */           byte[] arrayOfByte1 = identity.getPublicKeyBlob();
/* 131 */           if (arrayOfByte1 != null) {
/*     */             
/* 133 */             this.mbuf.putString(arrayOfByte1);
/* 134 */             this.mbuf.putString("".getBytes());
/*     */           } 
/*     */         } 
/* 137 */       }  byte[] arrayOfByte = new byte[this.mbuf.getLength()];
/* 138 */       this.mbuf.getByte(arrayOfByte);
/*     */       
/* 140 */       send(arrayOfByte);
/*     */     }
/* 142 */     else if (j == 13) {
/* 143 */       byte[] arrayOfByte1 = this.rbuf.getString();
/* 144 */       byte[] arrayOfByte2 = this.rbuf.getString();
/* 145 */       int k = this.rbuf.getInt();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 151 */       Identity identity = null;
/* 152 */       synchronized (vector) {
/* 153 */         for (byte b = 0; b < vector.size(); b++) {
/* 154 */           Identity identity1 = vector.elementAt(b);
/* 155 */           if (identity1.getPublicKeyBlob() == null)
/*     */             continue; 
/* 157 */           if (!Util.array_equals(arrayOfByte1, identity1.getPublicKeyBlob())) {
/*     */             continue;
/*     */           }
/* 160 */           if (identity1.isEncrypted()) {
/* 161 */             if (userInfo == null)
/*     */               continue; 
/* 163 */             while (identity1.isEncrypted() && 
/* 164 */               userInfo.promptPassphrase("Passphrase for " + identity1.getName())) {
/*     */ 
/*     */ 
/*     */               
/* 168 */               String str = userInfo.getPassphrase();
/* 169 */               if (str == null) {
/*     */                 break;
/*     */               }
/*     */               
/* 173 */               byte[] arrayOfByte = Util.str2byte(str);
/*     */               try {
/* 175 */                 if (identity1.setPassphrase(arrayOfByte))
/*     */                 {
/*     */                   break;
/*     */                 }
/*     */               }
/* 180 */               catch (JSchException jSchException) {
/*     */                 break;
/*     */               } 
/*     */             } 
/*     */           } 
/* 185 */           if (!identity1.isEncrypted()) {
/* 186 */             identity = identity1;
/*     */             break;
/*     */           } 
/*     */           continue;
/*     */         } 
/*     */       } 
/* 192 */       byte[] arrayOfByte3 = null;
/*     */       
/* 194 */       if (identity != null) {
/* 195 */         arrayOfByte3 = identity.getSignature(arrayOfByte2);
/*     */       }
/*     */       
/* 198 */       this.mbuf.reset();
/* 199 */       if (arrayOfByte3 == null) {
/* 200 */         this.mbuf.putByte((byte)30);
/*     */       } else {
/*     */         
/* 203 */         this.mbuf.putByte((byte)14);
/* 204 */         this.mbuf.putString(arrayOfByte3);
/*     */       } 
/*     */       
/* 207 */       byte[] arrayOfByte4 = new byte[this.mbuf.getLength()];
/* 208 */       this.mbuf.getByte(arrayOfByte4);
/*     */       
/* 210 */       send(arrayOfByte4);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void send(byte[] paramArrayOfbyte) {
/* 215 */     this.packet.reset();
/* 216 */     this.wbuf.putByte((byte)94);
/* 217 */     this.wbuf.putInt(this.recipient);
/* 218 */     this.wbuf.putInt(4 + paramArrayOfbyte.length);
/* 219 */     this.wbuf.putString(paramArrayOfbyte);
/*     */     
/*     */     try {
/* 222 */       getSession().write(this.packet, this, 4 + paramArrayOfbyte.length);
/*     */     }
/* 224 */     catch (Exception exception) {}
/*     */   }
/*     */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/ChannelAgentForwarding.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */