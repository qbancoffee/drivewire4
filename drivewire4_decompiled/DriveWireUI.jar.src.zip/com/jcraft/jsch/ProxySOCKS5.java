/*     */ package com.jcraft.jsch;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.net.Socket;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProxySOCKS5
/*     */   implements Proxy
/*     */ {
/*  42 */   private static int DEFAULTPORT = 1080;
/*     */   private String proxy_host;
/*     */   private int proxy_port;
/*     */   private InputStream in;
/*     */   private OutputStream out;
/*     */   private Socket socket;
/*     */   private String user;
/*     */   private String passwd;
/*     */   
/*     */   public ProxySOCKS5(String paramString) {
/*  52 */     int i = DEFAULTPORT;
/*  53 */     String str = paramString;
/*  54 */     if (paramString.indexOf(':') != -1) {
/*     */       try {
/*  56 */         str = paramString.substring(0, paramString.indexOf(':'));
/*  57 */         i = Integer.parseInt(paramString.substring(paramString.indexOf(':') + 1));
/*     */       }
/*  59 */       catch (Exception exception) {}
/*     */     }
/*     */     
/*  62 */     this.proxy_host = str;
/*  63 */     this.proxy_port = i;
/*     */   }
/*     */   public ProxySOCKS5(String paramString, int paramInt) {
/*  66 */     this.proxy_host = paramString;
/*  67 */     this.proxy_port = paramInt;
/*     */   }
/*     */   public void setUserPasswd(String paramString1, String paramString2) {
/*  70 */     this.user = paramString1;
/*  71 */     this.passwd = paramString2;
/*     */   }
/*     */   public void connect(SocketFactory paramSocketFactory, String paramString, int paramInt1, int paramInt2) throws JSchException {
/*     */     try {
/*  75 */       if (paramSocketFactory == null) {
/*  76 */         this.socket = Util.createSocket(this.proxy_host, this.proxy_port, paramInt2);
/*     */         
/*  78 */         this.in = this.socket.getInputStream();
/*  79 */         this.out = this.socket.getOutputStream();
/*     */       } else {
/*     */         
/*  82 */         this.socket = paramSocketFactory.createSocket(this.proxy_host, this.proxy_port);
/*  83 */         this.in = paramSocketFactory.getInputStream(this.socket);
/*  84 */         this.out = paramSocketFactory.getOutputStream(this.socket);
/*     */       } 
/*  86 */       if (paramInt2 > 0) {
/*  87 */         this.socket.setSoTimeout(paramInt2);
/*     */       }
/*  89 */       this.socket.setTcpNoDelay(true);
/*     */       
/*  91 */       byte[] arrayOfByte1 = new byte[1024];
/*  92 */       int i = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 115 */       arrayOfByte1[i++] = 5;
/*     */       
/* 117 */       arrayOfByte1[i++] = 2;
/* 118 */       arrayOfByte1[i++] = 0;
/* 119 */       arrayOfByte1[i++] = 2;
/*     */       
/* 121 */       this.out.write(arrayOfByte1, 0, i);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 134 */       fill(this.in, arrayOfByte1, 2);
/*     */       
/* 136 */       boolean bool = false;
/* 137 */       switch (arrayOfByte1[1] & 0xFF) {
/*     */         case 0:
/* 139 */           bool = true;
/*     */           break;
/*     */         case 2:
/* 142 */           if (this.user == null || this.passwd == null) {
/*     */             break;
/*     */           }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 163 */           i = 0;
/* 164 */           arrayOfByte1[i++] = 1;
/* 165 */           arrayOfByte1[i++] = (byte)this.user.length();
/* 166 */           System.arraycopy(this.user.getBytes(), 0, arrayOfByte1, i, this.user.length());
/* 167 */           i += this.user.length();
/* 168 */           arrayOfByte1[i++] = (byte)this.passwd.length();
/* 169 */           System.arraycopy(this.passwd.getBytes(), 0, arrayOfByte1, i, this.passwd.length());
/* 170 */           i += this.passwd.length();
/*     */           
/* 172 */           this.out.write(arrayOfByte1, 0, i);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 189 */           fill(this.in, arrayOfByte1, 2);
/* 190 */           if (arrayOfByte1[1] == 0) {
/* 191 */             bool = true;
/*     */           }
/*     */           break;
/*     */       } 
/*     */       
/* 196 */       if (!bool) { try {
/* 197 */           this.socket.close();
/* 198 */         } catch (Exception exception) {}
/*     */         
/* 200 */         throw new JSchException("fail in SOCKS5 proxy"); }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 229 */       i = 0;
/* 230 */       arrayOfByte1[i++] = 5;
/* 231 */       arrayOfByte1[i++] = 1;
/* 232 */       arrayOfByte1[i++] = 0;
/*     */       
/* 234 */       byte[] arrayOfByte2 = paramString.getBytes();
/* 235 */       int j = arrayOfByte2.length;
/* 236 */       arrayOfByte1[i++] = 3;
/* 237 */       arrayOfByte1[i++] = (byte)j;
/* 238 */       System.arraycopy(arrayOfByte2, 0, arrayOfByte1, i, j);
/* 239 */       i += j;
/* 240 */       arrayOfByte1[i++] = (byte)(paramInt1 >>> 8);
/* 241 */       arrayOfByte1[i++] = (byte)(paramInt1 & 0xFF);
/*     */       
/* 243 */       this.out.write(arrayOfByte1, 0, i);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 281 */       fill(this.in, arrayOfByte1, 4);
/*     */       
/* 283 */       if (arrayOfByte1[1] != 0) { try {
/* 284 */           this.socket.close();
/* 285 */         } catch (Exception exception) {}
/*     */         
/* 287 */         throw new JSchException("ProxySOCKS5: server returns " + arrayOfByte1[1]); }
/*     */ 
/*     */       
/* 290 */       switch (arrayOfByte1[3] & 0xFF) {
/*     */         
/*     */         case 1:
/* 293 */           fill(this.in, arrayOfByte1, 6);
/*     */           break;
/*     */         
/*     */         case 3:
/* 297 */           fill(this.in, arrayOfByte1, 1);
/*     */           
/* 299 */           fill(this.in, arrayOfByte1, (arrayOfByte1[0] & 0xFF) + 2);
/*     */           break;
/*     */         
/*     */         case 4:
/* 303 */           fill(this.in, arrayOfByte1, 18);
/*     */           break;
/*     */       } 
/*     */ 
/*     */     
/*     */     } catch (RuntimeException runtimeException) {
/* 309 */       throw runtimeException;
/*     */     } catch (Exception exception) {
/*     */       try {
/* 312 */         if (this.socket != null) this.socket.close(); 
/* 313 */       } catch (Exception exception1) {}
/*     */       
/* 315 */       String str = "ProxySOCKS5: " + exception.toString();
/* 316 */       if (exception instanceof Throwable)
/* 317 */         throw new JSchException(str, exception); 
/* 318 */       throw new JSchException(str);
/*     */     } 
/*     */   }
/* 321 */   public InputStream getInputStream() { return this.in; }
/* 322 */   public OutputStream getOutputStream() { return this.out; } public Socket getSocket() {
/* 323 */     return this.socket;
/*     */   } public void close() {
/*     */     try {
/* 326 */       if (this.in != null) this.in.close(); 
/* 327 */       if (this.out != null) this.out.close(); 
/* 328 */       if (this.socket != null) this.socket.close();
/*     */     
/* 330 */     } catch (Exception exception) {}
/*     */     
/* 332 */     this.in = null;
/* 333 */     this.out = null;
/* 334 */     this.socket = null;
/*     */   }
/*     */   public static int getDefaultPort() {
/* 337 */     return DEFAULTPORT;
/*     */   }
/*     */   private void fill(InputStream paramInputStream, byte[] paramArrayOfbyte, int paramInt) throws JSchException, IOException {
/* 340 */     int i = 0;
/* 341 */     while (i < paramInt) {
/* 342 */       int j = paramInputStream.read(paramArrayOfbyte, i, paramInt - i);
/* 343 */       if (j <= 0) {
/* 344 */         throw new JSchException("ProxySOCKS5: stream is closed");
/*     */       }
/* 346 */       i += j;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/ProxySOCKS5.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */