/*     */ package com.jcraft.jsch.jgss;
/*     */ 
/*     */ import com.jcraft.jsch.GSSContext;
/*     */ import com.jcraft.jsch.JSchException;
/*     */ import java.net.InetAddress;
/*     */ import java.net.UnknownHostException;
/*     */ import org.ietf.jgss.GSSContext;
/*     */ import org.ietf.jgss.GSSCredential;
/*     */ import org.ietf.jgss.GSSException;
/*     */ import org.ietf.jgss.GSSManager;
/*     */ import org.ietf.jgss.GSSName;
/*     */ import org.ietf.jgss.MessageProp;
/*     */ import org.ietf.jgss.Oid;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class GSSContextKrb5
/*     */   implements GSSContext
/*     */ {
/*     */   private static final String pUseSubjectCredsOnly = "javax.security.auth.useSubjectCredsOnly";
/*  48 */   private static String useSubjectCredsOnly = getSystemProperty("javax.security.auth.useSubjectCredsOnly");
/*     */ 
/*     */   
/*  51 */   private GSSContext context = null;
/*     */   
/*     */   public void create(String paramString1, String paramString2) throws JSchException {
/*     */     try {
/*  55 */       Oid oid1 = new Oid("1.2.840.113554.1.2.2");
/*     */       
/*  57 */       Oid oid2 = new Oid("1.2.840.113554.1.2.2.1");
/*     */       
/*  59 */       GSSManager gSSManager = GSSManager.getInstance();
/*     */       
/*  61 */       GSSCredential gSSCredential = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  74 */       String str = paramString2;
/*     */       try {
/*  76 */         str = InetAddress.getByName(str).getCanonicalHostName();
/*     */       }
/*  78 */       catch (UnknownHostException unknownHostException) {}
/*     */       
/*  80 */       GSSName gSSName = gSSManager.createName("host/" + str, oid2);
/*     */       
/*  82 */       this.context = gSSManager.createContext(gSSName, oid1, gSSCredential, 0);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 101 */       this.context.requestMutualAuth(true);
/* 102 */       this.context.requestConf(true);
/* 103 */       this.context.requestInteg(true);
/* 104 */       this.context.requestCredDeleg(true);
/* 105 */       this.context.requestAnonymity(false);
/*     */ 
/*     */       
/*     */       return;
/*     */     } catch (GSSException gSSException) {
/* 110 */       throw new JSchException(gSSException.toString());
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean isEstablished() {
/* 115 */     return this.context.isEstablished();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] init(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws JSchException {
/*     */     try {
/*     */       try {
/* 126 */         if (useSubjectCredsOnly == null) {
/* 127 */           setSystemProperty("javax.security.auth.useSubjectCredsOnly", "false");
/*     */         }
/* 129 */         return this.context.initSecContext(paramArrayOfbyte, 0, paramInt2);
/*     */ 
/*     */ 
/*     */       
/*     */       }
/*     */       finally {
/*     */ 
/*     */ 
/*     */         
/* 138 */         if (useSubjectCredsOnly == null)
/*     */         {
/* 140 */           setSystemProperty("javax.security.auth.useSubjectCredsOnly", "true"); } 
/*     */       } 
/*     */     } catch (GSSException gSSException) {
/*     */       throw new JSchException(gSSException.toString());
/*     */     } catch (SecurityException securityException) {
/*     */       throw new JSchException(securityException.toString());
/*     */     }  } public byte[] getMIC(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) { try {
/* 147 */       MessageProp messageProp = new MessageProp(0, true);
/* 148 */       return this.context.getMIC(paramArrayOfbyte, paramInt1, paramInt2, messageProp);
/*     */     } catch (GSSException gSSException) {
/*     */       
/* 151 */       return null;
/*     */     }  }
/*     */ 
/*     */   
/*     */   public void dispose() {
/*     */     try {
/* 157 */       this.context.dispose();
/*     */     }
/* 159 */     catch (GSSException gSSException) {}
/*     */   }
/*     */   
/*     */   private static String getSystemProperty(String paramString) {
/*     */     try {
/* 164 */       return System.getProperty(paramString);
/*     */     } catch (Exception exception) {
/*     */       
/* 167 */       return null;
/*     */     } 
/*     */   }
/*     */   private static void setSystemProperty(String paramString1, String paramString2) {
/*     */     try {
/* 172 */       System.setProperty(paramString1, paramString2);
/* 173 */     } catch (Exception exception) {}
/*     */   }
/*     */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/jgss/GSSContextKrb5.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */