/*    */ package com.jcraft.jsch;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JSchException
/*    */   extends Exception
/*    */ {
/* 34 */   private Throwable cause = null;
/*    */   
/*    */   public JSchException() {}
/*    */   
/*    */   public JSchException(String paramString) {
/* 39 */     super(paramString);
/*    */   }
/*    */   public JSchException(String paramString, Throwable paramThrowable) {
/* 42 */     super(paramString);
/* 43 */     this.cause = paramThrowable;
/*    */   }
/*    */   public Throwable getCause() {
/* 46 */     return this.cause;
/*    */   }
/*    */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/JSchException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */