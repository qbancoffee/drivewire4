package com.jcraft.jsch;

public interface KeyPairGenRSA {
  void init(int paramInt) throws Exception;
  
  byte[] getD();
  
  byte[] getE();
  
  byte[] getN();
  
  byte[] getC();
  
  byte[] getEP();
  
  byte[] getEQ();
  
  byte[] getP();
  
  byte[] getQ();
}


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/KeyPairGenRSA.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */