/*    */ package com.jcraft.jsch;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class JSchPartialAuthException
/*    */   extends JSchException
/*    */ {
/*    */   String methods;
/*    */   
/*    */   public JSchPartialAuthException() {}
/*    */   
/*    */   public JSchPartialAuthException(String paramString) {
/* 39 */     super(paramString);
/* 40 */     this.methods = paramString;
/*    */   }
/*    */   public String getMethods() {
/* 43 */     return this.methods;
/*    */   }
/*    */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/JSchPartialAuthException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */