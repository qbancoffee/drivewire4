/*    */ package com.jcraft.jsch.jcraft;
/*    */ 
/*    */ import com.jcraft.jsch.MAC;
/*    */ import java.security.MessageDigest;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HMACSHA1
/*    */   extends HMAC
/*    */   implements MAC
/*    */ {
/*    */   private static final String name = "hmac-sha1";
/*    */   
/*    */   public HMACSHA1() {
/* 40 */     MessageDigest messageDigest = null; try {
/* 41 */       messageDigest = MessageDigest.getInstance("SHA-1");
/*    */     } catch (Exception exception) {
/* 43 */       System.err.println(exception);
/*    */     } 
/* 45 */     setH(messageDigest);
/*    */   }
/*    */   
/*    */   public String getName() {
/* 49 */     return "hmac-sha1";
/*    */   }
/*    */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/jcraft/HMACSHA1.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */