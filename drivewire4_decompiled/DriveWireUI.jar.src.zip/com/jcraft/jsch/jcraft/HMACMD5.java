/*    */ package com.jcraft.jsch.jcraft;
/*    */ 
/*    */ import com.jcraft.jsch.MAC;
/*    */ import java.security.MessageDigest;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HMACMD5
/*    */   extends HMAC
/*    */   implements MAC
/*    */ {
/*    */   private static final String name = "hmac-md5";
/*    */   
/*    */   public HMACMD5() {
/* 40 */     MessageDigest messageDigest = null; try {
/* 41 */       messageDigest = MessageDigest.getInstance("MD5");
/*    */     } catch (Exception exception) {
/* 43 */       System.err.println(exception);
/*    */     } 
/* 45 */     setH(messageDigest);
/*    */   }
/*    */   
/*    */   public String getName() {
/* 49 */     return "hmac-md5";
/*    */   }
/*    */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/jcraft/HMACMD5.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */