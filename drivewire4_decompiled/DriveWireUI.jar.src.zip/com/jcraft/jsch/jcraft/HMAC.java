/*     */ package com.jcraft.jsch.jcraft;
/*     */ 
/*     */ import java.security.MessageDigest;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class HMAC
/*     */ {
/*     */   private static final int B = 64;
/*  47 */   private byte[] k_ipad = null;
/*  48 */   private byte[] k_opad = null;
/*     */   
/*  50 */   private MessageDigest md = null;
/*     */   
/*  52 */   private int bsize = 0;
/*     */   
/*     */   protected void setH(MessageDigest paramMessageDigest) {
/*  55 */     this.md = paramMessageDigest;
/*  56 */     this.bsize = paramMessageDigest.getDigestLength();
/*     */   }
/*     */   public int getBlockSize() {
/*  59 */     return this.bsize;
/*     */   } public void init(byte[] paramArrayOfbyte) throws Exception {
/*  61 */     if (paramArrayOfbyte.length > this.bsize) {
/*  62 */       byte[] arrayOfByte = new byte[this.bsize];
/*  63 */       System.arraycopy(paramArrayOfbyte, 0, arrayOfByte, 0, this.bsize);
/*  64 */       paramArrayOfbyte = arrayOfByte;
/*     */     } 
/*     */ 
/*     */     
/*  68 */     if (paramArrayOfbyte.length > 64) {
/*  69 */       this.md.update(paramArrayOfbyte, 0, paramArrayOfbyte.length);
/*  70 */       paramArrayOfbyte = this.md.digest();
/*     */     } 
/*     */     
/*  73 */     this.k_ipad = new byte[64];
/*  74 */     System.arraycopy(paramArrayOfbyte, 0, this.k_ipad, 0, paramArrayOfbyte.length);
/*  75 */     this.k_opad = new byte[64];
/*  76 */     System.arraycopy(paramArrayOfbyte, 0, this.k_opad, 0, paramArrayOfbyte.length);
/*     */ 
/*     */     
/*  79 */     for (byte b = 0; b < 64; b++) {
/*  80 */       this.k_ipad[b] = (byte)(this.k_ipad[b] ^ 0x36);
/*  81 */       this.k_opad[b] = (byte)(this.k_opad[b] ^ 0x5C);
/*     */     } 
/*     */     
/*  84 */     this.md.update(this.k_ipad, 0, 64);
/*     */   }
/*     */   
/*  87 */   private final byte[] tmp = new byte[4];
/*     */   public void update(int paramInt) {
/*  89 */     this.tmp[0] = (byte)(paramInt >>> 24);
/*  90 */     this.tmp[1] = (byte)(paramInt >>> 16);
/*  91 */     this.tmp[2] = (byte)(paramInt >>> 8);
/*  92 */     this.tmp[3] = (byte)paramInt;
/*  93 */     update(this.tmp, 0, 4);
/*     */   }
/*     */   
/*     */   public void update(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
/*  97 */     this.md.update(paramArrayOfbyte, paramInt1, paramInt2);
/*     */   }
/*     */   
/*     */   public void doFinal(byte[] paramArrayOfbyte, int paramInt) {
/* 101 */     byte[] arrayOfByte = this.md.digest();
/* 102 */     this.md.update(this.k_opad, 0, 64);
/* 103 */     this.md.update(arrayOfByte, 0, this.bsize); 
/* 104 */     try { this.md.digest(paramArrayOfbyte, paramInt, this.bsize); } catch (Exception exception) {}
/* 105 */     this.md.update(this.k_ipad, 0, 64);
/*     */   }
/*     */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/jcraft/HMAC.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */