/*     */ package com.jcraft.jsch.jcraft;
/*     */ 
/*     */ import com.jcraft.jsch.Compression;
/*     */ import com.jcraft.jzlib.ZStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Compression
/*     */   implements Compression
/*     */ {
/*     */   private static final int BUF_SIZE = 4096;
/*     */   private int type;
/*     */   private ZStream stream;
/*  39 */   private byte[] tmpbuf = new byte[4096]; private byte[] inflated_buf;
/*     */   
/*     */   public Compression() {
/*  42 */     this.stream = new ZStream();
/*     */   }
/*     */   
/*     */   public void init(int paramInt1, int paramInt2) {
/*  46 */     if (paramInt1 == 1) {
/*  47 */       this.stream.deflateInit(paramInt2);
/*  48 */       this.type = 1;
/*     */     }
/*  50 */     else if (paramInt1 == 0) {
/*  51 */       this.stream.inflateInit();
/*  52 */       this.inflated_buf = new byte[4096];
/*  53 */       this.type = 0;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int compress(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
/*  76 */     this.stream.next_in = paramArrayOfbyte;
/*  77 */     this.stream.next_in_index = paramInt1;
/*  78 */     this.stream.avail_in = paramInt2 - paramInt1;
/*     */     
/*  80 */     int i = paramInt1;
/*     */     
/*     */     while (true) {
/*  83 */       this.stream.next_out = this.tmpbuf;
/*  84 */       this.stream.next_out_index = 0;
/*  85 */       this.stream.avail_out = 4096;
/*  86 */       int j = this.stream.deflate(1);
/*  87 */       switch (j) {
/*     */         case 0:
/*  89 */           System.arraycopy(this.tmpbuf, 0, paramArrayOfbyte, i, 4096 - this.stream.avail_out);
/*     */ 
/*     */           
/*  92 */           i += 4096 - this.stream.avail_out;
/*     */           break;
/*     */         default:
/*  95 */           System.err.println("compress: deflate returnd " + j);
/*     */           break;
/*     */       } 
/*  98 */       if (this.stream.avail_out != 0)
/*  99 */         return i; 
/*     */     } 
/*     */   }
/*     */   public byte[] uncompress(byte[] paramArrayOfbyte, int paramInt, int[] paramArrayOfint) {
/* 103 */     int j, i = 0;
/*     */     
/* 105 */     this.stream.next_in = paramArrayOfbyte;
/* 106 */     this.stream.next_in_index = paramInt;
/* 107 */     this.stream.avail_in = paramArrayOfint[0];
/*     */     
/*     */     while (true) {
/* 110 */       this.stream.next_out = this.tmpbuf;
/* 111 */       this.stream.next_out_index = 0;
/* 112 */       this.stream.avail_out = 4096;
/* 113 */       j = this.stream.inflate(1);
/* 114 */       switch (j) {
/*     */         case 0:
/* 116 */           if (this.inflated_buf.length < i + 4096 - this.stream.avail_out) {
/* 117 */             byte[] arrayOfByte = new byte[i + 4096 - this.stream.avail_out];
/* 118 */             System.arraycopy(this.inflated_buf, 0, arrayOfByte, 0, i);
/* 119 */             this.inflated_buf = arrayOfByte;
/*     */           } 
/* 121 */           System.arraycopy(this.tmpbuf, 0, this.inflated_buf, i, 4096 - this.stream.avail_out);
/*     */ 
/*     */           
/* 124 */           i += 4096 - this.stream.avail_out;
/* 125 */           paramArrayOfint[0] = i;
/*     */           continue;
/*     */         case -5:
/* 128 */           if (i > paramArrayOfbyte.length - paramInt) {
/* 129 */             byte[] arrayOfByte = new byte[i + paramInt];
/* 130 */             System.arraycopy(paramArrayOfbyte, 0, arrayOfByte, 0, paramInt);
/* 131 */             System.arraycopy(this.inflated_buf, 0, arrayOfByte, paramInt, i);
/* 132 */             paramArrayOfbyte = arrayOfByte;
/*     */           } else {
/*     */             
/* 135 */             System.arraycopy(this.inflated_buf, 0, paramArrayOfbyte, paramInt, i);
/*     */           } 
/* 137 */           paramArrayOfint[0] = i;
/* 138 */           return paramArrayOfbyte;
/*     */       }  break;
/* 140 */     }  System.err.println("uncompress: inflate returnd " + j);
/* 141 */     return null;
/*     */   }
/*     */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/jcraft/Compression.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */