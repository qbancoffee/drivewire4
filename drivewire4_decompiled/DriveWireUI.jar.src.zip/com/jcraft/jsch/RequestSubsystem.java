/*    */ package com.jcraft.jsch;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class RequestSubsystem
/*    */   extends Request
/*    */ {
/* 33 */   private String subsystem = null;
/*    */   public void request(Session paramSession, Channel paramChannel, String paramString, boolean paramBoolean) throws Exception {
/* 35 */     setReply(paramBoolean);
/* 36 */     this.subsystem = paramString;
/* 37 */     request(paramSession, paramChannel);
/*    */   }
/*    */   public void request(Session paramSession, Channel paramChannel) throws Exception {
/* 40 */     super.request(paramSession, paramChannel);
/*    */     
/* 42 */     Buffer buffer = new Buffer();
/* 43 */     Packet packet = new Packet(buffer);
/*    */     
/* 45 */     packet.reset();
/* 46 */     buffer.putByte((byte)98);
/* 47 */     buffer.putInt(paramChannel.getRecipient());
/* 48 */     buffer.putString("subsystem".getBytes());
/* 49 */     buffer.putByte((byte)(waitForReply() ? 1 : 0));
/* 50 */     buffer.putString(this.subsystem.getBytes());
/* 51 */     write(packet);
/*    */   }
/*    */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/RequestSubsystem.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */