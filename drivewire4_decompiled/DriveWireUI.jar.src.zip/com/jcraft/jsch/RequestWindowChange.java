/*    */ package com.jcraft.jsch;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class RequestWindowChange
/*    */   extends Request
/*    */ {
/* 33 */   int width_columns = 80;
/* 34 */   int height_rows = 24;
/* 35 */   int width_pixels = 640;
/* 36 */   int height_pixels = 480;
/*    */   void setSize(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 38 */     this.width_columns = paramInt1;
/* 39 */     this.height_rows = paramInt2;
/* 40 */     this.width_pixels = paramInt3;
/* 41 */     this.height_pixels = paramInt4;
/*    */   }
/*    */   public void request(Session paramSession, Channel paramChannel) throws Exception {
/* 44 */     super.request(paramSession, paramChannel);
/*    */     
/* 46 */     Buffer buffer = new Buffer();
/* 47 */     Packet packet = new Packet(buffer);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 57 */     packet.reset();
/* 58 */     buffer.putByte((byte)98);
/* 59 */     buffer.putInt(paramChannel.getRecipient());
/* 60 */     buffer.putString("window-change".getBytes());
/* 61 */     buffer.putByte((byte)(waitForReply() ? 1 : 0));
/* 62 */     buffer.putInt(this.width_columns);
/* 63 */     buffer.putInt(this.height_rows);
/* 64 */     buffer.putInt(this.width_pixels);
/* 65 */     buffer.putInt(this.height_pixels);
/* 66 */     write(packet);
/*    */   }
/*    */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/RequestWindowChange.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */