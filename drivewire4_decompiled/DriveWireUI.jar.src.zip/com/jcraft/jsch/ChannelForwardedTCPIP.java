/*     */ package com.jcraft.jsch;
/*     */ 
/*     */ import java.io.PipedOutputStream;
/*     */ import java.net.Socket;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChannelForwardedTCPIP
/*     */   extends Channel
/*     */ {
/*  37 */   static Vector pool = new Vector();
/*     */   
/*     */   private static final int LOCAL_WINDOW_SIZE_MAX = 131072;
/*     */   
/*     */   private static final int LOCAL_MAXIMUM_PACKET_SIZE = 16384;
/*     */   
/*     */   private static final int TIMEOUT = 10000;
/*     */   
/*  45 */   SocketFactory factory = null;
/*  46 */   private Socket socket = null;
/*  47 */   private ForwardedTCPIPDaemon daemon = null;
/*     */   
/*     */   String target;
/*     */   int lport;
/*     */   int rport;
/*     */   
/*     */   ChannelForwardedTCPIP() {
/*  54 */     setLocalWindowSizeMax(131072);
/*  55 */     setLocalWindowSize(131072);
/*  56 */     setLocalPacketSize(16384);
/*  57 */     this.io = new IO();
/*  58 */     this.connected = true;
/*     */   }
/*     */   
/*     */   public void run() {
/*     */     try {
/*  63 */       if (this.lport == -1) {
/*  64 */         Class clazz = Class.forName(this.target);
/*  65 */         this.daemon = (ForwardedTCPIPDaemon)clazz.newInstance();
/*     */         
/*  67 */         PipedOutputStream pipedOutputStream = new PipedOutputStream();
/*  68 */         this.io.setInputStream(new Channel.PassiveInputStream(this, pipedOutputStream, 32768), false);
/*     */ 
/*     */ 
/*     */         
/*  72 */         this.daemon.setChannel(this, getInputStream(), pipedOutputStream);
/*  73 */         Object[] arrayOfObject = getPort(getSession(), this.rport);
/*  74 */         this.daemon.setArg((Object[])arrayOfObject[3]);
/*     */         
/*  76 */         (new Thread(this.daemon)).start();
/*     */       } else {
/*     */         
/*  79 */         this.socket = (this.factory == null) ? Util.createSocket(this.target, this.lport, 10000) : this.factory.createSocket(this.target, this.lport);
/*     */ 
/*     */         
/*  82 */         this.socket.setTcpNoDelay(true);
/*  83 */         this.io.setInputStream(this.socket.getInputStream());
/*  84 */         this.io.setOutputStream(this.socket.getOutputStream());
/*     */       } 
/*  86 */       sendOpenConfirmation();
/*     */     } catch (Exception exception) {
/*     */       
/*  89 */       sendOpenFailure(1);
/*  90 */       this.close = true;
/*  91 */       disconnect();
/*     */       
/*     */       return;
/*     */     } 
/*  95 */     this.thread = Thread.currentThread();
/*  96 */     Buffer buffer = new Buffer(this.rmpsize);
/*  97 */     Packet packet = new Packet(buffer);
/*  98 */     int i = 0;
/*     */ 
/*     */     
/*     */     try {
/* 102 */       while (this.thread != null && this.io != null && this.io.in != null) {
/* 103 */         i = this.io.in.read(buffer.buffer, 14, buffer.buffer.length - 14 - 32 - 20);
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 108 */         if (i <= 0) {
/* 109 */           eof();
/*     */           break;
/*     */         } 
/* 112 */         packet.reset();
/* 113 */         if (this.close)
/* 114 */           break;  buffer.putByte((byte)94);
/* 115 */         buffer.putInt(this.recipient);
/* 116 */         buffer.putInt(i);
/* 117 */         buffer.skip(i);
/* 118 */         getSession().write(packet, this, i);
/*     */       }
/*     */     
/* 121 */     } catch (Exception exception) {}
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 126 */     disconnect();
/*     */   }
/*     */   
/*     */   void getData(Buffer paramBuffer) {
/* 130 */     setRecipient(paramBuffer.getInt());
/* 131 */     setRemoteWindowSize(paramBuffer.getInt());
/* 132 */     setRemotePacketSize(paramBuffer.getInt());
/* 133 */     byte[] arrayOfByte1 = paramBuffer.getString();
/* 134 */     int i = paramBuffer.getInt();
/* 135 */     byte[] arrayOfByte2 = paramBuffer.getString();
/* 136 */     int j = paramBuffer.getInt();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 145 */     Session session = null;
/*     */     try {
/* 147 */       session = getSession();
/*     */     }
/* 149 */     catch (JSchException jSchException) {}
/*     */ 
/*     */ 
/*     */     
/* 153 */     synchronized (pool) {
/* 154 */       for (byte b = 0; b < pool.size(); ) {
/* 155 */         Object[] arrayOfObject = pool.elementAt(b);
/* 156 */         if (arrayOfObject[0] != session || (
/* 157 */           (Integer)arrayOfObject[1]).intValue() != i) { b++; continue; }
/* 158 */          this.rport = i;
/* 159 */         this.target = (String)arrayOfObject[2];
/* 160 */         if (arrayOfObject[3] == null || arrayOfObject[3] instanceof Object[]) { this.lport = -1; }
/* 161 */         else { this.lport = ((Integer)arrayOfObject[3]).intValue(); }
/* 162 */          if (arrayOfObject.length >= 6) {
/* 163 */           this.factory = (SocketFactory)arrayOfObject[5];
/*     */         }
/*     */         break;
/*     */       } 
/* 167 */       if (this.target == null);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static Object[] getPort(Session paramSession, int paramInt) {
/* 174 */     synchronized (pool) {
/* 175 */       for (byte b = 0; b < pool.size(); ) {
/* 176 */         Object[] arrayOfObject = pool.elementAt(b);
/* 177 */         if (arrayOfObject[0] != paramSession || (
/* 178 */           (Integer)arrayOfObject[1]).intValue() != paramInt) { b++; continue; }
/* 179 */          return arrayOfObject;
/*     */       } 
/* 181 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   static String[] getPortForwarding(Session paramSession) {
/* 186 */     Vector vector = new Vector();
/* 187 */     synchronized (pool) {
/* 188 */       for (byte b1 = 0; b1 < pool.size(); b1++) {
/* 189 */         Object[] arrayOfObject = pool.elementAt(b1);
/* 190 */         if (arrayOfObject[0] == paramSession)
/* 191 */           if (arrayOfObject[3] == null) { vector.addElement(arrayOfObject[1] + ":" + arrayOfObject[2] + ":"); }
/* 192 */           else { vector.addElement(arrayOfObject[1] + ":" + arrayOfObject[2] + ":" + arrayOfObject[3]); }
/*     */            
/*     */       } 
/* 195 */     }  String[] arrayOfString = new String[vector.size()];
/* 196 */     for (byte b = 0; b < vector.size(); b++) {
/* 197 */       arrayOfString[b] = vector.elementAt(b);
/*     */     }
/* 199 */     return arrayOfString;
/*     */   }
/*     */   
/*     */   static String normalize(String paramString) {
/* 203 */     if (paramString == null) return "localhost"; 
/* 204 */     if (paramString.length() == 0 || paramString.equals("*")) return ""; 
/* 205 */     return paramString;
/*     */   }
/*     */   
/*     */   static void addPort(Session paramSession, String paramString1, int paramInt1, String paramString2, int paramInt2, SocketFactory paramSocketFactory) throws JSchException {
/* 209 */     String str = normalize(paramString1);
/* 210 */     synchronized (pool) {
/* 211 */       if (getPort(paramSession, paramInt1) != null) {
/* 212 */         throw new JSchException("PortForwardingR: remote port " + paramInt1 + " is already registered.");
/*     */       }
/* 214 */       Object[] arrayOfObject = new Object[6];
/* 215 */       arrayOfObject[0] = paramSession; arrayOfObject[1] = new Integer(paramInt1);
/* 216 */       arrayOfObject[2] = paramString2; arrayOfObject[3] = new Integer(paramInt2);
/* 217 */       arrayOfObject[4] = str;
/* 218 */       arrayOfObject[5] = paramSocketFactory;
/* 219 */       pool.addElement(arrayOfObject);
/*     */     } 
/*     */   }
/*     */   static void addPort(Session paramSession, String paramString1, int paramInt, String paramString2, Object[] paramArrayOfObject) throws JSchException {
/* 223 */     String str = normalize(paramString1);
/* 224 */     synchronized (pool) {
/* 225 */       if (getPort(paramSession, paramInt) != null) {
/* 226 */         throw new JSchException("PortForwardingR: remote port " + paramInt + " is already registered.");
/*     */       }
/* 228 */       Object[] arrayOfObject = new Object[5];
/* 229 */       arrayOfObject[0] = paramSession; arrayOfObject[1] = new Integer(paramInt);
/* 230 */       arrayOfObject[2] = paramString2; arrayOfObject[3] = paramArrayOfObject;
/* 231 */       arrayOfObject[4] = str;
/* 232 */       pool.addElement(arrayOfObject);
/*     */     } 
/*     */   }
/*     */   static void delPort(ChannelForwardedTCPIP paramChannelForwardedTCPIP) {
/* 236 */     Session session = null;
/*     */     try {
/* 238 */       session = paramChannelForwardedTCPIP.getSession();
/*     */     }
/* 240 */     catch (JSchException jSchException) {}
/*     */ 
/*     */     
/* 243 */     if (session != null)
/* 244 */       delPort(session, paramChannelForwardedTCPIP.rport); 
/*     */   }
/*     */   static void delPort(Session paramSession, int paramInt) {
/* 247 */     delPort(paramSession, (String)null, paramInt);
/*     */   }
/*     */   static void delPort(Session paramSession, String paramString, int paramInt) {
/* 250 */     synchronized (pool) {
/* 251 */       Object[] arrayOfObject = null;
/* 252 */       for (byte b = 0; b < pool.size(); ) {
/* 253 */         Object[] arrayOfObject1 = pool.elementAt(b);
/* 254 */         if (arrayOfObject1[0] != paramSession || (
/* 255 */           (Integer)arrayOfObject1[1]).intValue() != paramInt) { b++; continue; }
/* 256 */          arrayOfObject = arrayOfObject1;
/*     */         break;
/*     */       } 
/* 259 */       if (arrayOfObject == null)
/* 260 */         return;  pool.removeElement(arrayOfObject);
/* 261 */       if (paramString == null) {
/* 262 */         paramString = (String)arrayOfObject[4];
/*     */       }
/* 264 */       if (paramString == null) {
/* 265 */         paramString = "0.0.0.0";
/*     */       }
/*     */     } 
/*     */     
/* 269 */     Buffer buffer = new Buffer(100);
/* 270 */     Packet packet = new Packet(buffer);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 278 */       packet.reset();
/* 279 */       buffer.putByte((byte)80);
/* 280 */       buffer.putString("cancel-tcpip-forward".getBytes());
/* 281 */       buffer.putByte((byte)0);
/* 282 */       buffer.putString(paramString.getBytes());
/* 283 */       buffer.putInt(paramInt);
/* 284 */       paramSession.write(packet);
/*     */     }
/* 286 */     catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */   
/*     */   static void delPort(Session paramSession) {
/* 291 */     int[] arrayOfInt = null;
/* 292 */     byte b1 = 0;
/* 293 */     synchronized (pool) {
/* 294 */       arrayOfInt = new int[pool.size()];
/* 295 */       for (byte b = 0; b < pool.size(); b++) {
/* 296 */         Object[] arrayOfObject = pool.elementAt(b);
/* 297 */         if (arrayOfObject[0] == paramSession) {
/* 298 */           arrayOfInt[b1++] = ((Integer)arrayOfObject[1]).intValue();
/*     */         }
/*     */       } 
/*     */     } 
/* 302 */     for (byte b2 = 0; b2 < b1; b2++)
/* 303 */       delPort(paramSession, arrayOfInt[b2]); 
/*     */   }
/*     */   
/*     */   public int getRemotePort() {
/* 307 */     return this.rport;
/*     */   } void setSocketFactory(SocketFactory paramSocketFactory) {
/* 309 */     this.factory = paramSocketFactory;
/*     */   }
/*     */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/ChannelForwardedTCPIP.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */