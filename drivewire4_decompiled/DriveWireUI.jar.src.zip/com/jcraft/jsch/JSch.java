/*     */ package com.jcraft.jsch;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.util.Enumeration;
/*     */ import java.util.Hashtable;
/*     */ import java.util.Vector;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class JSch
/*     */ {
/*  36 */   static Hashtable config = new Hashtable();
/*     */   
/*     */   static {
/*  39 */     config.put("kex", "diffie-hellman-group1-sha1,diffie-hellman-group-exchange-sha1");
/*  40 */     config.put("server_host_key", "ssh-rsa,ssh-dss");
/*     */ 
/*     */     
/*  43 */     config.put("cipher.s2c", "aes128-ctr,aes128-cbc,3des-ctr,3des-cbc,blowfish-cbc,aes192-cbc,aes256-cbc");
/*     */     
/*  45 */     config.put("cipher.c2s", "aes128-ctr,aes128-cbc,3des-ctr,3des-cbc,blowfish-cbc,aes192-cbc,aes256-cbc");
/*     */ 
/*     */     
/*  48 */     config.put("mac.s2c", "hmac-md5,hmac-sha1,hmac-sha1-96,hmac-md5-96");
/*  49 */     config.put("mac.c2s", "hmac-md5,hmac-sha1,hmac-sha1-96,hmac-md5-96");
/*  50 */     config.put("compression.s2c", "none");
/*     */     
/*  52 */     config.put("compression.c2s", "none");
/*     */ 
/*     */     
/*  55 */     config.put("lang.s2c", "");
/*  56 */     config.put("lang.c2s", "");
/*     */     
/*  58 */     config.put("compression_level", "6");
/*     */     
/*  60 */     config.put("diffie-hellman-group-exchange-sha1", "com.jcraft.jsch.DHGEX");
/*     */     
/*  62 */     config.put("diffie-hellman-group1-sha1", "com.jcraft.jsch.DHG1");
/*     */ 
/*     */     
/*  65 */     config.put("dh", "com.jcraft.jsch.jce.DH");
/*  66 */     config.put("3des-cbc", "com.jcraft.jsch.jce.TripleDESCBC");
/*  67 */     config.put("blowfish-cbc", "com.jcraft.jsch.jce.BlowfishCBC");
/*  68 */     config.put("hmac-sha1", "com.jcraft.jsch.jce.HMACSHA1");
/*  69 */     config.put("hmac-sha1-96", "com.jcraft.jsch.jce.HMACSHA196");
/*  70 */     config.put("hmac-md5", "com.jcraft.jsch.jce.HMACMD5");
/*  71 */     config.put("hmac-md5-96", "com.jcraft.jsch.jce.HMACMD596");
/*  72 */     config.put("sha-1", "com.jcraft.jsch.jce.SHA1");
/*  73 */     config.put("md5", "com.jcraft.jsch.jce.MD5");
/*  74 */     config.put("signature.dss", "com.jcraft.jsch.jce.SignatureDSA");
/*  75 */     config.put("signature.rsa", "com.jcraft.jsch.jce.SignatureRSA");
/*  76 */     config.put("keypairgen.dsa", "com.jcraft.jsch.jce.KeyPairGenDSA");
/*  77 */     config.put("keypairgen.rsa", "com.jcraft.jsch.jce.KeyPairGenRSA");
/*  78 */     config.put("random", "com.jcraft.jsch.jce.Random");
/*     */     
/*  80 */     config.put("none", "com.jcraft.jsch.CipherNone");
/*     */     
/*  82 */     config.put("aes128-cbc", "com.jcraft.jsch.jce.AES128CBC");
/*  83 */     config.put("aes192-cbc", "com.jcraft.jsch.jce.AES192CBC");
/*  84 */     config.put("aes256-cbc", "com.jcraft.jsch.jce.AES256CBC");
/*     */     
/*  86 */     config.put("aes128-ctr", "com.jcraft.jsch.jce.AES128CTR");
/*  87 */     config.put("aes192-ctr", "com.jcraft.jsch.jce.AES192CTR");
/*  88 */     config.put("aes256-ctr", "com.jcraft.jsch.jce.AES256CTR");
/*  89 */     config.put("3des-ctr", "com.jcraft.jsch.jce.TripleDESCTR");
/*  90 */     config.put("arcfour", "com.jcraft.jsch.jce.ARCFOUR");
/*  91 */     config.put("arcfour128", "com.jcraft.jsch.jce.ARCFOUR128");
/*  92 */     config.put("arcfour256", "com.jcraft.jsch.jce.ARCFOUR256");
/*     */     
/*  94 */     config.put("userauth.none", "com.jcraft.jsch.UserAuthNone");
/*  95 */     config.put("userauth.password", "com.jcraft.jsch.UserAuthPassword");
/*  96 */     config.put("userauth.keyboard-interactive", "com.jcraft.jsch.UserAuthKeyboardInteractive");
/*  97 */     config.put("userauth.publickey", "com.jcraft.jsch.UserAuthPublicKey");
/*  98 */     config.put("userauth.gssapi-with-mic", "com.jcraft.jsch.UserAuthGSSAPIWithMIC");
/*  99 */     config.put("gssapi-with-mic.krb5", "com.jcraft.jsch.jgss.GSSContextKrb5");
/*     */     
/* 101 */     config.put("zlib", "com.jcraft.jsch.jcraft.Compression");
/* 102 */     config.put("zlib@openssh.com", "com.jcraft.jsch.jcraft.Compression");
/*     */     
/* 104 */     config.put("StrictHostKeyChecking", "ask");
/* 105 */     config.put("HashKnownHosts", "no");
/*     */     
/* 107 */     config.put("PreferredAuthentications", "gssapi-with-mic,publickey,keyboard-interactive,password");
/*     */     
/* 109 */     config.put("CheckCiphers", "aes256-ctr,aes192-ctr,aes128-ctr,aes256-cbc,aes192-cbc,aes128-cbc,3des-ctr,arcfour,arcfour128,arcfour256");
/*     */   }
/* 111 */   Vector pool = new Vector();
/* 112 */   Vector identities = new Vector();
/* 113 */   private HostKeyRepository known_hosts = null;
/*     */   
/* 115 */   private static final Logger DEVNULL = new Logger() { public void log(int param1Int, String param1String) {} public boolean isEnabled(int param1Int) {
/* 116 */         return false;
/*     */       } }
/*     */   ;
/* 119 */   static Logger logger = DEVNULL;
/*     */ 
/*     */   
/*     */   public JSch() {
/*     */     try {
/* 124 */       String str = (String)System.getProperties().get("os.name");
/* 125 */       if (str != null && str.equals("Mac OS X")) {
/* 126 */         config.put("hmac-sha1", "com.jcraft.jsch.jcraft.HMACSHA1");
/* 127 */         config.put("hmac-md5", "com.jcraft.jsch.jcraft.HMACMD5");
/* 128 */         config.put("hmac-md5-96", "com.jcraft.jsch.jcraft.HMACMD596");
/* 129 */         config.put("hmac-sha1-96", "com.jcraft.jsch.jcraft.HMACSHA196");
/*     */       }
/*     */     
/* 132 */     } catch (Exception exception) {}
/*     */   }
/*     */ 
/*     */   
/*     */   public Session getSession(String paramString1, String paramString2) throws JSchException {
/* 137 */     return getSession(paramString1, paramString2, 22);
/*     */   } public Session getSession(String paramString1, String paramString2, int paramInt) throws JSchException {
/* 139 */     if (paramString1 == null) {
/* 140 */       throw new JSchException("username must not be null.");
/*     */     }
/* 142 */     if (paramString2 == null) {
/* 143 */       throw new JSchException("host must not be null.");
/*     */     }
/* 145 */     Session session = new Session(this);
/* 146 */     session.setUserName(paramString1);
/* 147 */     session.setHost(paramString2);
/* 148 */     session.setPort(paramInt);
/*     */     
/* 150 */     return session;
/*     */   }
/*     */   
/*     */   protected void addSession(Session paramSession) {
/* 154 */     synchronized (this.pool) {
/* 155 */       this.pool.addElement(paramSession);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected boolean removeSession(Session paramSession) {
/* 160 */     synchronized (this.pool) {
/* 161 */       return this.pool.remove(paramSession);
/*     */     } 
/*     */   }
/*     */   public void setHostKeyRepository(HostKeyRepository paramHostKeyRepository) {
/* 165 */     this.known_hosts = paramHostKeyRepository;
/*     */   }
/*     */   
/*     */   public void setKnownHosts(String paramString) throws JSchException {
/* 169 */     if (this.known_hosts == null) this.known_hosts = new KnownHosts(this); 
/* 170 */     if (this.known_hosts instanceof KnownHosts) {
/* 171 */       synchronized (this.known_hosts) {
/* 172 */         ((KnownHosts)this.known_hosts).setKnownHosts(paramString);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   public void setKnownHosts(InputStream paramInputStream) throws JSchException {
/* 178 */     if (this.known_hosts == null) this.known_hosts = new KnownHosts(this); 
/* 179 */     if (this.known_hosts instanceof KnownHosts) {
/* 180 */       synchronized (this.known_hosts) {
/* 181 */         ((KnownHosts)this.known_hosts).setKnownHosts(paramInputStream);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   public HostKeyRepository getHostKeyRepository() {
/* 187 */     if (this.known_hosts == null) this.known_hosts = new KnownHosts(this); 
/* 188 */     return this.known_hosts;
/*     */   }
/*     */   
/*     */   public void addIdentity(String paramString) throws JSchException {
/* 192 */     addIdentity(paramString, (byte[])null);
/*     */   }
/*     */   
/*     */   public void addIdentity(String paramString1, String paramString2) throws JSchException {
/* 196 */     byte[] arrayOfByte = null;
/* 197 */     if (paramString2 != null) {
/* 198 */       arrayOfByte = Util.str2byte(paramString2);
/*     */     }
/* 200 */     addIdentity(paramString1, arrayOfByte);
/* 201 */     if (arrayOfByte != null)
/* 202 */       Util.bzero(arrayOfByte); 
/*     */   }
/*     */   
/*     */   public void addIdentity(String paramString, byte[] paramArrayOfbyte) throws JSchException {
/* 206 */     IdentityFile identityFile = IdentityFile.newInstance(paramString, null, this);
/* 207 */     addIdentity(identityFile, paramArrayOfbyte);
/*     */   }
/*     */   public void addIdentity(String paramString1, String paramString2, byte[] paramArrayOfbyte) throws JSchException {
/* 210 */     IdentityFile identityFile = IdentityFile.newInstance(paramString1, paramString2, this);
/* 211 */     addIdentity(identityFile, paramArrayOfbyte);
/*     */   }
/*     */   
/*     */   public void addIdentity(String paramString, byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[] paramArrayOfbyte3) throws JSchException {
/* 215 */     IdentityFile identityFile = IdentityFile.newInstance(paramString, paramArrayOfbyte1, paramArrayOfbyte2, this);
/* 216 */     addIdentity(identityFile, paramArrayOfbyte3);
/*     */   }
/*     */   
/*     */   public void addIdentity(Identity paramIdentity, byte[] paramArrayOfbyte) throws JSchException {
/* 220 */     if (paramArrayOfbyte != null) {
/*     */       try {
/* 222 */         byte[] arrayOfByte = new byte[paramArrayOfbyte.length];
/* 223 */         System.arraycopy(paramArrayOfbyte, 0, arrayOfByte, 0, paramArrayOfbyte.length);
/* 224 */         paramArrayOfbyte = arrayOfByte;
/* 225 */         paramIdentity.setPassphrase(paramArrayOfbyte);
/*     */       } finally {
/*     */         
/* 228 */         Util.bzero(paramArrayOfbyte);
/*     */       } 
/*     */     }
/* 231 */     synchronized (this.identities) {
/* 232 */       if (!this.identities.contains(paramIdentity)) {
/* 233 */         this.identities.addElement(paramIdentity);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public void removeIdentity(String paramString) throws JSchException {
/* 239 */     synchronized (this.identities) {
/* 240 */       for (byte b = 0; b < this.identities.size(); ) {
/* 241 */         Identity identity = this.identities.elementAt(b);
/* 242 */         if (!identity.getName().equals(paramString)) {
/*     */           b++; continue;
/* 244 */         }  this.identities.removeElement(identity);
/* 245 */         identity.clear();
/*     */         break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public Vector getIdentityNames() throws JSchException {
/* 252 */     Vector vector = new Vector();
/* 253 */     synchronized (this.identities) {
/* 254 */       for (byte b = 0; b < this.identities.size(); b++) {
/* 255 */         Identity identity = this.identities.elementAt(b);
/* 256 */         vector.addElement(identity.getName());
/*     */       } 
/*     */     } 
/* 259 */     return vector;
/*     */   }
/*     */   
/*     */   public void removeAllIdentity() throws JSchException {
/* 263 */     synchronized (this.identities) {
/* 264 */       Vector vector = getIdentityNames();
/* 265 */       for (byte b = 0; b < vector.size(); b++) {
/* 266 */         String str = vector.elementAt(b);
/* 267 */         removeIdentity(str);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public static String getConfig(String paramString) {
/* 273 */     synchronized (config) {
/* 274 */       return (String)config.get(paramString);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void setConfig(Hashtable paramHashtable) {
/* 279 */     synchronized (config) {
/* 280 */       for (Enumeration enumeration = paramHashtable.keys(); enumeration.hasMoreElements(); ) {
/* 281 */         String str = enumeration.nextElement();
/* 282 */         config.put(str, (String)paramHashtable.get(str));
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void setConfig(String paramString1, String paramString2) {
/* 288 */     config.put(paramString1, paramString2);
/*     */   }
/*     */   
/*     */   public static void setLogger(Logger paramLogger) {
/* 292 */     if (paramLogger == null) logger = DEVNULL; 
/* 293 */     logger = paramLogger;
/*     */   }
/*     */   static Logger getLogger() {
/* 296 */     return logger;
/*     */   }
/*     */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/JSch.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */