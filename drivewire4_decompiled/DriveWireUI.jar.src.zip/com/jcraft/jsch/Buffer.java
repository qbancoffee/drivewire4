/*     */ package com.jcraft.jsch;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Buffer
/*     */ {
/*  33 */   final byte[] tmp = new byte[4]; byte[] buffer;
/*     */   int index;
/*     */   int s;
/*     */   
/*     */   public Buffer(int paramInt) {
/*  38 */     this.buffer = new byte[paramInt];
/*  39 */     this.index = 0;
/*  40 */     this.s = 0;
/*     */   }
/*     */   public Buffer(byte[] paramArrayOfbyte) {
/*  43 */     this.buffer = paramArrayOfbyte;
/*  44 */     this.index = 0;
/*  45 */     this.s = 0;
/*     */   } public Buffer() {
/*  47 */     this(20480);
/*     */   } public void putByte(byte paramByte) {
/*  49 */     this.buffer[this.index++] = paramByte;
/*     */   }
/*     */   public void putByte(byte[] paramArrayOfbyte) {
/*  52 */     putByte(paramArrayOfbyte, 0, paramArrayOfbyte.length);
/*     */   }
/*     */   public void putByte(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
/*  55 */     System.arraycopy(paramArrayOfbyte, paramInt1, this.buffer, this.index, paramInt2);
/*  56 */     this.index += paramInt2;
/*     */   }
/*     */   public void putString(byte[] paramArrayOfbyte) {
/*  59 */     putString(paramArrayOfbyte, 0, paramArrayOfbyte.length);
/*     */   }
/*     */   public void putString(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
/*  62 */     putInt(paramInt2);
/*  63 */     putByte(paramArrayOfbyte, paramInt1, paramInt2);
/*     */   }
/*     */   public void putInt(int paramInt) {
/*  66 */     this.tmp[0] = (byte)(paramInt >>> 24);
/*  67 */     this.tmp[1] = (byte)(paramInt >>> 16);
/*  68 */     this.tmp[2] = (byte)(paramInt >>> 8);
/*  69 */     this.tmp[3] = (byte)paramInt;
/*  70 */     System.arraycopy(this.tmp, 0, this.buffer, this.index, 4);
/*  71 */     this.index += 4;
/*     */   }
/*     */   public void putLong(long paramLong) {
/*  74 */     this.tmp[0] = (byte)(int)(paramLong >>> 56L);
/*  75 */     this.tmp[1] = (byte)(int)(paramLong >>> 48L);
/*  76 */     this.tmp[2] = (byte)(int)(paramLong >>> 40L);
/*  77 */     this.tmp[3] = (byte)(int)(paramLong >>> 32L);
/*  78 */     System.arraycopy(this.tmp, 0, this.buffer, this.index, 4);
/*  79 */     this.tmp[0] = (byte)(int)(paramLong >>> 24L);
/*  80 */     this.tmp[1] = (byte)(int)(paramLong >>> 16L);
/*  81 */     this.tmp[2] = (byte)(int)(paramLong >>> 8L);
/*  82 */     this.tmp[3] = (byte)(int)paramLong;
/*  83 */     System.arraycopy(this.tmp, 0, this.buffer, this.index + 4, 4);
/*  84 */     this.index += 8;
/*     */   }
/*     */   void skip(int paramInt) {
/*  87 */     this.index += paramInt;
/*     */   }
/*     */   void putPad(int paramInt) {
/*  90 */     while (paramInt > 0) {
/*  91 */       this.buffer[this.index++] = 0;
/*  92 */       paramInt--;
/*     */     } 
/*     */   }
/*     */   public void putMPInt(byte[] paramArrayOfbyte) {
/*  96 */     int i = paramArrayOfbyte.length;
/*  97 */     if ((paramArrayOfbyte[0] & 0x80) != 0) {
/*  98 */       i++;
/*  99 */       putInt(i);
/* 100 */       putByte((byte)0);
/*     */     } else {
/*     */       
/* 103 */       putInt(i);
/*     */     } 
/* 105 */     putByte(paramArrayOfbyte);
/*     */   }
/*     */   public int getLength() {
/* 108 */     return this.index - this.s;
/*     */   }
/*     */   public int getOffSet() {
/* 111 */     return this.s;
/*     */   }
/*     */   public void setOffSet(int paramInt) {
/* 114 */     this.s = paramInt;
/*     */   }
/*     */   public long getLong() {
/* 117 */     long l = getInt() & 0xFFFFFFFFL;
/* 118 */     l = l << 32L | getInt() & 0xFFFFFFFFL;
/* 119 */     return l;
/*     */   }
/*     */   public int getInt() {
/* 122 */     int i = getShort();
/* 123 */     i = i << 16 & 0xFFFF0000 | getShort() & 0xFFFF;
/* 124 */     return i;
/*     */   }
/*     */   int getShort() {
/* 127 */     int i = getByte();
/* 128 */     i = i << 8 & 0xFF00 | getByte() & 0xFF;
/* 129 */     return i;
/*     */   }
/*     */   public int getByte() {
/* 132 */     return this.buffer[this.s++] & 0xFF;
/*     */   }
/*     */   public void getByte(byte[] paramArrayOfbyte) {
/* 135 */     getByte(paramArrayOfbyte, 0, paramArrayOfbyte.length);
/*     */   }
/*     */   void getByte(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
/* 138 */     System.arraycopy(this.buffer, this.s, paramArrayOfbyte, paramInt1, paramInt2);
/* 139 */     this.s += paramInt2;
/*     */   }
/*     */   public int getByte(int paramInt) {
/* 142 */     int i = this.s;
/* 143 */     this.s += paramInt;
/* 144 */     return i;
/*     */   }
/*     */   public byte[] getMPInt() {
/* 147 */     int i = getInt();
/* 148 */     byte[] arrayOfByte = new byte[i];
/* 149 */     getByte(arrayOfByte, 0, i);
/* 150 */     return arrayOfByte;
/*     */   }
/*     */   public byte[] getMPIntBits() {
/* 153 */     int i = getInt();
/* 154 */     int j = (i + 7) / 8;
/* 155 */     byte[] arrayOfByte = new byte[j];
/* 156 */     getByte(arrayOfByte, 0, j);
/* 157 */     if ((arrayOfByte[0] & 0x80) != 0) {
/* 158 */       byte[] arrayOfByte1 = new byte[arrayOfByte.length + 1];
/* 159 */       arrayOfByte1[0] = 0;
/* 160 */       System.arraycopy(arrayOfByte, 0, arrayOfByte1, 1, arrayOfByte.length);
/* 161 */       arrayOfByte = arrayOfByte1;
/*     */     } 
/* 163 */     return arrayOfByte;
/*     */   }
/*     */   public byte[] getString() {
/* 166 */     int i = getInt();
/* 167 */     byte[] arrayOfByte = new byte[i];
/* 168 */     getByte(arrayOfByte, 0, i);
/* 169 */     return arrayOfByte;
/*     */   }
/*     */   byte[] getString(int[] paramArrayOfint1, int[] paramArrayOfint2) {
/* 172 */     int i = getInt();
/* 173 */     paramArrayOfint1[0] = getByte(i);
/* 174 */     paramArrayOfint2[0] = i;
/* 175 */     return this.buffer;
/*     */   }
/*     */   public void reset() {
/* 178 */     this.index = 0;
/* 179 */     this.s = 0;
/*     */   }
/*     */   public void shift() {
/* 182 */     if (this.s == 0)
/* 183 */       return;  System.arraycopy(this.buffer, this.s, this.buffer, 0, this.index - this.s);
/* 184 */     this.index -= this.s;
/* 185 */     this.s = 0;
/*     */   }
/*     */   void rewind() {
/* 188 */     this.s = 0;
/*     */   }
/*     */   
/*     */   byte getCommand() {
/* 192 */     return this.buffer[5];
/*     */   }
/*     */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/Buffer.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */