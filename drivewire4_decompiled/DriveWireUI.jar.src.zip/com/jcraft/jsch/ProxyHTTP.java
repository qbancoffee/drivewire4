/*     */ package com.jcraft.jsch;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.net.Socket;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ProxyHTTP
/*     */   implements Proxy
/*     */ {
/*  36 */   private static int DEFAULTPORT = 80;
/*     */   
/*     */   private String proxy_host;
/*     */   private int proxy_port;
/*     */   private InputStream in;
/*     */   private OutputStream out;
/*     */   private Socket socket;
/*     */   private String user;
/*     */   private String passwd;
/*     */   
/*     */   public ProxyHTTP(String paramString) {
/*  47 */     int i = DEFAULTPORT;
/*  48 */     String str = paramString;
/*  49 */     if (paramString.indexOf(':') != -1) {
/*     */       try {
/*  51 */         str = paramString.substring(0, paramString.indexOf(':'));
/*  52 */         i = Integer.parseInt(paramString.substring(paramString.indexOf(':') + 1));
/*     */       }
/*  54 */       catch (Exception exception) {}
/*     */     }
/*     */     
/*  57 */     this.proxy_host = str;
/*  58 */     this.proxy_port = i;
/*     */   }
/*     */   public ProxyHTTP(String paramString, int paramInt) {
/*  61 */     this.proxy_host = paramString;
/*  62 */     this.proxy_port = paramInt;
/*     */   }
/*     */   public void setUserPasswd(String paramString1, String paramString2) {
/*  65 */     this.user = paramString1;
/*  66 */     this.passwd = paramString2;
/*     */   }
/*     */   public void connect(SocketFactory paramSocketFactory, String paramString, int paramInt1, int paramInt2) throws JSchException {
/*     */     try {
/*  70 */       if (paramSocketFactory == null) {
/*  71 */         this.socket = Util.createSocket(this.proxy_host, this.proxy_port, paramInt2);
/*  72 */         this.in = this.socket.getInputStream();
/*  73 */         this.out = this.socket.getOutputStream();
/*     */       } else {
/*     */         
/*  76 */         this.socket = paramSocketFactory.createSocket(this.proxy_host, this.proxy_port);
/*  77 */         this.in = paramSocketFactory.getInputStream(this.socket);
/*  78 */         this.out = paramSocketFactory.getOutputStream(this.socket);
/*     */       } 
/*  80 */       if (paramInt2 > 0) {
/*  81 */         this.socket.setSoTimeout(paramInt2);
/*     */       }
/*  83 */       this.socket.setTcpNoDelay(true);
/*     */       
/*  85 */       this.out.write(("CONNECT " + paramString + ":" + paramInt1 + " HTTP/1.0\r\n").getBytes());
/*     */       
/*  87 */       if (this.user != null && this.passwd != null) {
/*  88 */         byte[] arrayOfByte = (this.user + ":" + this.passwd).getBytes();
/*  89 */         arrayOfByte = Util.toBase64(arrayOfByte, 0, arrayOfByte.length);
/*  90 */         this.out.write("Proxy-Authorization: Basic ".getBytes());
/*  91 */         this.out.write(arrayOfByte);
/*  92 */         this.out.write("\r\n".getBytes());
/*     */       } 
/*     */       
/*  95 */       this.out.write("\r\n".getBytes());
/*  96 */       this.out.flush();
/*     */       
/*  98 */       int i = 0;
/*     */       
/* 100 */       StringBuffer stringBuffer = new StringBuffer();
/* 101 */       while (!i) {
/* 102 */         i = this.in.read(); if (i != 13) { stringBuffer.append((char)i); continue; }
/* 103 */          i = this.in.read(); if (i != 10)
/*     */           continue;  break;
/*     */       } 
/* 106 */       if (i < 0) {
/* 107 */         throw new IOException();
/*     */       }
/*     */       
/* 110 */       String str1 = stringBuffer.toString();
/* 111 */       String str2 = "Unknow reason";
/* 112 */       int j = -1;
/*     */       try {
/* 114 */         i = str1.indexOf(' ');
/* 115 */         int k = str1.indexOf(' ', i + 1);
/* 116 */         j = Integer.parseInt(str1.substring(i + 1, k));
/* 117 */         str2 = str1.substring(k + 1);
/*     */       }
/* 119 */       catch (Exception exception) {}
/*     */       
/* 121 */       if (j != 200) {
/* 122 */         throw new IOException("proxy error: " + str2);
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 135 */       byte b = 0;
/*     */       do {
/* 137 */         b = 0;
/* 138 */         while (i >= 0) {
/* 139 */           i = this.in.read(); if (i != 13) { b++; continue; }
/* 140 */            i = this.in.read(); if (i != 10)
/*     */             continue;  break;
/*     */         } 
/* 143 */         if (i < 0) {
/* 144 */           throw new IOException();
/*     */         }
/* 146 */       } while (b != 0);
/*     */     }
/*     */     catch (RuntimeException runtimeException) {
/*     */       
/* 150 */       throw runtimeException;
/*     */     } catch (Exception exception) {
/*     */       try {
/* 153 */         if (this.socket != null) this.socket.close(); 
/* 154 */       } catch (Exception exception1) {}
/*     */       
/* 156 */       String str = "ProxyHTTP: " + exception.toString();
/* 157 */       if (exception instanceof Throwable)
/* 158 */         throw new JSchException(str, exception); 
/* 159 */       throw new JSchException(str);
/*     */     } 
/*     */   }
/* 162 */   public InputStream getInputStream() { return this.in; }
/* 163 */   public OutputStream getOutputStream() { return this.out; } public Socket getSocket() {
/* 164 */     return this.socket;
/*     */   } public void close() {
/*     */     try {
/* 167 */       if (this.in != null) this.in.close(); 
/* 168 */       if (this.out != null) this.out.close(); 
/* 169 */       if (this.socket != null) this.socket.close();
/*     */     
/* 171 */     } catch (Exception exception) {}
/*     */     
/* 173 */     this.in = null;
/* 174 */     this.out = null;
/* 175 */     this.socket = null;
/*     */   }
/*     */   public static int getDefaultPort() {
/* 178 */     return DEFAULTPORT;
/*     */   }
/*     */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/ProxyHTTP.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */