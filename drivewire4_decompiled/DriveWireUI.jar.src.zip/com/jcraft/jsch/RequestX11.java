/*    */ package com.jcraft.jsch;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class RequestX11
/*    */   extends Request
/*    */ {
/*    */   public void setCookie(String paramString) {
/* 34 */     ChannelX11.cookie = paramString.getBytes();
/*    */   }
/*    */   public void request(Session paramSession, Channel paramChannel) throws Exception {
/* 37 */     super.request(paramSession, paramChannel);
/*    */     
/* 39 */     Buffer buffer = new Buffer();
/* 40 */     Packet packet = new Packet(buffer);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */     
/* 50 */     packet.reset();
/* 51 */     buffer.putByte((byte)98);
/* 52 */     buffer.putInt(paramChannel.getRecipient());
/* 53 */     buffer.putString("x11-req".getBytes());
/* 54 */     buffer.putByte((byte)(waitForReply() ? 1 : 0));
/* 55 */     buffer.putByte((byte)0);
/* 56 */     buffer.putString("MIT-MAGIC-COOKIE-1".getBytes());
/* 57 */     buffer.putString(ChannelX11.getFakedCookie(paramSession));
/* 58 */     buffer.putInt(0);
/* 59 */     write(packet);
/*    */     
/* 61 */     paramSession.x11_forwarding = true;
/*    */   }
/*    */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/RequestX11.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */