/*     */ package com.jcraft.jsch.jce;
/*     */ 
/*     */ import com.jcraft.jsch.SignatureDSA;
/*     */ import java.math.BigInteger;
/*     */ import java.security.KeyFactory;
/*     */ import java.security.PrivateKey;
/*     */ import java.security.PublicKey;
/*     */ import java.security.Signature;
/*     */ import java.security.spec.DSAPrivateKeySpec;
/*     */ import java.security.spec.DSAPublicKeySpec;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SignatureDSA
/*     */   implements SignatureDSA
/*     */ {
/*     */   Signature signature;
/*     */   KeyFactory keyFactory;
/*     */   
/*     */   public void init() throws Exception {
/*  42 */     this.signature = Signature.getInstance("SHA1withDSA");
/*  43 */     this.keyFactory = KeyFactory.getInstance("DSA");
/*     */   }
/*     */   public void setPubKey(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[] paramArrayOfbyte3, byte[] paramArrayOfbyte4) throws Exception {
/*  46 */     DSAPublicKeySpec dSAPublicKeySpec = new DSAPublicKeySpec(new BigInteger(paramArrayOfbyte1), new BigInteger(paramArrayOfbyte2), new BigInteger(paramArrayOfbyte3), new BigInteger(paramArrayOfbyte4));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  51 */     PublicKey publicKey = this.keyFactory.generatePublic(dSAPublicKeySpec);
/*  52 */     this.signature.initVerify(publicKey);
/*     */   }
/*     */   public void setPrvKey(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, byte[] paramArrayOfbyte3, byte[] paramArrayOfbyte4) throws Exception {
/*  55 */     DSAPrivateKeySpec dSAPrivateKeySpec = new DSAPrivateKeySpec(new BigInteger(paramArrayOfbyte1), new BigInteger(paramArrayOfbyte2), new BigInteger(paramArrayOfbyte3), new BigInteger(paramArrayOfbyte4));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  60 */     PrivateKey privateKey = this.keyFactory.generatePrivate(dSAPrivateKeySpec);
/*  61 */     this.signature.initSign(privateKey);
/*     */   }
/*     */   public byte[] sign() throws Exception {
/*  64 */     byte[] arrayOfByte1 = this.signature.sign();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  74 */     int i = 0;
/*  75 */     int j = 3;
/*  76 */     i = arrayOfByte1[j++] & 0xFF;
/*     */     
/*  78 */     byte[] arrayOfByte2 = new byte[i];
/*  79 */     System.arraycopy(arrayOfByte1, j, arrayOfByte2, 0, arrayOfByte2.length);
/*  80 */     j = j + i + 1;
/*  81 */     i = arrayOfByte1[j++] & 0xFF;
/*     */     
/*  83 */     byte[] arrayOfByte3 = new byte[i];
/*  84 */     System.arraycopy(arrayOfByte1, j, arrayOfByte3, 0, arrayOfByte3.length);
/*     */     
/*  86 */     byte[] arrayOfByte4 = new byte[40];
/*     */ 
/*     */ 
/*     */     
/*  90 */     System.arraycopy(arrayOfByte2, (arrayOfByte2.length > 20) ? 1 : 0, arrayOfByte4, (arrayOfByte2.length > 20) ? 0 : (20 - arrayOfByte2.length), (arrayOfByte2.length > 20) ? 20 : arrayOfByte2.length);
/*     */ 
/*     */     
/*  93 */     System.arraycopy(arrayOfByte3, (arrayOfByte3.length > 20) ? 1 : 0, arrayOfByte4, (arrayOfByte3.length > 20) ? 20 : (40 - arrayOfByte3.length), (arrayOfByte3.length > 20) ? 20 : arrayOfByte3.length);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 100 */     return arrayOfByte4;
/*     */   }
/*     */   public void update(byte[] paramArrayOfbyte) throws Exception {
/* 103 */     this.signature.update(paramArrayOfbyte);
/*     */   }
/*     */   public boolean verify(byte[] paramArrayOfbyte) throws Exception {
/* 106 */     int i = 0;
/* 107 */     int j = 0;
/*     */ 
/*     */     
/* 110 */     if (paramArrayOfbyte[0] == 0 && paramArrayOfbyte[1] == 0 && paramArrayOfbyte[2] == 0) {
/* 111 */       j = paramArrayOfbyte[i++] << 24 & 0xFF000000 | paramArrayOfbyte[i++] << 16 & 0xFF0000 | paramArrayOfbyte[i++] << 8 & 0xFF00 | paramArrayOfbyte[i++] & 0xFF;
/*     */       
/* 113 */       i += j;
/* 114 */       j = paramArrayOfbyte[i++] << 24 & 0xFF000000 | paramArrayOfbyte[i++] << 16 & 0xFF0000 | paramArrayOfbyte[i++] << 8 & 0xFF00 | paramArrayOfbyte[i++] & 0xFF;
/*     */       
/* 116 */       byte[] arrayOfByte1 = new byte[j];
/* 117 */       System.arraycopy(paramArrayOfbyte, i, arrayOfByte1, 0, j); paramArrayOfbyte = arrayOfByte1;
/*     */     } 
/*     */ 
/*     */     
/* 121 */     byte b1 = ((paramArrayOfbyte[0] & 0x80) != 0) ? 1 : 0;
/* 122 */     byte b2 = ((paramArrayOfbyte[20] & 0x80) != 0) ? 1 : 0;
/*     */ 
/*     */     
/* 125 */     int k = paramArrayOfbyte.length + 6 + b1 + b2;
/* 126 */     byte[] arrayOfByte = new byte[k];
/* 127 */     arrayOfByte[0] = 48; arrayOfByte[1] = 44;
/* 128 */     arrayOfByte[1] = (byte)(arrayOfByte[1] + b1); arrayOfByte[1] = (byte)(arrayOfByte[1] + b2);
/* 129 */     arrayOfByte[2] = 2; arrayOfByte[3] = 20;
/* 130 */     arrayOfByte[3] = (byte)(arrayOfByte[3] + b1);
/* 131 */     System.arraycopy(paramArrayOfbyte, 0, arrayOfByte, 4 + b1, 20);
/* 132 */     arrayOfByte[4 + arrayOfByte[3]] = 2; arrayOfByte[5 + arrayOfByte[3]] = 20;
/* 133 */     arrayOfByte[5 + arrayOfByte[3]] = (byte)(arrayOfByte[5 + arrayOfByte[3]] + b2);
/* 134 */     System.arraycopy(paramArrayOfbyte, 20, arrayOfByte, 6 + arrayOfByte[3] + b2, 20);
/* 135 */     paramArrayOfbyte = arrayOfByte;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 145 */     return this.signature.verify(paramArrayOfbyte);
/*     */   }
/*     */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/jce/SignatureDSA.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */