/*    */ package com.jcraft.jsch.jce;
/*    */ 
/*    */ import com.jcraft.jsch.Cipher;
/*    */ import javax.crypto.Cipher;
/*    */ import javax.crypto.SecretKey;
/*    */ import javax.crypto.SecretKeyFactory;
/*    */ import javax.crypto.spec.DESedeKeySpec;
/*    */ import javax.crypto.spec.IvParameterSpec;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class TripleDESCTR
/*    */   implements Cipher
/*    */ {
/*    */   private static final int ivsize = 8;
/*    */   private static final int bsize = 24;
/*    */   private Cipher cipher;
/*    */   
/*    */   public int getIVSize() {
/* 40 */     return 8; } public int getBlockSize() {
/* 41 */     return 24;
/*    */   } public void init(int paramInt, byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) throws Exception {
/* 43 */     String str = "NoPadding";
/*    */ 
/*    */     
/* 46 */     if (paramArrayOfbyte2.length > 8) {
/* 47 */       byte[] arrayOfByte = new byte[8];
/* 48 */       System.arraycopy(paramArrayOfbyte2, 0, arrayOfByte, 0, arrayOfByte.length);
/* 49 */       paramArrayOfbyte2 = arrayOfByte;
/*    */     } 
/* 51 */     if (paramArrayOfbyte1.length > 24) {
/* 52 */       byte[] arrayOfByte = new byte[24];
/* 53 */       System.arraycopy(paramArrayOfbyte1, 0, arrayOfByte, 0, arrayOfByte.length);
/* 54 */       paramArrayOfbyte1 = arrayOfByte;
/*    */     } 
/*    */     
/*    */     try {
/* 58 */       this.cipher = Cipher.getInstance("DESede/CTR/" + str);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 67 */       DESedeKeySpec dESedeKeySpec = new DESedeKeySpec(paramArrayOfbyte1);
/* 68 */       SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("DESede");
/* 69 */       SecretKey secretKey = secretKeyFactory.generateSecret(dESedeKeySpec);
/* 70 */       this.cipher.init((paramInt == 0) ? 1 : 2, secretKey, new IvParameterSpec(paramArrayOfbyte2));
/*    */     
/*    */     }
/*    */     catch (Exception exception) {
/*    */ 
/*    */       
/* 76 */       this.cipher = null;
/* 77 */       throw exception;
/*    */     } 
/*    */   }
/*    */   public void update(byte[] paramArrayOfbyte1, int paramInt1, int paramInt2, byte[] paramArrayOfbyte2, int paramInt3) throws Exception {
/* 81 */     this.cipher.update(paramArrayOfbyte1, paramInt1, paramInt2, paramArrayOfbyte2, paramInt3);
/*    */   }
/*    */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/jce/TripleDESCTR.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */