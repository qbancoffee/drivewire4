/*    */ package com.jcraft.jsch.jce;
/*    */ 
/*    */ import com.jcraft.jsch.HASH;
/*    */ import java.security.MessageDigest;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class MD5
/*    */   implements HASH
/*    */ {
/*    */   MessageDigest md;
/*    */   
/*    */   public int getBlockSize() {
/* 38 */     return 16; } public void init() throws Exception {
/*    */     try {
/* 40 */       this.md = MessageDigest.getInstance("MD5");
/*    */     } catch (Exception exception) {
/* 42 */       System.err.println(exception);
/*    */     } 
/*    */   }
/*    */   public void update(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) throws Exception {
/* 46 */     this.md.update(paramArrayOfbyte, paramInt1, paramInt2);
/*    */   }
/*    */   public byte[] digest() throws Exception {
/* 49 */     return this.md.digest();
/*    */   }
/*    */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/jce/MD5.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */