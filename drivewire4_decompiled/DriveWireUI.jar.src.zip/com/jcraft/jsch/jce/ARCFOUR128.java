/*    */ package com.jcraft.jsch.jce;
/*    */ 
/*    */ import com.jcraft.jsch.Cipher;
/*    */ import javax.crypto.Cipher;
/*    */ import javax.crypto.spec.SecretKeySpec;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ARCFOUR128
/*    */   implements Cipher
/*    */ {
/*    */   private static final int ivsize = 8;
/*    */   private static final int bsize = 16;
/*    */   private static final int skip = 1536;
/*    */   private Cipher cipher;
/*    */   
/*    */   public int getIVSize() {
/* 41 */     return 8; } public int getBlockSize() {
/* 42 */     return 16;
/*    */   }
/*    */   public void init(int paramInt, byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) throws Exception {
/* 45 */     if (paramArrayOfbyte1.length > 16) {
/* 46 */       byte[] arrayOfByte = new byte[16];
/* 47 */       System.arraycopy(paramArrayOfbyte1, 0, arrayOfByte, 0, arrayOfByte.length);
/* 48 */       paramArrayOfbyte1 = arrayOfByte;
/*    */     } 
/*    */     try {
/* 51 */       this.cipher = Cipher.getInstance("RC4");
/* 52 */       SecretKeySpec secretKeySpec = new SecretKeySpec(paramArrayOfbyte1, "RC4");
/* 53 */       this.cipher.init((paramInt == 0) ? 1 : 2, secretKeySpec);
/*    */ 
/*    */ 
/*    */       
/* 57 */       byte[] arrayOfByte = new byte[1];
/* 58 */       for (byte b = 0; b < '؀'; b++) {
/* 59 */         this.cipher.update(arrayOfByte, 0, 1, arrayOfByte, 0);
/*    */       }
/*    */     } catch (Exception exception) {
/*    */       
/* 63 */       this.cipher = null;
/* 64 */       throw exception;
/*    */     } 
/*    */   }
/*    */   public void update(byte[] paramArrayOfbyte1, int paramInt1, int paramInt2, byte[] paramArrayOfbyte2, int paramInt3) throws Exception {
/* 68 */     this.cipher.update(paramArrayOfbyte1, paramInt1, paramInt2, paramArrayOfbyte2, paramInt3);
/*    */   }
/*    */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/jce/ARCFOUR128.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */