/*    */ package com.jcraft.jsch.jce;
/*    */ 
/*    */ import com.jcraft.jsch.MAC;
/*    */ import javax.crypto.Mac;
/*    */ import javax.crypto.ShortBufferException;
/*    */ import javax.crypto.spec.SecretKeySpec;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HMACMD596
/*    */   implements MAC
/*    */ {
/*    */   private static final String name = "hmac-md5-96";
/*    */   private static final int bsize = 12;
/*    */   private Mac mac;
/*    */   
/*    */   public int getBlockSize() {
/* 40 */     return 12;
/*    */   } public void init(byte[] paramArrayOfbyte) throws Exception {
/* 42 */     if (paramArrayOfbyte.length > 16) {
/* 43 */       byte[] arrayOfByte = new byte[16];
/* 44 */       System.arraycopy(paramArrayOfbyte, 0, arrayOfByte, 0, 16);
/* 45 */       paramArrayOfbyte = arrayOfByte;
/*    */     } 
/* 47 */     SecretKeySpec secretKeySpec = new SecretKeySpec(paramArrayOfbyte, "HmacMD5");
/* 48 */     this.mac = Mac.getInstance("HmacMD5");
/* 49 */     this.mac.init(secretKeySpec);
/*    */   }
/* 51 */   private final byte[] tmp = new byte[4];
/*    */   public void update(int paramInt) {
/* 53 */     this.tmp[0] = (byte)(paramInt >>> 24);
/* 54 */     this.tmp[1] = (byte)(paramInt >>> 16);
/* 55 */     this.tmp[2] = (byte)(paramInt >>> 8);
/* 56 */     this.tmp[3] = (byte)paramInt;
/* 57 */     update(this.tmp, 0, 4);
/*    */   }
/*    */   
/*    */   public void update(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
/* 61 */     this.mac.update(paramArrayOfbyte, paramInt1, paramInt2);
/*    */   }
/*    */   
/* 64 */   private final byte[] _buf16 = new byte[16];
/*    */   public void doFinal(byte[] paramArrayOfbyte, int paramInt) {
/*    */     try {
/* 67 */       this.mac.doFinal(this._buf16, 0);
/*    */     }
/* 69 */     catch (ShortBufferException shortBufferException) {}
/*    */     
/* 71 */     System.arraycopy(this._buf16, 0, paramArrayOfbyte, 0, 12);
/*    */   }
/*    */   
/*    */   public String getName() {
/* 75 */     return "hmac-md5-96";
/*    */   }
/*    */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/jce/HMACMD596.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */