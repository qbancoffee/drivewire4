/*    */ package com.jcraft.jsch.jce;
/*    */ 
/*    */ import com.jcraft.jsch.Cipher;
/*    */ import javax.crypto.Cipher;
/*    */ import javax.crypto.spec.IvParameterSpec;
/*    */ import javax.crypto.spec.SecretKeySpec;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class BlowfishCBC
/*    */   implements Cipher
/*    */ {
/*    */   private static final int ivsize = 8;
/*    */   private static final int bsize = 16;
/*    */   private Cipher cipher;
/*    */   
/*    */   public int getIVSize() {
/* 39 */     return 8; } public int getBlockSize() {
/* 40 */     return 16;
/*    */   } public void init(int paramInt, byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) throws Exception {
/* 42 */     String str = "NoPadding";
/*    */ 
/*    */     
/* 45 */     if (paramArrayOfbyte2.length > 8) {
/* 46 */       byte[] arrayOfByte = new byte[8];
/* 47 */       System.arraycopy(paramArrayOfbyte2, 0, arrayOfByte, 0, arrayOfByte.length);
/* 48 */       paramArrayOfbyte2 = arrayOfByte;
/*    */     } 
/* 50 */     if (paramArrayOfbyte1.length > 16) {
/* 51 */       byte[] arrayOfByte = new byte[16];
/* 52 */       System.arraycopy(paramArrayOfbyte1, 0, arrayOfByte, 0, arrayOfByte.length);
/* 53 */       paramArrayOfbyte1 = arrayOfByte;
/*    */     } 
/*    */     try {
/* 56 */       SecretKeySpec secretKeySpec = new SecretKeySpec(paramArrayOfbyte1, "Blowfish");
/* 57 */       this.cipher = Cipher.getInstance("Blowfish/CBC/" + str);
/* 58 */       this.cipher.init((paramInt == 0) ? 1 : 2, secretKeySpec, new IvParameterSpec(paramArrayOfbyte2));
/*    */     
/*    */     }
/*    */     catch (Exception exception) {
/*    */ 
/*    */       
/* 64 */       throw exception;
/*    */     } 
/*    */   }
/*    */   public void update(byte[] paramArrayOfbyte1, int paramInt1, int paramInt2, byte[] paramArrayOfbyte2, int paramInt3) throws Exception {
/* 68 */     this.cipher.update(paramArrayOfbyte1, paramInt1, paramInt2, paramArrayOfbyte2, paramInt3);
/*    */   }
/*    */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/jce/BlowfishCBC.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */