/*    */ package com.jcraft.jsch.jce;
/*    */ 
/*    */ import com.jcraft.jsch.DH;
/*    */ import java.math.BigInteger;
/*    */ import java.security.KeyFactory;
/*    */ import java.security.KeyPair;
/*    */ import java.security.KeyPairGenerator;
/*    */ import java.security.PublicKey;
/*    */ import javax.crypto.KeyAgreement;
/*    */ import javax.crypto.interfaces.DHPublicKey;
/*    */ import javax.crypto.spec.DHParameterSpec;
/*    */ import javax.crypto.spec.DHPublicKeySpec;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class DH
/*    */   implements DH
/*    */ {
/*    */   BigInteger p;
/*    */   BigInteger g;
/*    */   BigInteger e;
/*    */   byte[] e_array;
/*    */   BigInteger f;
/*    */   BigInteger K;
/*    */   byte[] K_array;
/*    */   private KeyPairGenerator myKpairGen;
/*    */   private KeyAgreement myKeyAgree;
/*    */   
/*    */   public void init() throws Exception {
/* 49 */     this.myKpairGen = KeyPairGenerator.getInstance("DH");
/*    */     
/* 51 */     this.myKeyAgree = KeyAgreement.getInstance("DH");
/*    */   }
/*    */   
/*    */   public byte[] getE() throws Exception {
/* 55 */     if (this.e == null) {
/* 56 */       DHParameterSpec dHParameterSpec = new DHParameterSpec(this.p, this.g);
/* 57 */       this.myKpairGen.initialize(dHParameterSpec);
/* 58 */       KeyPair keyPair = this.myKpairGen.generateKeyPair();
/* 59 */       this.myKeyAgree.init(keyPair.getPrivate());
/*    */       
/* 61 */       byte[] arrayOfByte = keyPair.getPublic().getEncoded();
/* 62 */       this.e = ((DHPublicKey)keyPair.getPublic()).getY();
/* 63 */       this.e_array = this.e.toByteArray();
/*    */     } 
/* 65 */     return this.e_array;
/*    */   }
/*    */   public byte[] getK() throws Exception {
/* 68 */     if (this.K == null) {
/* 69 */       KeyFactory keyFactory = KeyFactory.getInstance("DH");
/* 70 */       DHPublicKeySpec dHPublicKeySpec = new DHPublicKeySpec(this.f, this.p, this.g);
/* 71 */       PublicKey publicKey = keyFactory.generatePublic(dHPublicKeySpec);
/* 72 */       this.myKeyAgree.doPhase(publicKey, true);
/* 73 */       byte[] arrayOfByte = this.myKeyAgree.generateSecret();
/* 74 */       this.K = new BigInteger(arrayOfByte);
/* 75 */       this.K_array = this.K.toByteArray();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 81 */       this.K_array = arrayOfByte;
/*    */     } 
/* 83 */     return this.K_array;
/*    */   }
/* 85 */   public void setP(byte[] paramArrayOfbyte) { setP(new BigInteger(paramArrayOfbyte)); }
/* 86 */   public void setG(byte[] paramArrayOfbyte) { setG(new BigInteger(paramArrayOfbyte)); }
/* 87 */   public void setF(byte[] paramArrayOfbyte) { setF(new BigInteger(paramArrayOfbyte)); }
/* 88 */   void setP(BigInteger paramBigInteger) { this.p = paramBigInteger; }
/* 89 */   void setG(BigInteger paramBigInteger) { this.g = paramBigInteger; } void setF(BigInteger paramBigInteger) {
/* 90 */     this.f = paramBigInteger;
/*    */   }
/*    */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/jce/DH.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */