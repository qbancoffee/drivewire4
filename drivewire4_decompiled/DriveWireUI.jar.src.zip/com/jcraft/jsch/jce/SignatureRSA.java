/*    */ package com.jcraft.jsch.jce;
/*    */ 
/*    */ import com.jcraft.jsch.SignatureRSA;
/*    */ import java.math.BigInteger;
/*    */ import java.security.KeyFactory;
/*    */ import java.security.PrivateKey;
/*    */ import java.security.PublicKey;
/*    */ import java.security.Signature;
/*    */ import java.security.spec.RSAPrivateKeySpec;
/*    */ import java.security.spec.RSAPublicKeySpec;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SignatureRSA
/*    */   implements SignatureRSA
/*    */ {
/*    */   Signature signature;
/*    */   KeyFactory keyFactory;
/*    */   
/*    */   public void init() throws Exception {
/* 42 */     this.signature = Signature.getInstance("SHA1withRSA");
/* 43 */     this.keyFactory = KeyFactory.getInstance("RSA");
/*    */   }
/*    */   public void setPubKey(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) throws Exception {
/* 46 */     RSAPublicKeySpec rSAPublicKeySpec = new RSAPublicKeySpec(new BigInteger(paramArrayOfbyte2), new BigInteger(paramArrayOfbyte1));
/*    */ 
/*    */     
/* 49 */     PublicKey publicKey = this.keyFactory.generatePublic(rSAPublicKeySpec);
/* 50 */     this.signature.initVerify(publicKey);
/*    */   }
/*    */   public void setPrvKey(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) throws Exception {
/* 53 */     RSAPrivateKeySpec rSAPrivateKeySpec = new RSAPrivateKeySpec(new BigInteger(paramArrayOfbyte2), new BigInteger(paramArrayOfbyte1));
/*    */ 
/*    */     
/* 56 */     PrivateKey privateKey = this.keyFactory.generatePrivate(rSAPrivateKeySpec);
/* 57 */     this.signature.initSign(privateKey);
/*    */   }
/*    */   public byte[] sign() throws Exception {
/* 60 */     return this.signature.sign();
/*    */   }
/*    */   
/*    */   public void update(byte[] paramArrayOfbyte) throws Exception {
/* 64 */     this.signature.update(paramArrayOfbyte);
/*    */   }
/*    */   public boolean verify(byte[] paramArrayOfbyte) throws Exception {
/* 67 */     int i = 0;
/* 68 */     int j = 0;
/*    */ 
/*    */     
/* 71 */     if (paramArrayOfbyte[0] == 0 && paramArrayOfbyte[1] == 0 && paramArrayOfbyte[2] == 0) {
/* 72 */       j = paramArrayOfbyte[i++] << 24 & 0xFF000000 | paramArrayOfbyte[i++] << 16 & 0xFF0000 | paramArrayOfbyte[i++] << 8 & 0xFF00 | paramArrayOfbyte[i++] & 0xFF;
/*    */       
/* 74 */       i += j;
/* 75 */       j = paramArrayOfbyte[i++] << 24 & 0xFF000000 | paramArrayOfbyte[i++] << 16 & 0xFF0000 | paramArrayOfbyte[i++] << 8 & 0xFF00 | paramArrayOfbyte[i++] & 0xFF;
/*    */       
/* 77 */       byte[] arrayOfByte = new byte[j];
/* 78 */       System.arraycopy(paramArrayOfbyte, i, arrayOfByte, 0, j); paramArrayOfbyte = arrayOfByte;
/*    */     } 
/*    */     
/* 81 */     return this.signature.verify(paramArrayOfbyte);
/*    */   }
/*    */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/jce/SignatureRSA.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */