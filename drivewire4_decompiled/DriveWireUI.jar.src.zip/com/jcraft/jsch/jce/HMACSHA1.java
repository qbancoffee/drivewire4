/*    */ package com.jcraft.jsch.jce;
/*    */ 
/*    */ import com.jcraft.jsch.MAC;
/*    */ import javax.crypto.Mac;
/*    */ import javax.crypto.ShortBufferException;
/*    */ import javax.crypto.spec.SecretKeySpec;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HMACSHA1
/*    */   implements MAC
/*    */ {
/*    */   private static final String name = "hmac-sha1";
/*    */   private static final int bsize = 20;
/*    */   private Mac mac;
/*    */   
/*    */   public int getBlockSize() {
/* 40 */     return 20;
/*    */   } public void init(byte[] paramArrayOfbyte) throws Exception {
/* 42 */     if (paramArrayOfbyte.length > 20) {
/* 43 */       byte[] arrayOfByte = new byte[20];
/* 44 */       System.arraycopy(paramArrayOfbyte, 0, arrayOfByte, 0, 20);
/* 45 */       paramArrayOfbyte = arrayOfByte;
/*    */     } 
/* 47 */     SecretKeySpec secretKeySpec = new SecretKeySpec(paramArrayOfbyte, "HmacSHA1");
/* 48 */     this.mac = Mac.getInstance("HmacSHA1");
/* 49 */     this.mac.init(secretKeySpec);
/*    */   }
/* 51 */   private final byte[] tmp = new byte[4];
/*    */   public void update(int paramInt) {
/* 53 */     this.tmp[0] = (byte)(paramInt >>> 24);
/* 54 */     this.tmp[1] = (byte)(paramInt >>> 16);
/* 55 */     this.tmp[2] = (byte)(paramInt >>> 8);
/* 56 */     this.tmp[3] = (byte)paramInt;
/* 57 */     update(this.tmp, 0, 4);
/*    */   }
/*    */   
/*    */   public void update(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
/* 61 */     this.mac.update(paramArrayOfbyte, paramInt1, paramInt2);
/*    */   }
/*    */   
/*    */   public void doFinal(byte[] paramArrayOfbyte, int paramInt) {
/*    */     try {
/* 66 */       this.mac.doFinal(paramArrayOfbyte, paramInt);
/*    */     }
/* 68 */     catch (ShortBufferException shortBufferException) {}
/*    */   }
/*    */ 
/*    */   
/*    */   public String getName() {
/* 73 */     return "hmac-sha1";
/*    */   }
/*    */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/jce/HMACSHA1.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */