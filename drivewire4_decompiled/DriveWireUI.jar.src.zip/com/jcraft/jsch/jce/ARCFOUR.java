/*    */ package com.jcraft.jsch.jce;
/*    */ 
/*    */ import com.jcraft.jsch.Cipher;
/*    */ import javax.crypto.Cipher;
/*    */ import javax.crypto.spec.SecretKeySpec;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ARCFOUR
/*    */   implements Cipher
/*    */ {
/*    */   private static final int ivsize = 8;
/*    */   private static final int bsize = 16;
/*    */   private Cipher cipher;
/*    */   
/*    */   public int getIVSize() {
/* 40 */     return 8; } public int getBlockSize() {
/* 41 */     return 16;
/*    */   } public void init(int paramInt, byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) throws Exception {
/* 43 */     String str = "NoPadding";
/*    */     
/* 45 */     if (paramArrayOfbyte1.length > 16) {
/* 46 */       byte[] arrayOfByte = new byte[16];
/* 47 */       System.arraycopy(paramArrayOfbyte1, 0, arrayOfByte, 0, arrayOfByte.length);
/* 48 */       paramArrayOfbyte1 = arrayOfByte;
/*    */     } 
/*    */     
/*    */     try {
/* 52 */       this.cipher = Cipher.getInstance("RC4");
/* 53 */       SecretKeySpec secretKeySpec = new SecretKeySpec(paramArrayOfbyte1, "RC4");
/* 54 */       this.cipher.init((paramInt == 0) ? 1 : 2, secretKeySpec);
/*    */     
/*    */     }
/*    */     catch (Exception exception) {
/*    */ 
/*    */       
/* 60 */       this.cipher = null;
/* 61 */       throw exception;
/*    */     } 
/*    */   }
/*    */   public void update(byte[] paramArrayOfbyte1, int paramInt1, int paramInt2, byte[] paramArrayOfbyte2, int paramInt3) throws Exception {
/* 65 */     this.cipher.update(paramArrayOfbyte1, paramInt1, paramInt2, paramArrayOfbyte2, paramInt3);
/*    */   }
/*    */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/jce/ARCFOUR.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */