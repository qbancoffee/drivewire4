/*    */ package com.jcraft.jsch.jce;
/*    */ 
/*    */ import com.jcraft.jsch.Cipher;
/*    */ import javax.crypto.Cipher;
/*    */ import javax.crypto.spec.IvParameterSpec;
/*    */ import javax.crypto.spec.SecretKeySpec;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AES256CTR
/*    */   implements Cipher
/*    */ {
/*    */   private static final int ivsize = 16;
/*    */   private static final int bsize = 32;
/*    */   private Cipher cipher;
/*    */   
/*    */   public int getIVSize() {
/* 39 */     return 16; } public int getBlockSize() {
/* 40 */     return 32;
/*    */   } public void init(int paramInt, byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) throws Exception {
/* 42 */     String str = "NoPadding";
/*    */     
/* 44 */     if (paramArrayOfbyte2.length > 16) {
/* 45 */       byte[] arrayOfByte = new byte[16];
/* 46 */       System.arraycopy(paramArrayOfbyte2, 0, arrayOfByte, 0, arrayOfByte.length);
/* 47 */       paramArrayOfbyte2 = arrayOfByte;
/*    */     } 
/* 49 */     if (paramArrayOfbyte1.length > 32) {
/* 50 */       byte[] arrayOfByte = new byte[32];
/* 51 */       System.arraycopy(paramArrayOfbyte1, 0, arrayOfByte, 0, arrayOfByte.length);
/* 52 */       paramArrayOfbyte1 = arrayOfByte;
/*    */     } 
/*    */     try {
/* 55 */       SecretKeySpec secretKeySpec = new SecretKeySpec(paramArrayOfbyte1, "AES");
/* 56 */       this.cipher = Cipher.getInstance("AES/CTR/" + str);
/* 57 */       this.cipher.init((paramInt == 0) ? 1 : 2, secretKeySpec, new IvParameterSpec(paramArrayOfbyte2));
/*    */     
/*    */     }
/*    */     catch (Exception exception) {
/*    */ 
/*    */       
/* 63 */       this.cipher = null;
/* 64 */       throw exception;
/*    */     } 
/*    */   }
/*    */   public void update(byte[] paramArrayOfbyte1, int paramInt1, int paramInt2, byte[] paramArrayOfbyte2, int paramInt3) throws Exception {
/* 68 */     this.cipher.update(paramArrayOfbyte1, paramInt1, paramInt2, paramArrayOfbyte2, paramInt3);
/*    */   }
/*    */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/jce/AES256CTR.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */