/*    */ package com.jcraft.jsch.jce;
/*    */ 
/*    */ import com.jcraft.jsch.MAC;
/*    */ import javax.crypto.Mac;
/*    */ import javax.crypto.ShortBufferException;
/*    */ import javax.crypto.spec.SecretKeySpec;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class HMACMD5
/*    */   implements MAC
/*    */ {
/*    */   private static final String name = "hmac-md5";
/*    */   private static final int BSIZE = 16;
/*    */   private Mac mac;
/*    */   
/*    */   public int getBlockSize() {
/* 40 */     return 16;
/*    */   } public void init(byte[] paramArrayOfbyte) throws Exception {
/* 42 */     if (paramArrayOfbyte.length > 16) {
/* 43 */       byte[] arrayOfByte = new byte[16];
/* 44 */       System.arraycopy(paramArrayOfbyte, 0, arrayOfByte, 0, 16);
/* 45 */       paramArrayOfbyte = arrayOfByte;
/*    */     } 
/*    */     
/* 48 */     SecretKeySpec secretKeySpec = new SecretKeySpec(paramArrayOfbyte, "HmacMD5");
/* 49 */     this.mac = Mac.getInstance("HmacMD5");
/* 50 */     this.mac.init(secretKeySpec);
/*    */   }
/*    */   
/* 53 */   private final byte[] tmp = new byte[4];
/*    */   public void update(int paramInt) {
/* 55 */     this.tmp[0] = (byte)(paramInt >>> 24);
/* 56 */     this.tmp[1] = (byte)(paramInt >>> 16);
/* 57 */     this.tmp[2] = (byte)(paramInt >>> 8);
/* 58 */     this.tmp[3] = (byte)paramInt;
/* 59 */     update(this.tmp, 0, 4);
/*    */   }
/*    */   public void update(byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
/* 62 */     this.mac.update(paramArrayOfbyte, paramInt1, paramInt2);
/*    */   }
/*    */   public void doFinal(byte[] paramArrayOfbyte, int paramInt) {
/*    */     try {
/* 66 */       this.mac.doFinal(paramArrayOfbyte, paramInt);
/*    */     }
/* 68 */     catch (ShortBufferException shortBufferException) {}
/*    */   }
/*    */ 
/*    */   
/*    */   public String getName() {
/* 73 */     return "hmac-md5";
/*    */   }
/*    */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/jce/HMACMD5.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */