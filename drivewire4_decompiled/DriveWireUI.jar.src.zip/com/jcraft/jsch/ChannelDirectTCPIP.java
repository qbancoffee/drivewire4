/*     */ package com.jcraft.jsch;
/*     */ 
/*     */ import java.io.InputStream;
/*     */ import java.io.OutputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChannelDirectTCPIP
/*     */   extends Channel
/*     */ {
/*     */   private static final int LOCAL_WINDOW_SIZE_MAX = 131072;
/*     */   private static final int LOCAL_MAXIMUM_PACKET_SIZE = 16384;
/*     */   String host;
/*     */   int port;
/*  42 */   String originator_IP_address = "127.0.0.1";
/*  43 */   int originator_port = 0;
/*     */ 
/*     */   
/*     */   ChannelDirectTCPIP() {
/*  47 */     setLocalWindowSizeMax(131072);
/*  48 */     setLocalWindowSize(131072);
/*  49 */     setLocalPacketSize(16384);
/*     */   }
/*     */   
/*     */   void init() {
/*     */     try {
/*  54 */       this.io = new IO();
/*     */     } catch (Exception exception) {
/*     */       
/*  57 */       System.err.println(exception);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void connect() throws JSchException {
/*     */     try {
/*  63 */       Session session = getSession();
/*  64 */       if (!session.isConnected()) {
/*  65 */         throw new JSchException("session is down");
/*     */       }
/*  67 */       Buffer buffer = new Buffer(150);
/*  68 */       Packet packet = new Packet(buffer);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  76 */       packet.reset();
/*  77 */       buffer.putByte((byte)90);
/*  78 */       buffer.putString("direct-tcpip".getBytes());
/*  79 */       buffer.putInt(this.id);
/*  80 */       buffer.putInt(this.lwsize);
/*  81 */       buffer.putInt(this.lmpsize);
/*  82 */       buffer.putString(this.host.getBytes());
/*  83 */       buffer.putInt(this.port);
/*  84 */       buffer.putString(this.originator_IP_address.getBytes());
/*  85 */       buffer.putInt(this.originator_port);
/*  86 */       session.write(packet);
/*     */       
/*  88 */       char c = 'Ϩ';
/*     */ 
/*     */       
/*     */       try {
/*  92 */         while (getRecipient() == -1 && session.isConnected() && c > '\000' && !this.eof_remote)
/*     */         {
/*     */           
/*  95 */           Thread.sleep(50L);
/*  96 */           c--;
/*     */         }
/*     */       
/*  99 */       } catch (Exception exception) {}
/*     */       
/* 101 */       if (!session.isConnected()) {
/* 102 */         throw new JSchException("session is down");
/*     */       }
/* 104 */       if (c == '\000' || this.eof_remote) {
/* 105 */         throw new JSchException("channel is not opened.");
/*     */       }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 114 */       this.connected = true;
/*     */       
/* 116 */       if (this.io.in != null) {
/* 117 */         this.thread = new Thread(this);
/* 118 */         this.thread.setName("DirectTCPIP thread " + session.getHost());
/* 119 */         if (session.daemon_thread) {
/* 120 */           this.thread.setDaemon(session.daemon_thread);
/*     */         }
/* 122 */         this.thread.start();
/*     */       } 
/*     */     } catch (Exception exception) {
/*     */       
/* 126 */       this.io.close();
/* 127 */       this.io = null;
/* 128 */       Channel.del(this);
/* 129 */       if (exception instanceof JSchException) {
/* 130 */         throw (JSchException)exception;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void run() {
/* 137 */     Buffer buffer = new Buffer(this.rmpsize);
/* 138 */     Packet packet = new Packet(buffer);
/* 139 */     int i = 0;
/*     */     
/*     */     try {
/* 142 */       Session session = getSession();
/*     */ 
/*     */ 
/*     */       
/* 146 */       while (isConnected() && this.thread != null && this.io != null && this.io.in != null) {
/* 147 */         i = this.io.in.read(buffer.buffer, 14, buffer.buffer.length - 14 - 32 - 20);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 153 */         if (i <= 0) {
/* 154 */           eof();
/*     */           break;
/*     */         } 
/* 157 */         if (this.close)
/* 158 */           break;  packet.reset();
/* 159 */         buffer.putByte((byte)94);
/* 160 */         buffer.putInt(this.recipient);
/* 161 */         buffer.putInt(i);
/* 162 */         buffer.skip(i);
/* 163 */         session.write(packet, this, i);
/*     */       }
/*     */     
/* 166 */     } catch (Exception exception) {}
/*     */     
/* 168 */     disconnect();
/*     */   }
/*     */ 
/*     */   
/*     */   public void setInputStream(InputStream paramInputStream) {
/* 173 */     this.io.setInputStream(paramInputStream);
/*     */   }
/*     */   public void setOutputStream(OutputStream paramOutputStream) {
/* 176 */     this.io.setOutputStream(paramOutputStream);
/*     */   }
/*     */   
/* 179 */   public void setHost(String paramString) { this.host = paramString; }
/* 180 */   public void setPort(int paramInt) { this.port = paramInt; }
/* 181 */   public void setOrgIPAddress(String paramString) { this.originator_IP_address = paramString; } public void setOrgPort(int paramInt) {
/* 182 */     this.originator_port = paramInt;
/*     */   }
/*     */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/ChannelDirectTCPIP.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */