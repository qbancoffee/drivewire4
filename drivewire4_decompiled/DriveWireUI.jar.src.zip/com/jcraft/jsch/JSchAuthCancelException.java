/*    */ package com.jcraft.jsch;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class JSchAuthCancelException
/*    */   extends JSchException
/*    */ {
/*    */   String method;
/*    */   
/*    */   JSchAuthCancelException() {}
/*    */   
/*    */   JSchAuthCancelException(String paramString) {
/* 39 */     super(paramString);
/* 40 */     this.method = paramString;
/*    */   }
/*    */   public String getMethod() {
/* 43 */     return this.method;
/*    */   }
/*    */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/JSchAuthCancelException.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */