/*    */ package com.jcraft.jsch;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class RequestEnv
/*    */   extends Request
/*    */ {
/* 33 */   byte[] name = new byte[0];
/* 34 */   byte[] value = new byte[0];
/*    */   void setEnv(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) {
/* 36 */     this.name = paramArrayOfbyte1;
/* 37 */     this.value = paramArrayOfbyte2;
/*    */   }
/*    */   public void request(Session paramSession, Channel paramChannel) throws Exception {
/* 40 */     super.request(paramSession, paramChannel);
/*    */     
/* 42 */     Buffer buffer = new Buffer();
/* 43 */     Packet packet = new Packet(buffer);
/*    */     
/* 45 */     packet.reset();
/* 46 */     buffer.putByte((byte)98);
/* 47 */     buffer.putInt(paramChannel.getRecipient());
/* 48 */     buffer.putString("env".getBytes());
/* 49 */     buffer.putByte((byte)(waitForReply() ? 1 : 0));
/* 50 */     buffer.putString(this.name);
/* 51 */     buffer.putString(this.value);
/* 52 */     write(packet);
/*    */   }
/*    */ }


/* Location:              /home/pedro/Downloads/tmp/drivewireserver-git/DriveWireUI/DriveWireUI.jar!/com/jcraft/jsch/RequestEnv.class
 * Java compiler version: 2 (46.0)
 * JD-Core Version:       1.1.3
 */